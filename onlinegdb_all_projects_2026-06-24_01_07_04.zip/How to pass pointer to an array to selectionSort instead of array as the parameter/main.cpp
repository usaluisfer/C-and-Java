#include <iostream>

using namespace std;

void selectionSort(int*, int);
void swap(int &, int &);

// Main
int main() 
{
    int arr[] = {64, 25, 12, 22, 11};  // Array to be sorted
    int size = 5;  // Manually passing the size of the array

    // Passing the pointer to the array (first element) and its size
    selectionSort(arr, size);

    cout << "Sorted array: ";
    
    for (int i = 0; i < size; i++) 
    {
        cout << *(arr + i) << " ";  // Dereferencing the pointer to print the values
    }
    
    cout << endl;


    return 0;
    
}



// Function to perform selection sort
void selectionSort(int* arr, int size) 
{
    int minIndex;
    int minValue;
    
    for (int start = 0; start < (size - 1); start++)
    {
        minIndex = start;
        minValue = arr[start];
        
        for (int index = start + 1; index < size; index++)
        {
            if (arr[index] < minValue)
            {
                minValue = arr[index];
                minIndex = index;
            }
        }
        
        swap(arr[minIndex], arr[start]);
        
    }
}



// Swap function
void swap(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}







