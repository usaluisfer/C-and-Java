// User creates and fills the elements of an array
import java.util.Scanner;

public class Main 
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        // Matrix declaration
        int matrix[][] = new int[2][2];    // 2x2
        
        System.out.println("Enter " + matrix.length + " rows and " + matrix[0].length + " columns: ");
        
        // User enters array elements
        for (int row = 0; row < matrix.length; row++) 
        {
            for (int column = 0; column < matrix[row].length; column++) 
            {
                matrix[row][column] = input.nextInt();
            }
        }
    }
}