// #4
// Imagine you are developing a software package that requires users to enter their own passwords.
// Your software requires that users’ passwords meet the following criteria:
// •	The password should be at least six characters long.
// •	The password should contain at least one uppercase and at least one lowercase letter.
// •	The password should have at least one digit.
// Write a program that asks for a password then verifies that it meets the stated criteria. 
// If it doesn’t, the program should display a message telling the user why.

#include <iostream>

using namespace std;
 
// Global constants
const int SIZE = 80; // The maximum size of the array
const int MIN = 6;   // The minimum number characters
 
// Function prototypes
void displayRequirements();
void displayResult(char[]);
bool isValid(char[]);
bool hasLength(char[]);
bool hasLower(char[]);
bool hasUpper(char[]);
bool hasDigit(char[]); 


// Main
int main()
{
    char cstring[SIZE];  // To hold the password
   
    // Display the password requirements.
    displayRequirements();
   
    // Get the password as input from the user.
    cout << "Enter a password: ";
    cin.getline(cstring, SIZE);
    
    // Display a message indicating whether or not the password is valid.
    displayResult(cstring);
    
    
    
    return 0;
    
}



// function for testing password according to the requirements
void displayRequirements()
{
    // Display the password requirements.
    cout << "Password Requirments:\n" << "  - The password should be at least " << MIN << " characters long.\n"
         << "  - The password should contain at least one uppercase\n"
         << "    and at least one lowercase letter.\n"
         << "  - The password should have at least one digit.\n\n";
}



// Function for displaying message if password is valid or not
void displayResult(char str[])
{
    // Determine if password is valid.
    if (isValid(str))
    {
      // If so, display a message indicating that the
      // password is valid.
      cout << "The password is valid.\n";
    }
    
    else  
    {
        // If not, display a message indicating that the password is not valid.
        cout << "The password is invalid.\n";
    }
    
}



// boolean function for checking determining validity of password
bool isValid(char str[])
{
   // The status flag, set to false
   bool status = false;
 
   // Determine if the string meets the requirements for a valid password
   if (hasLength(str) && hasLower(str) && hasUpper(str) && hasDigit(str))
   {
       // If so, set the status to true
       status = true;
   }
 
   // Return the status
   return status;
   
}



// boolean for checking the length of the string
bool hasLength(char str[])
{
    // The status flag, set to false
    bool status = false;
    
    // To count the number of characters
    int count = 0;
 
 
    // Count each character in the string until the null terminator is reached.
    while (*str != '\0')
    {
        // Increment the counter variable
        count++;
 
        // Go to the next character.
        *str++;
    }
 
    // Determine if the character counter variable is greater-than or equal-to the minimum number of characters.
    if (count >= MIN)
    {
        // If so, set the status to true.
        status = true;
    }
 
    // Return the status.
    return status;
    
}



// 
bool hasLower(char str[])
{
    bool status = false; // The status flag, set to false
    int count = 0;       // To count lowercase characters
 
    // Test each character until the null terminator is reached or a lowercase character is found.
    while (*str != '\0' && count == 0)
    {
      // Determine if this character is lowercase.
      if (islower(*str))
      {
         // If so, increment the counter variable.
         count++;
      }
      
      else
      {
         // If not, go to the next character.
         *str++;
      }
      
   }
 
   // Determine if the lowercase character counter variable is greater than zero.
   if (count > 0)
   {
      // If so, set the status to true.
      status = true;
   }
 
   // Return the status.
   return status;
   
}



//
bool hasUpper(char str[])
{
    bool status = false; // The status flag, set to false
    int count = 0;       // To count uppercase characters.
 
    // Test each character until the null terminator
    // is reached or an uppercase character is found.
    while (*str != '\0' && count == 0)
    {
        // Determine if this character is uppercase.
        if (isupper(*str))
        {
            // If so, increment the counter variable.
            count++;
        }
        
        else
        {
            // If not, go to the next character.
            *str++;
        }
    }
 
    // Determine if the uppercase character counter variable is greater than zero.
    if (count > 0)
    {
        // If so, set the status to true.
        status = true;
    }
 
    // Return the status.
    return status;
    
}



//
bool hasDigit(char str[])
{
    bool status = false; // The status flag, set to false
    int count = 0;       // To count digit characters.
 
    // Test each character until the null terminator is reached or a digit character is found.
    while (*str != '\0' && count == 0)
    {
        // Determine if this character is a digit.
        if (isdigit(*str))
        {
            // If so, increment the counter variable.
            count++;
        }
        
        else
        {
            // If not, go to the next character.
            *str++;
        }
 
    }
  
    // Determine if the digit character counter variable is greater than zero.
    if (count > 0)
    {
        // If so, set the status to true.
        status = true;
    }
 
    // Return the status.
    return status;
    
}

