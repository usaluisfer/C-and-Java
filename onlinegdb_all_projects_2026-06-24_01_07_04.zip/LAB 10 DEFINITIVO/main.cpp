// This program asks the user to enter the number of spools ordered and the discount percentage
// asks user for number of spools in stock
// asks if its a custom shipping charge is required.
// After caulculating, it displays the order summary

#include <iostream>
#include <iomanip>
using namespace std;

// Declaring constants
const double SPOOL_PRICE = 134.95;
const double STANDARD_SHIPPING = 15.0;

// Function Prototypes
void getOrder(int &spoolsOrdered, double &discountPercentage, char &customShippingIndicator, double &customShippingCharge);
double calculateSpoolCharges(int spools, double discount);
void displayOrderSummary(int spoolsOrdered, int spoolsInStock, double discount, double customShippingCharge);
double calculateTotalCharges(int spoolsToShip, double spoolCharges, double shippingChargePerSpool);

int main() 
{
    int spoolsOrdered, spoolsInStock;
    double discountPercentage, customShippingCharge = STANDARD_SHIPPING;
    char customShippingIndicator;

    // Getting order details from the user
    getOrder(spoolsOrdered, discountPercentage, customShippingIndicator, customShippingCharge);

    // Getting number of spools in stock with validation
    cout << "Enter the number of spools in stock: ";
    cin >> spoolsInStock;
    
    while (spoolsInStock < 0) 
    {
        cout << "Error, invalid stock amount.The number of spools cannot be negative.\n";
        cout << "Enter the number of spools in stock: ";
        cin >> spoolsInStock;
    }

    // Displays order summary if stock is available
    if (spoolsInStock > 0) 
    {
        displayOrderSummary(spoolsOrdered, spoolsInStock, discountPercentage, customShippingCharge);
    } 
    
    else 
    {
        cout << "Sorry, there are currently no spools in stock, ready to ship.\n";
    }

    cout << "\nThank you, please shop again.\n";
    return 0;
}


// getOrder() gets order details from the user including the number of spools, discount, custom shipping indicator, and custom shipping charge if applicable.
void getOrder(int &spoolsOrdered, double &discountPercentage, char &customShippingIndicator, double &customShippingCharge) 
{
    // Number of spools ordered
    cout << "Please enter the number of spools ordered: ";
    cin >> spoolsOrdered;
    
    while (spoolsOrdered < 1) 
    {
        cout << "Error, invalid order amount. Spools must be at least one.\n";
        cout << "Please enter the number of spools ordered: ";
        cin >> spoolsOrdered;
    }

    // Discount percentage
    cout << "Enter the discount percentage for the customer: ";
    cin >> discountPercentage;
    
    while (discountPercentage < 0) 
    {
        cout << "Error, invalid discount. The percentage cannot be negative.\n";
        cout << "Enter the discount percentage for the customer: ";
        cin >> discountPercentage;
    }

    // Customizing shipping indicator
    cout << "Does the order include custom shipping and handling charges? [Enter Y for Yes or N for No]: ";
    cin >> customShippingIndicator;
    
    while (customShippingIndicator != 'y' && customShippingIndicator != 'Y' && customShippingIndicator != 'n' && customShippingIndicator != 'N') 
    {
        cout << "Error, invalid response. The response should be Y for Yes or N for No.\n";
        cout << "Does the order include custom shipping and handling charges? [Enter Y for Yes or N for No]: " << endl;
        cin >> customShippingIndicator;
    }

    // Customizing shipping charge
    if (customShippingIndicator == 'y' || customShippingIndicator == 'Y') 
    {
        cout << "Enter the shipping and handling charge: ";
        cin >> customShippingCharge;
        
        while (customShippingCharge < 0) 
        {
            cout << "Error, invalid charges entered. Shipping and handling cannot be negative.\n";
            cout << "Enter the shipping and handling charge: " << endl;
            cin >> customShippingCharge;
        }
    } 
    
    else 
    {
        customShippingCharge = STANDARD_SHIPPING;
    }
}


// calculateSpoolCharges - Calculates and returns the total charges for spools including any applicable discount.
double calculateSpoolCharges(int spools, double discount) 
{
    double totalCharge = spools * SPOOL_PRICE;
    double discountAmount = (discount / 100) * totalCharge;
    return totalCharge - discountAmount;
}


// displayOrderSummary() displays the order summary, including the spools ready to ship,
// back-ordered spools, spool charges, shipping charges, and total charges.
void displayOrderSummary(int spoolsOrdered, int spoolsInStock, double discount, double customShippingCharge) 
{
    int spoolsToShip = (spoolsOrdered <= spoolsInStock) ? spoolsOrdered : spoolsInStock;
    int spoolsBackOrdered = (spoolsOrdered > spoolsInStock) ? spoolsOrdered - spoolsInStock : 0;

    double spoolCharges = calculateSpoolCharges(spoolsToShip, discount);
    double shippingCharges = spoolsToShip * customShippingCharge;
    double totalCharges = calculateTotalCharges(spoolsToShip, spoolCharges, customShippingCharge);

    // Displaying header
    cout << "\n\t\tOrder Summary\n";
    cout << "==============================\n";

    // Only displays backorder message if there are spools on backorder
    if (spoolsBackOrdered > 0) 
    {
        cout << spoolsBackOrdered << " spools are on back order.\n";
    }

    cout << spoolsToShip << " spools are ready to ship.\n";

    cout << fixed << setprecision(2);
    
    // Only displays discount message if there is a non-zero discount
    if (discount > 0) 
    {
        cout << "The charges for " << spoolsToShip << " spools (including a " << setprecision(1) << discount << "% discount): $" << setprecision(2) << spoolCharges << endl;
    } 
    
    else 
    {
        cout << "The charges for " << spoolsToShip << " spools : $" << spoolCharges << endl;
    }

    cout << "Shipping and handling for " << spoolsToShip << " spools: $" << shippingCharges << endl;
    cout << "The total charges (incl. shipping & handling): $" << totalCharges << endl;
}


// calculateTotalCharges() calculates and returns the total charges including spool charges and shipping.
double calculateTotalCharges(int spoolsToShip, double spoolCharges, double shippingChargePerSpool) 
{
    double shippingCharges = spoolsToShip * shippingChargePerSpool;
    return spoolCharges + shippingCharges;
}
