// This program includes a function that accepts an array and the array’s size as arguments. 
// The function "shift" creates a new array that is one element larger than the argument array. 
// The first element of the new array is set to 0. Element 0 of the argument array is copied to element 1 of the new array,
// element 1 of the argument array is also copied to element 2 of the new array, and so forth. 
// Finally, the function returns a pointer to the new array.
#include <iostream>

using namespace std;

// Functio prototypes
int *shift(int[], int);
void showArray(int[], int);

int main()
{
    // Constant int
	const int SIZE = 5;
	int values[SIZE] = {1, 2, 3, 4, 5};

	// Displaying the contents of the array.
	cout << "The contents of the original array are:\n";
	showArray(values, SIZE);
	cout << endl;

	// Calling the shift function to make a copy of the array, with the elements shifted one position toward the end of the array
	int *shifting = shift(values, SIZE);

	// Displaying the contents of the new array.
	cout << "The contents of the new array are:\n";
	showArray(shifting, SIZE + 1);    // Adding 1 to SIZE
	cout << endl;

	
	// Free allocated memory
	delete[] shifting;
	
	

	return 0;
}

// ********************************************************
// The shift function accepts an int array and an int     *
// indicating the array's size. The function returns a    *
// pointer to an array that is one element larger than    *
// the array that was passed as an argument. The elements *
// of the argument array are copied to the new array,     *
// shifted one position toward the end of the array.      *
// ********************************************************
int *shift(int array[], int SIZE)
{
    // Allocating a new array
    int *newArray = new int[SIZE + 1];    // original size getting incremented by 1
    
    // Setting fisrt element to 0
    newArray[0] = 0;                    
    
    // Copying contents of original array to newArray
    for (int i = 0; i < SIZE; i++)
    {
        newArray[i + 1] = array[i];
    }
    
    return newArray;
   
   
   
}

// ********************************************************
// The showArray function displays the contents of an int *
// array.                                                 *
// ********************************************************
void showArray(int array[], int SIZE)
{
    // Displaying the array
	for (int i = 0; i < SIZE; i++)
	{
	    cout << array[i] << " ";
	}
	
	cout << endl;
    
    
    
}

