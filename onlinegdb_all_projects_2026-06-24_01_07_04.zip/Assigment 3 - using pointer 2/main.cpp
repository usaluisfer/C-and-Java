#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

// Function prototypes
void sort(string*, double*, int);  
double average(double*, int); 

int main()
{
   // Declare variable to hold the number of test scores
   int SIZE;
   
   // Declare variable to hold the average score
   double averageScore;
   
   // Get the number of test scores.
   cout << "\nHow many test scores will you enter? ";
   cin >> SIZE;
   cout << endl;
   
   // Validate the input. Should be > 0, if not ask the user to enter again
   if (SIZE <= 0)
   {
      cout << "Should be greater than 0. Please enter again: ";
      cin >> SIZE;
      cout << endl;
   }
 
   // Allocate an array to hold the test scores.
   double* scores = new double[SIZE];
   
   // Allocate an array to hold the names.
   string* names = new string[SIZE];
  
   // Populate the two arrays. Check that score are positive values, otherwise ask to enter again
   for (int i = 0; i < SIZE; i++)
   {
      cout << "Enter student " << i + 1 << "'s name: ";
      cin >> names[i];
      
      cout << "Enter that student's test score: ";
      cin >> scores[i];
      if (scores[i] > 0)
      {
         cout << endl;
      }
      
      // Check that score are positive values, otherwise ask to enter again
      while (scores[i] < 0)
      {
         cout << "Negative scores are not allowed." << endl << "Enter another score for this test: " << endl;
         cin >> scores[i];
      }
   }
   
   // Declare variable to point to the scores array
   double *doublePtr = scores;
   // Declare variable to point to the names array
   string *stringPtr = names;


   // Sort the test scores.
   sort(stringPtr, doublePtr, SIZE);


   // Get the average of the test scores.
   averageScore = average(doublePtr, SIZE);
   

   // Display the resulting data.
   cout << "The test scores in ascending "
        << "order, and their average, are:\n\n";
   cout << setw(12) << left << "Name" << setw(6) 
        << " Score" << endl;
   cout << "----------------------------------------" << endl;
   cout << endl;
   cout << setprecision(2) << fixed << showpoint;
   
   //display sorted scores 
   for (int i = 0; i < SIZE; i++)
   {
      
        cout << stringPtr[i] << "        " << doublePtr[i];
        cout << " ";
        cout << endl;
   }
   
   //display average score
   cout << "\nAverage score:  " << averageScore << endl << endl;
   
   // Free the dynamically-allocated memory.
   delete[] doublePtr;
   delete[] stringPtr;
 
   
   return 0;
}



// Selection sort function for student names and test scores
void sort(string *stringPtr, double *doublePtr, int SIZE)
{
    // selection sort for locating smallest element in array and exchanging with element at first position
    for (int start = 0; start < (SIZE - 1); start++)
    {
        // min index
        int minIndex = start;
        
        // Keeps checking for other elements
        for (int index = start + 1; index < SIZE; index++)
        {
           // Checking if index element is smaller than the minimum value found
            if (*(doublePtr + index) < *(doublePtr + minIndex))
            {
               // Updating minimum value and index
                minIndex = index;
            }
        }
        // swaping elements
        swap(*(doublePtr + start), *(doublePtr + minIndex));
        swap(*(stringPtr + start), *(stringPtr + minIndex));
    }
}



// Function to calculate average score
double average(double* doublePtr, int SIZE)
{
    double total = 0;
    for (int i = 0; i < SIZE; i++)
    {
        total += *(doublePtr + i);
    }
    return total / SIZE;
}