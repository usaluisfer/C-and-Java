#include <iostream>

using namespace std;
int main()
{
    int number;
    cout << "Enter a number: ";
    cin >> number;
    
    if (number % 5 == 0)
        cout << "HiFive" << endl;

    
    if (number % 2 == 0)
    
        cout << "Hi Even" << endl;
    

    return 0;
}