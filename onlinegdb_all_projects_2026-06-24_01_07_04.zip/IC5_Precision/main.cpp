
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    // Declaring variables
    double x = 28.45678;
    double y = 42.98;
    double z = 123456.78915;
    double c = 123.4,  d = 12;
    
    // Printing the values
    cout << "X is " << x << endl;
    cout << "Y is " << y << endl;
    
    // Using the setprecision(x) Stream manipulator
    cout << setprecision(1);
    cout << "With precision 1: " << endl;
    cout << "X is " << x << endl;
    cout << "Y is " << y << endl;
    
    cout << setprecision(2);
    cout << "With precision 2: " << endl;
    cout << "X is " << x << endl;
    cout << "Y is " << y << endl;
    
    cout << setprecision(3);
    cout << "With precision 3: " << endl;
    cout << "X is " << x << endl;
    cout << "Y is " << y << endl;
    
    cout << setprecision(4);
    cout << "With precision 4: " << endl;
    cout << "X is " << x << endl;
    cout << "Y is " << y;
    
    // Here I started using the setw(x) manipulator to print in a field at least 8 spaces wide.
    cout << setprecision(5) << setw(8) << endl;
    cout << "With precision 5 and setw(8): " << endl;
    cout << "X is " << setw(8) << x << endl;
    cout << "Y is " << setw(8) << y << endl;
    cout << "Z is " << setw(8) << z << endl;
    
    cout << endl << "C is " << c << endl;
    cout << "D is " << d;
    
    cout << setprecision(5) << setw(8) << endl;
    cout << "With precision 5 and setw(8): " << endl;
    cout << "C is " << setw(8) << c << endl;
    cout << "D is " << setw(8) << d;
    
    // The showpoint manipulator prints decimal for floating-point values
    cout << setprecision(5) << showpoint << setw(8) << endl;
    cout << "With precision 5, showpoint and setw(8): " << endl;
    cout << "C is " << setw(8) << c << endl;
    cout << "D is " << setw(8) << d;
    
    // Here the noshowpoint does not print decimals for floating-point values
    cout << setprecision(5) << noshowpoint << setw(8) << endl;
    cout << "With precision 5, noshowpoint and setw(8): " << endl;
    cout << "C is " << setw(8) << c << endl;
    cout << "D is " << setw(8) << d << endl;
    
    // "fixed" uses decimal notation for floating-point values
    cout << setprecision(2) << fixed << setw(8) << endl;
    cout << "With precision 2 fixed and setw(8): " << endl;
    cout << "X is " << setw(8) << x << endl;
    cout << "Y is " << setw(8) << y << endl;
    cout << "Z is " << setw(8) << z << endl;
    
    cout << setprecision(5) << showpoint << endl;
    cout << "With precision 5 and showpoint: " << endl;
    cout << "C is " << c << endl;
    cout << "D is " << d << endl;
    
    // In this case, the "left" manipulator causes subsequent output to be left-justified
    cout << setprecision(3) << fixed << setw(4) << left << endl;
    cout << "With precision 3 fixed and setw(4) and left justified: " << endl;
    cout << "X is " << setw(4) << x << endl;
    cout << "Y is " << setw(4) << y << endl;
    cout << "Z is " << setw(4) << z;
    
    cout << setprecision(3) << fixed << left << endl;
    cout << "With precision 3 fixed and left justified: " << endl;
    cout << "X is " << x << endl;
    cout << "Y is " << y << endl;
    cout << "Z is " << z;

    // For making the output to be right-justified, I used the "right" manipulator
    cout << setprecision(3) << setw(8) << fixed << right << endl;
    cout << "With precision 3 , setw(8), fixed and right justified: " << endl;
    cout << "X is " << setw(8) << x << endl;
    cout << "Y is " << setw(8) << y << endl;
    cout << "Z is " << setw(8) << z << endl;
    
    
    
    
 

    return 0;
}