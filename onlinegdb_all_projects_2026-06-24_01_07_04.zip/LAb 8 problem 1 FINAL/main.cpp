// This program reads a file containing sales data and writes a bar chart to represent the data read to a file named “saleschart.txt”.
// It will ask the user for the name of the text file containing the sales data.
// Additionally, the store number is stored in a variable of type unsigned int. 
// The sales value is stored in a variable of type long long int.
// It outputs a string of * characters where each * represents $5,000 in sales for that store.
// For each 5,000 in sales, it outputs one *.
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>

using namespace std;

// void function prototype
void salesFunction(string inputFileName) 
{
    // Storing variables using unsigned int for store and long long int for sales
    unsigned int store = 0;
    long long int sales = 0;

    // Boolean that checks if the output file is empty or not
    bool isEmpty = true;

    // Boolean variable that stores if there is an error in input
    bool error = false;

    // Input stream
    ifstream inputFile(inputFileName);
    string line;   // line variable

    // If statement to check if input file opened successfully
    if (inputFile) 
    {
        // For output to a file 
        ofstream outputFile;
        outputFile.open("saleschart.txt");   // Output file named "saleschart.txt"
        
        // If output file opened successfully
        if (outputFile) 
        {
            // while loop for reading one line at a time into the variable line
            while(std::getline(inputFile, line))
            {
                std::stringstream lineStream(line);
                
                // Variable value of type long long int
                long long int value;
                int count = 0;    // count stores number and sales value

                // For storing store number and sales
                store = 0;   // Set at 0
                sales = 0;   // Set at 0
                error = false;   // Resets error for each line

                // While loop for reading an integer at a time from the line
                while (lineStream >> value) 
                {
                    // When count is at zero
                    if (count == 0) 
                    {
                        // If value is greater or equal to 1 and less than or equal to 99
                        if (value >= 1 && value <= 99) 
                        {
                            store = value;
                        } 
                        
                        // Displaying message if it's not inside the range
                        else 
                        {
                            cout << value << " is not in the range 1 through 99." << endl;
                            error = true;
                        }
                        
                    }
                    
                    // When count equals 1
                    else if (count == 1) 
                    {
                        // Checks if value is greater or equal to 0
                        if (value >= 0) 
                        {
                            sales = value;   // Storing value in sales variable
                        } 
                        
                        // If not, prints skipped store
                        else 
                        {
                            cout << "Skipped store #" << store << "." << endl;
                            error = true;
                        }
                    } 
                    else 
                    {
                        cout << "Error! Too many values on one line." << endl;
                        error = true;
                    }
                    
                    
                    
                    count++;    // Count variable increments
                }
                
                // Checking if there's error
                if (error) 
                {
                    
                    continue;
                }

                // Output header is displayed when boolean checks if output file is empty
                if (isEmpty) 
                {
                    outputFile << "SALES BAR CHART\n" << "(Each * equals 5,000 dollars)" << endl;
                    isEmpty = false;
                }

                // Displaying stores and their numbers
                outputFile << "Store " << setw(2) << right << store << ": ";
                
                // For each 5,000 in sales, it output one *.
                for (int i = 0; i < sales / 5000; i++) 
                {
                    outputFile << "*";
                }
                
                outputFile << endl;
            }

            // Closing files
            inputFile.close();   // Closing input file
            outputFile.close();   // Closing output file
            
        } 
        
        // If output file didn't successfully open, error message is displayed
        else
        {
            cout << "\"saleschart.txt\" could not be opened" << endl;
        }
    } 
    
    // If input file wasn't successfully opened, error message is displayed
    else 
    {
        cout << "\"" << inputFileName << "\" could not be opened." << endl;
    }
    
}

// Main function for asking the user for file name
int main() 
{
    string fileName;
    
    // For entering the name of the file
    cout << "Please enter the input file name.\n";
    cin >> fileName;

    // Sales function is called
    salesFunction(fileName);


    return 0;
}
