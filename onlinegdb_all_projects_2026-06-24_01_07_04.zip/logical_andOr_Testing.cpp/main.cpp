/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    /*int  a = 10, b = 16, c = 20; 
     
    if((a -=10) || (b -= 15) && (c += 20))
    {
        cout << "If takes over" << endl;
        cout << "a = " << a <<endl;
        cout << "b = " << b <<endl;
        cout << "c = " << c <<endl;
    }
    else{
        cout << "Else takes over" << endl;
        cout << "a = " << a <<endl;
        cout << "b = " << b <<endl;
        cout << "c = " << c <<endl;
    }
    */
    
    //int e1 = 0, e2 = 0, e3 = 5;           //rule2   always else
        //int e1 = -3, e2 = 0, e3 = 5;          //rule1  always if
       //int e1 = 0, e2 = 3, e3 = 5;           //rule3  if condition
       //int e1 = 0, e2 = 3, e3 = 0;             //rule3  else condition
    if(e1 || e2 && e3)   // --> e1 || ( e2 && e3)  binding will happen bet' e2 and e3 not e1 or e2 first
                                  //thats what && has higher precedence means
    {
        cout << "Good" << endl;
    }
    else{
        cout << "No Good" << endl;
    }

    return 0;
}