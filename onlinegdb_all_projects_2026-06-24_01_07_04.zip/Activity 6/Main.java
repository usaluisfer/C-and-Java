// This program performs the function of a calculator by taking two numbers from user
// It also prompts the user for an operation option, displayed on a menu
// Using methods for each of the operations (Addition, Subtraction, Multiplication, Division, and Modulo)
// Finally, main calls the methods back and displays the results according to the math operation performed
import java.util.Scanner; 

public class Main
{
    // Method for addition
    public static double add(double num1, double num2)
    {
        return num1 + num2;
    }
    
    // Method for subtraction
    public static double subtract(double num1, double num2)
    {
        return num1 - num2;
    }
    
    // Method for multiplication
    public static double multiply(double num1, double num2)
    {
        return num1 * num2;
    }
    
    // Method for division
    public static double divide(double num1, double num2)
    {
        // number 2 entered by user cannot be 0 when performing divison
        if (num2 == 0)
        {
            System.out.println("Cannot divide by zero!");
            System.exit(1);   // Program ends
        }
        
        return (double) num1 / num2;
    }
    
    // Method for modulo or remainder
    public static double modulo(double num1, double num2)
    {
        // number 2 entered by user cannot be 0 when performing modulo
        if (num2 == 0)
        {
            System.out.println("Cannot perform modulo by zero!");
            System.exit(1);    // Program ends
        }
        
        return num1 % num2;
    }
    
    
    
    
    // Main
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        
        // Letting user two numbers
        System.out.println("Enter number a: ");
        double a = sc.nextDouble();
        System.out.println();
        
        System.out.println("Enter number b: ");
        double b = sc.nextDouble();
        System.out.println();
        
        int operation = 0;
        
        // Displaying menu using while loop 
        while (true)
        {
            System.out.println("Calculator Operations:");
            System.out.println("1 : + (Addition) a + b");
            System.out.println("2 : - (Subtraction) a - b");
            System.out.println("3 : * (Multiplication) a * b");
            System.out.println("4 : / (Division) a / b");
            System.out.println("5 : % (Modulo or remainder) a % b");
            System.out.println();
        
            // Letting user enter an option for operation
            System.out.println("Enter your operation: ");
            operation = sc.nextInt();
            System.out.println();
            
            // Checking if option is valid
            if (operation >= 1 && operation <= 5)
            {
                break;
            }
            
            else 
            {
                System.out.println("Invalid choice, try again.");
                System.out.println();
            }
        }
        
        
        // Calling methods
        double addition = add(a, b);
        double subtraction = subtract(a, b);
        double multiplication = multiply(a, b);
        double division = divide(a, b);
        double remainder = modulo(a, b);
        
        // Displaying results depending on the user's operation option (with two decimals)
        if (operation == 1)
        {
            System.out.printf("Result: %.2f%n", addition);
        }
        
        else if (operation == 2)
        {
            System.out.printf("Result: %.2f%n", subtraction);
        }
        
        else if (operation == 3)
        {
            System.out.printf("Result: %.2f%n", multiplication);
        }
        
        else if (operation == 4)
        {
            System.out.printf("Result: %.2f%n", division);
        }
        
        else if (operation == 5)
        {
            System.out.printf("Result: %.2f%n", remainder);
        }
        
        sc.close();

        
        
        
        
        
    }
    
}
