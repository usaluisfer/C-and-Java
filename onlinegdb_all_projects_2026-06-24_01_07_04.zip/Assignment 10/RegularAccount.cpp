#include <iostream>
#include "RegularAccount.h"

RegularAccount::RegularAccount(string nam, double amnt, Date d) : Account(nam, amnt, d) {}

void RegularAccount::print() const 
{
    cout << "Regular account, ";
    this->Account::print();
}








