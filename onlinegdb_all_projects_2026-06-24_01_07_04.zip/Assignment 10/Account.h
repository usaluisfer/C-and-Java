#ifndef ACCOUNT_H_INCLUDED
#define ACCOUNT_H_INCLUDED
#include <string>
#include "Date.h"

using namespace std;

class Account
{
private:
    int accountNumber;
    string ownerName;

protected:
    double balance;
    static int numberAccounts;

public:
    Account(string ownerName_, double balance_, Date date_);
    virtual bool withdraw(double, Date);
    bool deposit(double, Date);
    int getAccountNumber() const;
    double getBalance() const;
    static int getNumberAccounts();
    virtual void print() const;
    
    // For returning the name to the user
    string getOwnerName() const;

};
#endif