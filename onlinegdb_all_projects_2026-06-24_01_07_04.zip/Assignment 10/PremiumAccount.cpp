#include <iostream>
#include "PremiumAccount.h"

const double PremiumAccount::MIN_BALANCE = 1000.0;

PremiumAccount::PremiumAccount(string nam, double amnt, Date d) : Account(nam, amnt, d) {}

bool PremiumAccount::withdraw(double amount, Date d) 
{
    if (balance >= amount + MIN_BALANCE)
    {
        balance -= amount;
        return true;
    }
    return false;
}

double PremiumAccount::getMinBalance() 
{
    return MIN_BALANCE;
}

void PremiumAccount::print() const 
{
    cout << "Premium account, ";
    this->Account::print();
}







