#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
using namespace std;

#include "Account.h"
#include "RegularAccount.h"
#include "PremiumAccount.h"

const int MAX_NUM_ACCOUNTS = 5;

const int CREATE_REGULAR_ACCOUNT = 1;
const int CREATE_PREMIUM_ACCOUNT = 2;
const int DEPOSIT_ACCOUNT = 3;
const int WITHDRAWAL_ACCOUNT = 4;
const int DISPLAY_ALL = 5;
const int QUIT = 6;

int getMonthFromString(string d) {
    return stoi(d.substr(0, 2));
}
int getDayFromString(string d) {
    return stoi(d.substr(3, 2));
}
int getYearFromString(string d) {
    return stoi(d.substr(6, 4));
}
int getHourFromString(string d) {
    return stoi(d.substr(11, 2));
}

bool isValidDateFormat(const string& d) {
    return d.length() >= 13 && d[2] == '/' && d[5] == '/' && d[10] == '/';
}

Account* accountArray[MAX_NUM_ACCOUNTS];

int main() {
    int numAccounts = 0;
    int choice = 0;
    string name;

    cout << fixed << setprecision(2);

    while (choice != QUIT) {
        cout << "\n1->Create regular accnt, 2->Create premium accnt, 3->Deposit to accnt\n";
        cout << "4->Withdraw from accnt, 5->Print info accnts, 6->Quit\n";
        cin >> choice;
        cin.ignore();

        if (choice == CREATE_REGULAR_ACCOUNT || choice == CREATE_PREMIUM_ACCOUNT) {
            if (numAccounts >= MAX_NUM_ACCOUNTS) {
                cout << "Max number of accounts reached, cannot add a new account\n";
                continue;
            }

            //string name;
            string dateString;
            double amount;

            cout << "Enter owner's name: ";
            getline(cin, name);
            cout << "Enter date, in the mm/dd/yyyy/hh format: ";
            getline(cin, dateString);
            cout << "Enter amount: ";
            cin >> amount;
            cin.ignore();

            if (amount < 0) {
                cout << "Amount cannot be negative, account creation not executed\n";
                continue;
            }

            if (!isValidDateFormat(dateString)) {
                cout << "Invalid date format, account creation not executed\n";
                continue;
            }

            int month = getMonthFromString(dateString);
            int day = getDayFromString(dateString);
            int year = getYearFromString(dateString);
            int hour = getHourFromString(dateString);
            Date d;
            d.set(month, day, year, hour);

            if (choice == CREATE_REGULAR_ACCOUNT) {
                accountArray[numAccounts] = new RegularAccount(name, amount, d);
                cout << "Account created: \n";
                accountArray[numAccounts]->print();
                numAccounts++;
            } else {
                if (amount < 1000) {
                    cout << "Insufficient amount, you need at least 1000.00 Galactic units to open a premium account\n";
                } else {
                    accountArray[numAccounts] = new PremiumAccount(name, amount, d);
                    cout << "Account created: \n";
                    accountArray[numAccounts]->print();
                    numAccounts++;
                }
            }
        } else if (choice == DEPOSIT_ACCOUNT || choice == WITHDRAWAL_ACCOUNT) {
            int accNum;
            string dateString;
            double amount;

            cout << "Enter account number: ";
            cin >> accNum;
            cin.ignore();

            bool found = false;
            int idx = -1;
            for (int i = 0; i < numAccounts; i++) {
                if (accountArray[i]->getAccountNumber() == accNum) {
                    found = true;
                    idx = i;
                    break;
                }
            }
            if (!found) {
                cout << "No such account\n";
                continue;
            }

            cout << "Enter date, in the mm/dd/yyyy/hh format: ";
            getline(cin, dateString);
            if (!isValidDateFormat(dateString)) {
                if (choice == DEPOSIT_ACCOUNT)
                    cout << "Invalid date format, deposit not executed\n";
                else
                    cout << "Invalid date format, withdraw not executed\n";
                continue;
            }

            cout << "Enter amount: ";
            cin >> amount;
            cin.ignore();

            if (amount < 0) {
                if (choice == WITHDRAWAL_ACCOUNT)
                    cout << "Amount cannot be negative, withdraw not executed\n";
                else
                    cout << "Amount cannot be negative, deposit not executed\n";
                continue;
            }

            int month = getMonthFromString(dateString);
            int day = getDayFromString(dateString);
            int year = getYearFromString(dateString);
            int hour = getHourFromString(dateString);
            Date d;
            d.set(month, day, year, hour);

            if (choice == DEPOSIT_ACCOUNT) {
                accountArray[idx]->deposit(amount, d);
                cout << "Deposit executed: \n";
                accountArray[idx]->print();
            } else {
                if (accountArray[idx]->withdraw(amount, d)) {
                    cout << "Withdraw executed: \n";
                    accountArray[idx]->print();
                } else {
                    cout << "Insufficient balance, withdrawal not executed\n";
                }
            }
        } 
        
        else if (choice == DISPLAY_ALL) 
        {
            cout << "Accounts\n========\n\n";
            
            bool first = true;

            for (int i = 0; i < numAccounts; i++) 
            {
                if (accountArray[i] != nullptr) 
                {
                    if (!first) 
                    {
                        cout << endl;
                    }
                    first = false; 
            
                    RegularAccount* regAccount = dynamic_cast<RegularAccount*>(accountArray[i]);
                    PremiumAccount* premAccount = dynamic_cast<PremiumAccount*>(accountArray[i]);

                    if (regAccount) 
                    {
                        cout << "Regular account, #: "
                          << regAccount->getAccountNumber()
                          << ", Name: " << regAccount->getOwnerName() << ", Balance: " << regAccount->getBalance()
                          << " Galactic units" << endl;
                    } 
                    
                    else if (premAccount) 
                    {
                        cout << "Premium account, #: "
                          << premAccount->getAccountNumber() << ", Name: " << premAccount->getOwnerName()
                          << ", Balance: " << premAccount->getBalance()
                          << " Galactic units" << endl;
                    }
                }
            }
        }
    }

    for (int i = 0; i < numAccounts; i++) 
    {
        delete accountArray[i];
    }

    return 0;
}
