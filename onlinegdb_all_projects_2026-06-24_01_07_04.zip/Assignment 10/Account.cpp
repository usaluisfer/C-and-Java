#include <iostream>
#include <iomanip>
#include "Account.h"

int Account::numberAccounts = 0;

Account::Account(string ownerName_, double balance_, Date date_)
{
    ownerName = ownerName_;
    balance = balance_;
    accountNumber = numberAccounts + 1000;
    numberAccounts++;
}

bool Account::withdraw(double amount, Date date_)
{
    if (amount <= balance)
    {
        balance -= amount;
        return true;
    }
    
    return false;
}

bool Account::deposit(double amount, Date date_)
{
    if (amount > 0)
    {
        balance += amount;
        return true;
    }
    
    return false;
}

int Account::getAccountNumber() const
{
    return accountNumber;
}

double Account::getBalance() const
{
    return balance;
}

int Account::getNumberAccounts()
{
    return numberAccounts;
}

string Account::getOwnerName() const
{
    return ownerName;
}

void Account::print() const
{
    cout << fixed << setprecision(2);
    cout << "#: " << accountNumber << ", Name: " << ownerName << ", Balance: " << balance << " Galactic units" << endl;
}








