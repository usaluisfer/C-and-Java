// This program will ask the user to enter an amount to be converted in US Dollars and display the equivalent amount in:
// Canadian Dollars (CAD), Mexican Pesos, and British Pounds (GBP).
// Displays the USD, CAD, Pesos, and GBP under headings with these names. 
// Both the headings and amounts are right justified in tab separated fields. 
// All amounts displayed are in fixed-point notation rounded to exactly two digits to the right of the decimal point.
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
    
    // Declaring double variables constants
    const double CAD = 1.35;    //  one US dollar is 1.35 Canadian Dollars
    const double MexicanPesos = 18.36;    // one US dollar is 18.36 Mexican Pesos
    const double GBP = 0.829;    // one US dollar is 0.829 British Pounds.
    
    // Input the user for an amount in US dollars
    double AmountInDollars;
    cout << "Enter an amount in US dollars: ";
    cin >> AmountInDollars;
    cout << endl;
    
    // Calculate the conversions from dollars to each of the currencies (Canadian, Mexican, and British)
    double CAD_converted = AmountInDollars * CAD;
    double Pesos_converted = AmountInDollars * MexicanPesos;
    double GBP_converted = AmountInDollars * GBP;
    
    // Displaying the name of currencies in right justified way and separated 12 characters wide each
    cout << "\tDollars";
    cout << setw(12) << right << "CAD";
    cout << '\t';
    cout << setw(12) << right << "Pesos";
    cout << '\t';
    cout << setw(12) << right << "GBP" << endl;
    
    // Displaying the currency amounts in right justified way, separated 12 characters wide each, and rounded to two decimals.
    cout << setw(15);
    cout << fixed << setprecision(2) << AmountInDollars;
    cout << setw(12) << right << CAD_converted;
    cout << '\t';
    cout << setw(12) << right << Pesos_converted;
    cout << '\t';
    cout << setw(12) << right << GBP_converted;
    
    
    
    
    
    
    return 0;
}