// This program includes an Employee class which calculates an employee's salary by asking for number of hours worked.
// Salary = number of hours * 20;
// The class attributes are name, hoursWorked, and salary 
// The operations (methods) are setData(), calculateSalary(), and display()
import java.util.Scanner;

// Employee class declaration
class Employee
{
    // Attributes
    String name;
    int hoursWorked;
    double salary;
    
    // Operations
    // setData for storing the data
    void setData(String n, int h)
    {
        name = n;
        hoursWorked = h;
    }
    
    // calculateSalary for multiplying the hours worked by 20 (salary)
    void calculateSalary()
    {
        salary = hoursWorked * 20;
    }
    
    // For displaying the results
    void display()
    {
        System.out.println("Employee name: " + name);
        System.out.println("Hours worked: " + hoursWorked);
        System.out.println("Salary: " + salary);
    }
    
}



// Main
public class Main
{
	public static void main(String[] args) 
	{
	    Scanner input = new Scanner(System.in);
	    
	    // Object instance for Employee class
	    Employee empl = new Employee();
	    
	    // Letting user enter employee name and hours worked
	    System.out.println("Enter employee name: ");
	    String name = input.nextLine();
	    
	    System.out.println();
	    System.out.println("Enter number of hours worked: ");
	    int hours = input.nextInt();
	    System.out.println();
	    
	    // Calling methods inside Employee
	    empl.setData(name, hours);
	    empl.calculateSalary();
	    empl.display();
	

	}
}
