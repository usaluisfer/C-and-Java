// This program calls a function to calculate the sum of two matrix. 
// The main program creates two 2D array of 3*3 and initializes the values from 0 to 49 using a random generator.
// It also takes seed from user.
#include <iostream>
#include <cstdlib>
//#include <ctime>
#include <iomanip>

using namespace std;

const int ROW = 3;           // Number of divisions
const int COL = 3;

// Prototypes for the two functions
void addMatrix(int [][COL], int [][COL], int [][COL]);
void printResult(int [][COL], int [][COL], int[][COL], char);

int main()
{
   // Declaring matrix variables
   int m1[ROW][COL];
   int m2[ROW][COL];
   int m3[ROW][COL];
   
   // Taking seed as input
   int seed;
 
   cin >> seed;
    
   // Seeding the random
   srand(seed);
    
   int numbers[ROW * COL * 2]; 
   // Generating values from 0-49 
   for (int i = 0; i < ROW * COL * 2; i++)
   {
      numbers[i] = rand() % 50;
   }
  
   // Assigning numbers in order to m1 and m2
   int index = 0;      // Setting variable index to 0
   for (int i = 0; i < ROW; i++)
   {
      for (int j = 0; j < COL; j++)
      {
         m1[i][j] = numbers[index++];      // Assigning values to m1
      }
   }
   
   // Assigning values for m2
   for (int i = 0; i < ROW; i++)
   {
      for (int j = 0; j < COL; j++)
      {
         m2[i][j] = numbers[index++];
      }
   }


    
   // Print the result and calling functions
   addMatrix(m1, m2, m3);
   
   printResult(m1, m2, m3, '+');
}



// Adding two matrices
void addMatrix(int m1[ROW][COL], int m2[ROW][COL], int m3[ROW][COL] )
{
   for (int i = 0; i < ROW; i++)
   {
      for (int j = 0; j < COL; j++)
      {
         m3[i][j] = m1[i][j] + m2[i][j];
      }
   }
}



// Printing result
void printResult(int m1[ROW][COL], int m2[ROW][COL], int m3[ROW][COL], char op)
{
   // Displaying matrices
   cout << "The addition of the matrices is " << endl;
   
   // Printing matrices in order
   for (int i = 0; i < ROW; i++)
   {
      for (int j = 0; j < COL; j++)
      {
         cout << setw(4) << m1[i][j];
      }

      if (i == ROW / 2)
         cout <<  "  " << op <<  "  "  ;
      else
         cout <<  "     " ;

      // Displaying matrix2
      for (int j = 0; j < COL; j++)
      {
         cout << setw(4) << m2[i][j];
      }

      if (i == ROW / 2)
         cout <<  "  =  " ;
      else
         cout <<  "     " ;
    
      // Displaying matrix3 (resulting matrix)
      for (int j = 0; j < COL; j++)
      {
         cout << setw(4) << m3[i][j];
      }
      
       cout << endl;
    }
}