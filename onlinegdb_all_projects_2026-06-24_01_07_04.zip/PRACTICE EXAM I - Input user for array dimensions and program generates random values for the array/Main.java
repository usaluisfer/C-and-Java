import java.util.Scanner;

public class Main 
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        // Prompt user for array dimensions
        System.out.println("Enter # of rows: ");
        int row = input.nextInt();
        
        System.out.println("Enter # of columns: ");
        int column = input.nextInt();
        
        int matrix[][] = new int[row][column];
        
        System.out.println();
        
        // Array filled with random values
        for (int i = 0; i < row; i++) 
        {
            for (int j = 0; j < column; j++) 
            {
                matrix[i][j] = (int)(Math.random() * 100);
            }
        }
        
        // Displaying array
        for (int i = 0; i < row; i++) 
        {
            for (int j = 0; j < column; j++) 
            {
                System.out.print(matrix[i][j] + " ");
            }
            
            System.out.println();
        }

    }
}
