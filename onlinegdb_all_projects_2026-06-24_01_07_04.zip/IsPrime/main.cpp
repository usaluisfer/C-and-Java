// This program asks the user to enter a positive whole number in the range 2 through 1000 and determines whether the entered number is prime.
// When the number entered by the user is prime, it displays a message saying num is prime, where num is the entered number.
// When the number entered by the user is not a prime, it displays a list of all the values from the list of eleven primes given above that are factors of the entered number.
// If the user enters a number outside the range specified in the prompt, it will display an error message telling the user the number is outside the range 2 through 1000.
// Using if and else statements to test conditions, as well as for statements
#include <iostream>
#include <iomanip>

using namespace std;


int main()
{
    
    // Declaring constant variables for the prime numbers
    const int primes[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31};   // List of the prime numbers
    const int primeTotal = 11;   // Total number
    
    int num;
    // Asking user for entering a positive number inside the range
    cout << "Enter a positive whole number in the range 2 through 1000: ";
    cin >> num;
    cout << endl;
    
    // If outside of the condition
    if (num < 2 || num > 1000) 
    {
        cout << "Error! " << num << " is outside the range 2 through 1000." << endl;   // Error message displayed
        return 0;
    }
    
    // count variable set at 0
    int count = 0;
    // Testing if the number entered is a prime
    for (int i = 0; i < primeTotal; i++) 
    {
        if (num == primes[i]) 
        {
            cout << num << " is prime." << endl;   // If it is prime, this message is displayed
            return 0; 
            
        } 
        // if not, it looks for divisible numbers (factors)
        else if (num % primes[i] == 0) 
        {
            count++;
        }
    }
    
    // When count equals zero
    if (count == 0) 
    {
        cout << num << " is prime." << endl;
    } 
    else 
    {
        // Finding divisible numbers (factors)
        cout << num << " is divisible by:" << endl;
        
        for (int i = 0; i < primeTotal; i++) 
        {
            if (num % primes[i] == 0) 
            {
                // Displaying the factors
                cout << primes[i] << endl;
            }
        }
    }
    
    
       
       
       
       
    

    return 0;
}