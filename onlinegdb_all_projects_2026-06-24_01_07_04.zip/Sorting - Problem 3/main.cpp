// This program lets the user enter a charge account number. 
// The program determines if the number is valid by checking for it in the array list 
#include <iostream>
#include <string>

using namespace std;

// Function prototypes
void selectionSort(string [], int);
void displayArray(string [], int);

int main()
{
    // Constant for the array size
    const int NUM_NAMES = 20;
    
   // Array of account numbers
   string names[NUM_NAMES] = { 
                        "Collins, Bill", "Smith, Bart", "Allen, Jim",
                        "Griffin, Jim", "Stamey, Marty", "Rose, Geri",
                        "Taylor, Terri", "Johnson, Jill",
                        "Allison, Jeff", "Looney, Joe", "Wolfe, Bill",
                        "James, Jean", "Weaver, Jim", "Pore, Bob",
                        "Rutherford, Greg", "Javens, Renee",
                        "Harrison, Rose", "Setzer, Cathy",
                        "Pike, Gordon", "Holland, Beth" };
                         
    
   // Display the unsorted array.
   displayArray(names, NUM_NAMES);

   // Sort the array.
   selectionSort(names, NUM_NAMES);

   // Display the sorted array.
   cout << "Here are the names sorted:\n";
   cout << "--------------------------\n";
   displayArray(names, NUM_NAMES);
   
   return 0;
        
}


// selectionSort function
void selectionSort(string names[], int NUM_NAMES)
{
    // min index
    int minIndex;
    // min value
    string minValue;
    
    // selection sort for locating smallest element in array and exchanging with element at first position
    for (int start = 0; start < (NUM_NAMES - 1); start++)
    {
        minIndex = start;
        minValue = names[start];
        
        // Keeps checking for other elements
        for (int index = start + 1; index < NUM_NAMES; index++)
        {
           // Checking if index element is smaller than the minimum value found
            if (names[index] < minValue)
            {
               // Updating minimum value and index
                minValue = names[index];
                minIndex = index;
            }
        }
        // swaping elements
        swap(names[minIndex], names[start]);
    }
}


void displayArray(string names[], int NUM_NAMES)
{
    for (int i = 0; i < NUM_NAMES; i++)
    {
        cout << names[i] << endl;
    }
}
