#include <iostream>
using namespace std;

class Test 
{ 
protected: 
    int val; 
public: 
    Test (int x = 1) 
        { val = x; } 
 
    virtual void update() 
    {  
        val *= 2; 
     } 
 
    void getVal() 
    { 
        cout << val << endl;
        update(); 
        cout << val << endl; 
    } 

}; 

class Dtest: public Test 
{ 
private: 
    int x; 
public: 
    Dtest (int y = 5) 
        { x = y; } 
 
   void update() 
        { 
             x *= 2; 
            cout  << x << endl; 
        } 

}; 

int main() 
{ 
    Test tObj; 
    tObj.getVal();
    
    Test *obj = new Dtest(); 
    obj->getVal() ; 
    
  
    

} 

