// This program includes a function to merge two integer arrays A and B that are sorted in non-decreasing order into a new array C.
// Array C becomes sorted in non-decreasing order.
// The program asks the user for size of array and content
// It displays the merged array in non-decreasing order
// mergeArrays function uses:
/*
while (i < size1 && j < size2)
   {
      if (A[i] <= B[j])
      {
         C[k++] = A[i++];
      }
      else
      {
         C[k++] = B[j++];
      }
   }
   while(j < size2)
   {
      C[k++] = B[j++];
   }
   while(i < size1)
   {
      C[k++] = A[i++];
   }
*/
#include <iostream>

using namespace std;

// Function prototype for mergeArrays
void mergeArrays(int A[], int size1, int B[], int size2, int C[]);

// Main function
int main()
{
   // Declaring variables
    const int MAX_SIZE = 7;    // Max size of arrays 1, 2, and 3 is 7

    int A[MAX_SIZE];
    int B[MAX_SIZE];
    int C[2 * MAX_SIZE];

    int size1, size2, size3;

    // Asking user for size of array #1
    cout << "Enter the size of array1, cannot exceed 7: " ;
    cin >> size1;
    
    // Asking user for elements inside first array
    cout << "Enter elements for array1 whose size is " << size1 << " : ";
    
    // It only accepts contents inside the allowed max size (7)
    for(int i = 0; i < size1; i++)
        cin >> A[i];

    // Asking for size of array #2
    cout << "Enter the size of array2, cannot exceed 7: " ;
    cin >> size2;
    
    // Asking for elements for second array
    cout << "Enter elements for array2 whose size is " << size2 << " : ";
    
    // Again it only accepts contents inside the allowed max size (7)
    for(int i = 0; i < size2; i++)
       cin >> B[i];
    

    // It displays both arrays generated
    cout << "The two sorted arrays are: \n";
    
    // Displaying array #1
    for(int i = 0; i < size1; i++)
       cout << A[i] << " ";
       cout << endl;

    // Displaying array #2
    for(int i = 0; i < size2; i++)
       cout << B[i] << " ";
       cout << endl;

    // size3 will be the final merged array
    size3 = size1 + size2;     // 1st and 2nd array are added and stored in third array
    
    // Calling function for merged array
    mergeArrays(A, size1, B, size2, C);

    // Displaying size of array and its elements in non-decreasing order
    cout << "\nMerged array is of size " << size3 << " and the elements are: \n";
   
    // Displaying the merged array
    for(int i = 0; i < size3; i++)
       cout << C[i] << " ";
   
    cout << endl;
    
    return 0;
}

// Function definition for merging arrays. Merges A and B. C contains the merged array.
void mergeArrays(int A[], int size1, int B[], int size2, int C[])
{
   // Defining counters / index
   int i = 0;
   int j = 0;
   int k = 0;
   
   // while there are elements in both arrays (For avoiding out of bounds)
   while (i < size1 && j < size2)
   {
      // if first element in first array (A) is less than the first one from the other array (B)
      if (A[i] < B[j])
      {
         C[k++] = A[i++];     // merged array stores it and increments count; (A) continues to the next element for evaluation
      }
      
      else
      {
         C[k++] = B[j++];    // if first element in A is not less than the one from B, C stores that element and B continues to the next element and A stays the same
      }
   }
   
   // As long as there are elements only in array B
   while(j < size2)
   {
      C[k++] = B[j++];
   }
   
   // As long as there are elements only in array A
   while(i < size1)
   {
      C[k++] = A[i++];
   }
   
   

}