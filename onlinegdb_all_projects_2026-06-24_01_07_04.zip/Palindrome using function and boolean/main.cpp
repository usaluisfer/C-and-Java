// This program includes a function (named ifPalindrome) that checks whether a given string is a palindrome
#include <iostream>
#include <string>

using namespace std;

// boolean function for determining if string entered is a palindrome or not
bool ifPalindrome(string word)
{
   // Sets to true
   bool isPalindrome = true;
   
   // Measuring the word length
   int length = word.length();
   
   // check if the string is palindrome or not (checking if first letter is same as last letter)
   for (int i = 0; i < length/2; i++)
   {
      if (word[i] != word[length - 1 - i])
      {
         // if word is not a palindrome, boolean is set to false
         isPalindrome = false;
         break;
      }
   }
   
   return isPalindrome;
   
}
   

// Main
int main()
{
   string str;
   
   // Asking user for input
   cout << "Enter a string: ";
   cin >> str;
   
   if (ifPalindrome(str))
   {
      cout << "The given string is a palindrome. \n";
   }
   
   else
   
   {
      cout << "The given string is not a palindrome. \n";
   }
   
   return 0;
   
}
