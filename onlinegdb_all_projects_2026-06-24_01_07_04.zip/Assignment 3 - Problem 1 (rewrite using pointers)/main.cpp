// This program lets the user enter a charge account number. 
// The program determines if the number is valid by checking for it in the array list 
// This time using pointers instead
#include <iostream>
using namespace std;

// Function prototype
bool searchList(int *, int, int);

// Constant for the array size
const int SIZE = 18;

int main()
{
   // Use this Array of account numbers
   int accounts[SIZE] = { 5658845,  4520125,  7895122,
                           8777541,  8451277,  1302850,
                           8080152,  4562555,  5552012,
                           5050552,  7825877,  1250255,
                           1005231,  6545231,  3852085,
                           7576651,  7881200,  4581002 };
                           
   
   // Declaring a pointer variable "intArrayPtr" and initializing it to point to the address of the first element of the array
   int *intArrayPtr = accounts;
   
   // Prompting user for entering account number 
   int accountNumber;
   cout << endl << "Please enter a 7-digit account number: ";
   cin >> accountNumber;
   
   // Making sure input by user is a 7-digit number
   if (accountNumber < 1000000 || accountNumber > 9999999) 
   {
      // Error message displayed
      cout << "The number you entered is invalid." << endl;
      return 0;
   }
   
   
   // Searching for the accountNumber in the array (by passing the intArrayPtr as an argument) and indicates
   // whether it is valid or not.
   // Printing message whether accountNumber is valid or invalid
   if (searchList(intArrayPtr, accountNumber, SIZE))
   {
      cout << " The number you entered is valid." << endl;
   }
   
   else
   {
      cout << " The number you entered is invalid." << endl;
   }
   
   return 0;
   
}
   

   
// Defining searchList function to check
bool searchList(int *accounts, int accountNumber, int SIZE)
{
   for (int i = 0; i < SIZE; i++)
   {
       // Pointer arithmetic for searching array
      if (*(accounts + i) == accountNumber)
      {
         // If found, boolean sets to true
         return true;
      }
   }
   
   // If not, false
   return false;
}