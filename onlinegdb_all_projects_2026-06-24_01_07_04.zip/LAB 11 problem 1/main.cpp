// This program gets up to one hundred and twenty grades from the user, 
// calculates and displays the average of the grades 
// followed by a list of the grades that are below the average.
// It keeps asking the user for scores until -999 (sentinel) is entered
#include <iostream>
#include <iomanip>

using namespace std;

int main() 
{
    // Array for holding 120 scores initialized to zero
    int grades[120] = {0};
    int count = 0;    // counter variable
    double sum = 0.0;     // variable for holding the decimal sum of characters
    
    // Asking user for the first score
    int userScore;
    cout << "Enter the first score or -999 to end input: ";
    cin >> userScore;
    
    // If the score is -999, error message is displayed and program ends, displaying the totals.
    if (userScore == -999)
    {
        cout << "No scores were entered." << endl;
        return 0;
    }
    
    // If a value other than the sentinel is entered, program continues and keeps adding scores
    else
    {
        // While score entered is not -999 and can still be inside the array, keeps adding scores
        while (userScore != -999 && count < 120)
        {
            grades[count] = userScore;
            sum += userScore;    // adding and storing the sum
            count++;     // count increments
            
            // if array can still hold more scores, keeps asking user for another score
            if (count < 120)
            {
                cout << "Enter the next score or -999 to end input: ";
                cin >> userScore;
                cin.ignore();
            }
        }
        
        // Calculating average (total sum divided by the amount of scores entered)
        double average = sum / count;
        
        // Rounded exactly one digit to the right
        cout << fixed << setprecision(1);
        
        // Displaying average
        cout << "The average of the scores is: " << average << "." << endl;
        
        // If there are more than 1 scores entered, calculates the ones below average
        if (count > 1)
        {
            cout << "The scores below the average were: ";
            
            // Variable for tracking if the first grade above average is printed
            int belowAverage = 1;     // initialized to 1
            
            // When it is between the range
            for (int i = 0; i < count; i++)
            {
                // Determining if grade is less than average
                if (grades[i] < average)
                {
                    // Displaying the scores above average
                    if (belowAverage)
                    {
                        cout << grades[i];
                        belowAverage = 0;     // variable is set to 0
                    }
                    
                    else
                    {
                        cout << " " << grades[i];
                    }
                }
            }
            
            cout << " " << endl;
            
        }
    }
    
    
    return 0;
    
}