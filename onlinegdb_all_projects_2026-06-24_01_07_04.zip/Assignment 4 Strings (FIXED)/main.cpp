// This program performs input validation when reading grocery product records from a file.
// Each grocery product record consisting of 5 items: PLU code, Product Name, Product Sales Type, Price, and Inventory.
// To contain valid data, the file must have only valid records. A record is valid if
// program checks whether lines have exactly 5 items on the same line
// The first item should be a PLU. It is valid if and only if it contains only letters or digits, and is 4 characters long
// The second item should be product name. It is valid if and only if the first character is a letter
// The third item should be a sales type. It is valid if and only if it is only one character, and the character is a 1 or a 0
// The fourth item should be a unit price. It is valid if and only if it contains only digits and at most one dot. If there is a dot, there are at most two digits after the dot
// And finally, the fifth item should be the inventory level. It is valid if and only if it contains only digits
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>

using namespace std;

// Function prototypes
bool isValidPrice(string);
string tokenize(string & s);

int main ()
{
    // Asking user to enter a file name
    string fileName;
    cout << "Enter input file:" << fileName << endl;
    cin >> fileName;
    
    ifstream inputFile;
    
    inputFile.open(fileName);
    if (!inputFile)    // Checking if file was opened correctly
    {
        cout << "Error opening file!" << endl;
        return 1;
    }
    
    cout << "Checking " << fileName << endl;
    cout << string(9 + fileName.length(), '-') << endl << endl;

    // Declaring line and count variables
    string line;
    int count = 0;
    bool validFile = true;    // boolean for determining valid or invalid
    
    // Reding the content inside the file
    while (getline(inputFile, line))
    {
        count++;
        string originalLine = line;
        int tokenCount = 0;      // the count for tokens starts incrementing
        
        // The file must exactly have 5 items (tokens) in the same line
        string numOfTokens[5];
        
        // If file contains less than 5 tokens
        while (tokenCount < 5)
        {
            string tokens = tokenize(line);
            
            // Using .empty() to check if string is empty
            if (tokens.empty())
            {
                break;
            }
            
            numOfTokens[tokenCount++] = tokens;
            
            
        }
        

        /*
        // Checking when a line is not empty, but contains items not needed
        if (!line.empty() && tokenCount >= 6)
        {
            cout << "Token #" << tokenCount + 1 << " is " << line << ", Too many items in record" << endl;
            validFile = false;
            
        }
        */
        
    
        
        
        
        
        
        
        
        
        
        if (tokenCount <= 4)
        {
            // Print valid tokens before displaying the error
            for (int i = 0; i < tokenCount; i++)
            {
                cout << "Token #" << i + 1 << " is " << numOfTokens[i] << ", ";
        
                if (i == 0)
                cout << "PLU is valid";
                else if (i == 1)
                cout << "Product name is valid";
                else if (i == 2)
                cout << "Sales type is valid";
                else if (i == 3)
                cout << "Price is valid";
        
            cout << endl;
            
            }
                    
            // Displaying an error message to the user
            cout << "Inventory is invalid, record has missing items" << endl;
            validFile = false;      // validFile is set to false
            break;
        }
        
        
        
        
        if (!line.empty() && tokenCount >= 6)
        {
        // Check for special characters "&^" in any token
        for (int i = 0; i < tokenCount; i++)
        {
            for (int j = 0; j < numOfTokens[i].length(); j++)
            {
                if (numOfTokens[i][j] == '&' || numOfTokens[i][j] == '^')
                {
                    cout << "Token #" << i + 1 << " is " << numOfTokens[i] << ", Too many items in record" << endl;
                    validFile = false;
                    break;
                }
            }
        }
        }
        
        
        
        // Check for extra tokens beyond the required 5
        string extraToken = tokenize(line);
        if (!extraToken.empty())
        {
            
            // Print valid tokens before displaying the error
            for (int i = 0; i < tokenCount; i++)
            {
                cout << "Token #" << i + 1 << " is " << numOfTokens[i] << ", ";
        
                if (i == 0)
                cout << "PLU is valid";
                else if (i == 1)
                cout << "Product name is valid";
                else if (i == 2)
                cout << "Sales type is valid";
                else if (i == 3)
                cout << "Price is valid";
                else if (i == 4)
                cout << "Inventory is valid";
        
            cout << endl;
            
            }
            
            cout << "Token #" << tokenCount + 1 << " is " << extraToken << ", Too many items in record" << endl;
            validFile = false;
            break;
        }
        
        
        
        
        
        
        
        // PLU (4 characters, only letters and digits)
        bool validPLU = (numOfTokens[0].length() == 4);
        
        for (int i = 0; i < 4 && validPLU; i++) 
        {
            if (!((numOfTokens[0][i] >= '0' && numOfTokens[0][i] <= '9') || (numOfTokens[0][i] >= 'A' && numOfTokens[0][i] <= 'Z') || (numOfTokens[0][i] >= 'a' && numOfTokens[0][i] <= 'z')))
            {
                validPLU = false;
            }
        }
        
        
        // Token #1
        // Output line for PLU, including whether it is valid or not
        cout << "Token #1 is " << numOfTokens[0] << ", PLU is ";
        
        // Checking if its a first element in the array
        if (validPLU) 
        {
            cout << "valid" << endl;
        } 
        
        // if not, its invalid
        else
        {
            cout << "invalid" << endl;
            validFile = false;
            break;
        }
        
        
        // For product name the first character needs to be a letter
        bool validProductName = (numOfTokens[1][0] >= 'A' && numOfTokens[1][0] <= 'Z') || (numOfTokens[1][0] >= 'a' && numOfTokens[1][0] <= 'z');
        
        // Token #2
        // Output line for product name, including whether it is valid or not
        cout << "Token #2 is " << numOfTokens[1] << ", Product name is ";
        
        if (validProductName) 
        {
            cout << "valid" << endl;
        }
        
        else
        {
            cout << "invalid" << endl;
            validFile = false;
            break;
        }
        
        
        
        // Sales Type can only be '0' or '1'
        bool validSalesType = (numOfTokens[2] == "0" || numOfTokens[2] == "1");
        
        // Token #3
        // Output line for sales type, including whether it is valid or not
        cout << "Token #3 is " << numOfTokens[2] << ", Sales type is ";
        
        if (validSalesType) 
        {
            cout << "valid" << endl;
        }
        
        else
        {
            cout << "invalid" << endl;
            validFile = false;
            break;
        }
        
        
        
        // Calling price
        bool validPrice = isValidPrice(numOfTokens[3]);
        
        // Token #4
        // Output line for prices, including whether it is valid or not
        cout << "Token #4 is " << numOfTokens[3] << ", Price is ";
        
        if (validPrice) 
        {
            cout << "valid" << endl;
        }
        
        else
        {
            cout << "invalid" << endl;
            validFile = false;
            break;
        }
        
        
        
        // Inventory only includes digits
        bool validInventory = true;
        for (int i = 0; i < numOfTokens[4].length(); i++) 
        {
            // If it doesn't found digits
            if (!(numOfTokens[4][i] >= '0' && numOfTokens[4][i] <= '9')) 
            {
                validInventory = false;      // boolean set to false
                break;
            }
        }
        
        // Token #5
        // Output line for inventory, including whether it is valid or not
        cout << "Token #5 is " << numOfTokens[4] << ", Inventory is ";
        
        if (validInventory) 
        {
            cout << "valid" << endl;
        }
        
        else
        {
            cout << "invalid" << endl;
            validFile = false;
            break;
        }
        
        cout << endl;
        
        
        
    }
    
    
    // Closing the file
    inputFile.close();
    
    // Final output
    // If valid
    if (validFile) 
    {
        cout << "######## " << fileName << " has valid content ########" << endl;
    } 
    
    // If not valid
    else 
    {
        cout << "\n######## " << fileName << " has invalid content ########" << endl;
    }

    
    
    return 0;
}



// Function that returns true if the string is a valid price, false otherwise 
bool isValidPrice(string price)
{
    int dots = 0;     // count of dots
    int afterDot = 0;      // count for digits after dot
    
    // Checking if there was not price or if it started with a dot
    if (price.empty() || price[0] == '.')
    {
        return false;
    }
    
    // Checking whether characters are digits using 0 to 9
    for (int i = 0; i < price.length(); i++)
    {
        if (price[i] >= '0' && price[i] <= '9')
        {
            if (dots > 0) 
            {
                afterDot++;
            }
        }
        
        // Incrementing the number of dots when found
        else if (price[i] == '.')
        {
            dots++;
            
            if (dots > 1)
            {
                return false;
            }
        }
        
        else 
        {
            return false;
        }
        
    }
    
    return afterDot <= 2;     // making sure there are at most two digits after the decimal point
    
    
}



// tokenize function
string tokenize(string & s)
{
    // Declaring a counter variable
    int count = 0;
    
    // Looping over the characters of s as long as they are a delimiter (returns) and the end of s is not reached 
    while (count < s.length() && (s[count] == ' ' || s[count] == '\t' || s[count] == '\n' || s[count] == '\r')) 
    {
        count++;
    }
    
    // Looping over the remaining characters before end is reached
    int end = count;
    while (end < s.length() && s[end] != ' ' && s[end] != '\t' && s[end] != '\n' && s[end] != '\r') 
    {
        end++;
    }

    // Extracting the first token found, and storing the characters into token
    string token = s.substr(count, end - count);      // using .substring()
    
    // Deleting the first n characters from s, using .erase()
    s.erase(0, end);

    return token;
    
    
}



