// #3
// Write a program that reads twenty student records from a file (students.txt) and prints the student with the highest GPA.
// The file contains each student’s name, gpa, and current year. 
// You should write a function main that declares an array of students to hold the data for 20 students.
// It should call a function max which takes as parameters the student array and size,
// and returns the index of the student with the highest gpa.

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// structure called Student
struct Student 
{
    string name;
    double gpa; 
    int year;
};


// Function prototype
int max(Student [], int);


// Main
int main() 
{
    // Array of students to hold the data for 20 students
    Student students[20];
    
    // reading data from file
    ifstream file("students.txt");

    // If file is incorrect
    if (!file) 
    {
        cerr << "Error opening file!" << endl;
        return 0;
    }

    // Reading data from 20 students
    for (int i = 0; i < 20; ++i) 
    {
        file >> students[i].name >> students[i].gpa>> students[i].year;
    }

    // File is closed
    file.close();

    // Calling function and storing it in variable maxIndex
    int maxIndex = max(students, 20);

    // Displaying student name along with his/her GPA (student with the highest GPA only)
    cout << "Student name " << students[maxIndex].name << "gpa: " << students[maxIndex].gpa << endl;

    return 0;
    
}



// function which takes as parameters the student array and size, and returns the index of the student with the highest gpa
int max(Student students[], int size) 
{
    int maxIndex = 0; // Assume first student has the highest gpa, index = 0
    
    // Looking for highest GPA
    for (int i = 1; i < size; ++i) 
    {
        if (students[i].gpa > students[maxIndex].gpa) 
        {
            maxIndex = i; // Found a student with a higher gpa, set the new maxIndex
        }
    }
    
    return maxIndex;
}



