// This program rotates a string according to (k) characters, entered by the user.
#include <iostream>

using namespace std;

int main()
{
   // Declaring string variable
   string s;

   int k;
   
   // Ask user for string and rotation value
   cin >> s >> k;
   
   // k is within the length of the string
   k = k % s.length();
   
   // Shifting characters to the left
   for (int i = 0; i < k; i++)
   {
      char firstCharacter = s[0];
      
      for (int j = 0; j < s.length() - 1; j++)
      {
         s[j] = s[j + 1];
      }
      
      // First character at the end
      s[s.length() - 1] = firstCharacter;
   }
   
   cout << s << endl;
   
   return 0;
      
}
   