#include <iostream>
using namespace std;

#include "ShoppingCart.h"


ShoppingCart::ShoppingCart() : customerName("none"), currentDate("January 1, 2016"), cartItems() {}
// Constructor
ShoppingCart::ShoppingCart(string cn, string cd)
{
    customerName = cn;
    currentDate = cd;
}

//
void ShoppingCart::AddItem(ItemToPurchase item)
{
    cartItems.push_back(item); 
}

//
void ShoppingCart::RemoveItem(string itemName)
{
    for (size_t i = 0; i < cartItems.size(); i++) 
    {
        if (cartItems[i].GetName() == itemName) 
        {
            cartItems.erase(cartItems.begin() + i);
            return;
        }
    }
        
    cout << "Item not found in cart. Nothing removed." << endl;
   
}

//
void ShoppingCart::ModifyItem(ItemToPurchase item)
{
    /*
    for (size_t i = 0; i < cartItems.size(); i++) 
    {
        if (cartItems[i].GetName() == item.GetName()) 
        {
            if (!item.GetDescription().empty()) 
            {
                cartItems[i].SetDescription(item.GetDescription());
            }
            if (item.GetPrice() != 0) 
            {
                cartItems[i].SetPrice(item.GetPrice());
            }
            if (item.GetQuantity() != 0) 
            {
                cartItems[i].SetQuantity(item.GetQuantity());
            }
            return;
        }
    }
    cout << "Item not found in cart. Nothing modified." << endl;
    */
    
    
    
    for (size_t i = 0; i < cartItems.size(); i++) {
        if (cartItems[i].GetName() == item.GetName()) {
            if (item.GetQuantity() != 0) { // Only update quantity
                cartItems[i].SetQuantity(item.GetQuantity());
            }
            return;
        }
    }
    cout << "Item not found in cart. Nothing modified." << endl;
}

//
int ShoppingCart::GetNumItemsInCart()
{
    int totalItems = 0;
    for (size_t i = 0; i < cartItems.size(); i++) 
    {
        totalItems += cartItems[i].GetQuantity();
    }
        return totalItems;
}

//
int ShoppingCart::GetCostOfCart() 
{
    int totalCost = 0;
    for (size_t i = 0; i < cartItems.size(); i++) 
    {
        totalCost += cartItems[i].GetPrice() * cartItems[i].GetQuantity();
    }
    return totalCost;
}

//
void ShoppingCart::PrintTotal() 
{
    cout << customerName << "'s Shopping Cart - " << currentDate << endl;
    cout << "Number of Items: " << GetNumItemsInCart() << "\n" << endl;

    if (cartItems.empty()) 
    {
        cout << "SHOPPING CART IS EMPTY" << endl;
    } 
    else 
    {
        for (size_t i = 0; i < cartItems.size(); i++) 
        {
            cout << cartItems[i].GetName() << " " << cartItems[i].GetQuantity() << " @ $" << cartItems[i].GetPrice() << " = $" << (cartItems[i].GetPrice() * cartItems[i].GetQuantity()) << endl;
        }
    }
    cout << "\nTotal: $" << GetCostOfCart() << endl;
}

//
void ShoppingCart::PrintDescriptions() 
{
    cout << customerName << "'s Shopping Cart - " << currentDate << endl;
    cout << "\nItem Descriptions" << endl;

    if (cartItems.empty()) 
    {
        cout << "SHOPPING CART IS EMPTY" << endl;
    } else 
    {
        for (size_t i = 0; i < cartItems.size(); i++) 
        {
            cout << cartItems[i].GetName() << ": " << cartItems[i].GetDescription() << endl;
        }
    }
}




