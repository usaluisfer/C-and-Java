#include <iostream>
#include <iomanip>

using namespace std;

//#include "ItemToPurchase.h"
#include "ShoppingCart.h"


void PrintMenu()
{
    //cout << endl;
	cout << "MENU" << endl;
    cout << "a - Add item to cart" << endl;
    cout << "d - Remove item from cart" << endl;
    cout << "c - Change item quantity" << endl;
    cout << "i - Output items' descriptions" << endl;
    cout << "o - Output shopping cart" << endl;
    cout << "q - Quit";
}

//
void ExecuteMenu(char option, ShoppingCart& theCart)
{
    
	if (option == 'o')
	{
		cout << "OUTPUT SHOPPING CART" << endl;
		theCart.PrintTotal();
	}

	else if (option == 'i')
	{
		cout << "\nOUTPUT ITEMS' DESCRIPTIONS" << endl;
		theCart.PrintDescriptions();
	}

	else if (option == 'a')
	{
		cout << "\nADD ITEM TO CART" << endl;
		string name, description;
		int price, quantity;

		cout << "Enter the item name:" << endl;
		getline(cin, name);

		cout << "Enter the item description:" << endl;
		getline(cin, description);

		cout << "Enter the item price:" << endl;
		cin >> price;

		cout << "Enter the item quantity:" << endl;
		cin >> quantity;

		// Create a new ItemToPurchase object and add it to the cart
		ItemToPurchase newItem;
		newItem.SetName(name);
		newItem.SetDescription(description);
		newItem.SetPrice(price);
		newItem.SetQuantity(quantity);

		theCart.AddItem(newItem);

		cin.ignore(); // Clear input buffer
	}

	else if (option == 'd')
	{
		cout << "\nREMOVE ITEM FROM CART" << endl;
		string itemName;
		cout << "Enter name of item to remove:" << endl;
		getline(cin, itemName);

		theCart.RemoveItem(itemName);
	}

	else if (option == 'c')
	{
		cout << "\nCHANGE ITEM QUANTITY" << endl;
		string itemName;
		int newQuantity;

		cout << "Enter the item name:" << endl;
		getline(cin, itemName);
		cout << "Enter the new quantity:" << endl;
		cin >> newQuantity;

		ItemToPurchase modifiedItem;
		modifiedItem.SetName(itemName);
		modifiedItem.SetQuantity(newQuantity);

		theCart.ModifyItem(modifiedItem);

		cin.ignore();
	}



	else
	{
		cout << "Choose an option:" << endl;
		cin >> option;
		cin.ignore();
		
		if (option == 'q')
		{
		    return;
		}
	}


}



// Main
int main()
{
	string customerName, currentDate;

	cout << "Enter customer's name:" << endl;
	getline(cin, customerName);
	cout << "Enter today's date:" << endl;
	getline(cin, currentDate);

	ShoppingCart cart(customerName, currentDate);

	cout << "\nCustomer name: " << cart.GetCustomerName() << endl;
	cout << "Today's date: " << cart.GetDate() << endl;

	// For letting the user choose an option
	char option;     // char variable for option
    
	
	while (true) {
	    cout << endl;
	    PrintMenu();
	    cout << endl;
        cout << "\nChoose an option:" << endl;
        cin >> option;
        cin.ignore();  // Ignore any extra input characters
        
        if (option == 'f')
        {
            cout << "Choose an option:" << endl;
        cin >> option;
        cin.ignore();
        }
        
        if (option == 's')
        {
            cout << "Choose an option:" << endl;
        cin >> option;
        cin.ignore();
        }

        if (option == 'q') {
            break; // Quit immediately without extra output
        }

        
             // Only reprint the menu after executing a valid command
             
         else {
            
            
            ExecuteMenu(option, cart);
        
        }
        
        
    }




	return 0;
}

