#ifndef SHOPPINGCART_H
#define SHOPPINGCART_H

#include <iostream>
#include <string>
#include <vector>
#include "ItemToPurchase.h"

using namespace std;

class ShoppingCart
{
   private:
      string customerName;
      string currentDate;
      vector<ItemToPurchase> cartItems;

   public:
      // Default constructor
      ShoppingCart();
      ShoppingCart(string cn, string cd);     // Constructor
      
      // mutators & accessors
      string GetCustomerName() const
      {
          return customerName;
      }
      
      string GetDate() const
      {
          return currentDate;
      }
      
      // AddItem()
      void AddItem(ItemToPurchase item);
      
      // RemoveItem()
      void RemoveItem(string itemName);
      
      // ModifyItem()
      void ModifyItem(ItemToPurchase item);
      
      // GetNumItemsInCart
      int GetNumItemsInCart(); 
      
      // GetCostOfCart()
      int GetCostOfCart();
      
      // PrintTotal()
      void PrintTotal();
    
      // PrintDescriptions()
      void PrintDescriptions() ;
      
      
};

#endif