#include <iostream>
using namespace std;

#include "ItemToPurchase.h"

ItemToPurchase::ItemToPurchase() : itemName("none"), itemDescription("none"), itemPrice(0), itemQuantity(0) {}


ItemToPurchase::ItemToPurchase(string n, string d, int p, int q) 
{
    itemName = n;
    itemDescription = d;
    itemPrice = p;
    itemQuantity = q;
}


void ItemToPurchase::SetName(string n = "none")
{
    itemName = n;
}

//
void ItemToPurchase::SetPrice(int p = 0)
{
    itemPrice = p;
}

//
void ItemToPurchase::SetQuantity(int q = 0)
{
   itemQuantity = q;
   
}

//
void ItemToPurchase::SetDescription(string d = "none")
{
   itemDescription = d;
   
}

//
void ItemToPurchase::PrintItemCost() const 
{
    cout << itemName << " " << itemQuantity << " @ $" << itemPrice << " = $" << (itemPrice * itemQuantity) << endl;
}

//
void ItemToPurchase::PrintItemDescription() const 
{
    cout << itemName << ": " << itemDescription << endl;
}






 