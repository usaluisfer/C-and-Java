#ifndef ITEM_TO_PURCHASE_H
#define ITEM_TO_PURCHASE_H

#include <string>
using namespace std;

class ItemToPurchase
{
   private:
      string itemName;
      int itemPrice;
      int itemQuantity;
      string itemDescription;

   public:
      // Default constructor initializing itemName, itemPrice, and itemQuantity
      ItemToPurchase();
      ItemToPurchase(string n, string d, int p, int q);
      
      // mutators
      void SetName(string);
      void SetPrice(int);
      void SetQuantity(int);
      void SetDescription(string);
      void PrintItemCost() const;
      void PrintItemDescription() const;
      
      // accessors
      string GetName() const
      {
          return itemName;
      }
      
      int GetPrice() const
      {
          return itemPrice;
      }
      
      int GetQuantity() const
      {
          return itemQuantity;
      }
      
      string GetDescription() const
      {
          return itemDescription;
      }
      
};

#endif