// This program asks the user to enter a number of seconds and converts the seconds to days, hours, minutes, and remaining seconds.
// This program doesn't accept seconds of zero or below. 
// It can display an error message telling the user that the seconds must be greater than zero should they violate this rule.
// Only displays the leading label when the value of days, hours, minutes, or seconds is more than zero.
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    
    // long long int variable is declared for the seconds the user enters
    long long int userSeconds;
    cout << "Enter a time in seconds: ";
    cin >> userSeconds;
    
    // Checking if the number entered is greater than zero
    if (userSeconds <= 0)
    {
        cout << "Error! The seconds must be greater than zero." << endl;
    }
    
    // If it's greater than zero, calculations will take place
    else
    {
        
        // Finding the days
        long long int days = userSeconds / 86400;   // 86400 seconds in a day
        // Remaining seconds
        long long int remainingSeconds = userSeconds % 86400;
        // Finding the hours
        long long int hours = remainingSeconds / 3600;   // 3600 seconds in an hour
        // Updating the seconds remaining with module of 3600 (which is the amount of seconds in an hour)
        remainingSeconds = remainingSeconds % 3600;
        // Calculating the minutes
        long long int minutes = remainingSeconds / 60;   // 60 seconds in a minute
        // The seconds that will be displayed to the screen
        long long int seconds = remainingSeconds % 60;
        
        // Displaying the results to the screen
        cout << endl << endl << userSeconds << " seconds is:" << endl;
        
        if (days > 0)
        {
            cout << '\t' << days << " days." << endl;   // Displaying the days
        }
        if (hours > 0)
        {
            cout << '\t' << hours << " hours." << endl;   // Displaying the hours
        }
        if (minutes > 0)
        {
            cout << '\t' << minutes << " minutes." << endl;   // Displaying the minutes
        }
        if (seconds > 0)
        {
            cout << '\t' << seconds << " seconds." << endl;   // Displaying the seconds
        }
        
    }
    
    
    
    
    
    

    return 0;
}