// This program displays a menu driven program that determines how fast sound travels a specified distance through wood, steel, water, or air as selected by the user.
// When the user selects a valid medium, it asks them for the distance traveled in feet. 
// Otherwise, it displays an error message and asks the user to “Please run the program again.”
// When a distance is greater than zero, it calculates and displays the seconds it takes the sound to travel through the selected medium. 
// Otherwise, it display an error message telling the user that “the distance must be greater than zero”.
#include <iostream>
#include <iomanip>

using namespace std;


int main()
{
    
    // constants for the speeds in the mediums.
    const double woodSpeed = 12631.23;
    const double steelSpeed = 10614.81;
    const double waterSpeed = 4714.57;
    const double airSpeed = 1125.33;
    
    // unsigned int to store the menu choice (the medium)
    unsigned int choice;
    double distance;
    double wood;
    double steel;
    double water;
    double air;
    
    // Displaying choices to the user
    cout << '\t' << "Time for Sound to Travel through a Medium given Distance" << endl << endl;
    cout << "1 - Wood" << endl;
    cout << "2 - Steel" << endl;
    cout << "3 - Water" << endl;
    cout << "4 - Air" << endl << endl;
    cout << "Enter the number of the medium: ";
    cin >> choice;
    cout << endl;
       
    
    // If number entered is less than one or greater than 4, error message is displayed
    if (choice < 1 || choice > 4)
    {
        cout << "Error, invalid entry!" << endl << "Please run the program again." << endl;
    }
    
    else 
       {
           // switch statement to manage the decision between the various mediums
           switch(choice)
           {
               // Evaluating cases for each of the 4 choices
               // For choice 1
               case 1:
               cout << "Enter the distance to travel (in feet): ";
               cin >> distance;
               cout << endl;
               
               // if distance is greater than zero, it will work successfully, otherwise it will give error
               if (distance > 0)
               {
                   // Calculating the seconds
                   wood = distance / woodSpeed;    // Dividing the distance entered by the speed (feet per second) for each choice
                   cout << fixed << setprecision(4);
                   // Displaying the results to the screen
                   cout << "In wood it will take " << wood << " seconds to travel " << fixed << setprecision(2) << distance << " feet." << endl;
                   break;
               }
               
               // else statatement if distance is less than zero (negative)
               else
               {
                   cout << "Error, the distance must be greater than zero." << endl;
                   break;
               }
               
    
               // For choice 2
               case 2:
               cout << "Enter the distance to travel (in feet): ";
               cin >> distance;
               cout << endl;
               
               
               if (distance > 0)
               {
                   steel = distance / steelSpeed;
                   cout << fixed << setprecision(4);
                   cout << "In steel it will take " << steel << " seconds to travel " << fixed << setprecision(2) << distance << " feet." << endl;
                   break;
               }
               else
               {
                   cout << "Error, the distance must be greater than zero." << endl;
                   break;
               }
               
               
               // For choice 3
               case 3:
               cout << "Enter the distance to travel (in feet): ";
               cin >> distance;
               cout << endl;
               
               
               if (distance > 0)
               {
                   water = distance / waterSpeed;
                   cout << fixed << setprecision(4);
                   cout << "In water it will take " << water << " seconds to travel " << fixed << setprecision(2) << distance << " feet." << endl;
                   break;
               }
               else
               {
                   cout << "Error, the distance must be greater than zero." << endl;
                   break;
               }
        
               
               // For choice 4
               case 4:
               cout << "Enter the distance to travel (in feet): ";
               cin >> distance;
               cout << endl;
               
               
               if (distance > 0)
               {
                   air = distance / airSpeed;
                   cout << fixed << setprecision(4);
                   cout << "In air it will take " << air << " seconds to travel " << fixed << setprecision(2) << distance << " feet." << endl;
                   break;
               }
               else
               {
                   cout << "Error, the distance must be greater than zero." << endl;
                   break;
               }
               
           }
       }
       
       
       
       
    

    return 0;
}