#include <iostream>
#include <iomanip> 
#include "Team.h"
using namespace std;

// TODO: Implement mutator functions - SetName(), SetWins(), SetLosses()
void Team::SetName(string userName)
{
   name = userName;
}

void Team::SetWins(int userWins)
{
   wins = userWins;
}

void Team::SetLosses(int userLosses)
{
   losses = userLosses;
}
   
   
// TODO: Implement accessor functions - GetName(), GetWins(), GetLosses()
string Team::GetName() const 
{
   return name;
}

int Team::GetWins() const 
{
   return wins;
}

int Team::GetLosses() const 
{
   return losses;
}


// TODO: Implement GetWinPercentage()
double Team::GetWinPercentage()
{
    return static_cast<double>(wins) / (wins + losses);
}


// TODO: Implement PrintStanding()
void Team::PrintStanding()
{
   double percentWins = GetWinPercentage();
   
   cout << fixed << setprecision(2);
   cout << "Win percentage: " << percentWins << endl;
   
   if (percentWins >= 0.5)
   {
       cout << "Congratulations, Team " << name << " has a winning average!" << endl;
   }
   
   else 
   {
       cout << "Team " << name << " has a losing average." << endl;
   }
   
}



