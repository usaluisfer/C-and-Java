#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    unsigned seed = time(NULL);
    srand(seed);
    
    const int numberOfCards = 52;
    
    int number = rand() % numberOfCards;
    cout << "The card you picked is ";
    
    // To determine the rank
    if (number % 13 == 0)
        cout << "Ace of ";
    else if (number % 13 == 10)
        cout << "Jack of ";
    else if (number % 13 == 11)
        cout << "Queen of ";
    else if (number % 13 == 12)
        cout << "King of ";
    else
        cout << (number % 13) + 1 << " of ";
        
    
    // To determine the suit
    if (number / 13 == 0)
        cout << "Clubs";
    else if (number / 13 == 1)
        cout << "Spades";
    else if (number / 13 == 2)
        cout << "Diamond";
    else if (number / 13 == 3)
        cout << "Hearts";
    
    
    
    

    return 0;
}