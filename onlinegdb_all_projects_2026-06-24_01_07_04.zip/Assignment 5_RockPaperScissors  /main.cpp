// This program plays the popular rock-scissor-paper game.
// A scissor can cut paper, a rock can knock a scissor and a paper can wrap a rock.
// It will generate a number for 0,1,2 representing scissor, rock, paper.
// Inputs from the user a value as scissor (0), rock(1), paper (2).
// At the end, it determines if User or computer wins.
#include <iostream>
#include <cstdlib>  
#include <ctime>

using namespace std;

// This function gets the choice name based on the number
string getChoiceName(int choice) 
{
    switch (choice)   // switch statement for case 0 (scissor), case 1 (rock), and case 2 (paper)
    {
        case 0: return "scissor";
        case 1: return "rock";
        case 2: return "paper";
        default: return "";
    }
}

// This function determines the winner
string winner(int userNumber, int randomNumber) 
{
    if (userNumber == randomNumber)   // If the number entered by the user is equal to the computer generated number, it is a draw
    {
        return " It is a draw!";
    } 
    else if ((userNumber == 0 && randomNumber == 2) || (userNumber == 1 && randomNumber == 0) || (userNumber == 2 && randomNumber == 1))   // The user wins if number entered is a scissor that can cut paper, a rock that can knock a scissor and a paper can wrap a rock
    {
        return " You won!";
    } 
    else   // Otherwise, the user looses
    {
        return " You lost!";
    }
}

int main() 
{
    
    // Random number is generated
    srand(time(0));
    
    // int random variable declared
    int randomNumber;
    randomNumber = rand() % 3;    // Between 0 and 2
    
    // Input the user for a number between 0 and 2
    int userNumber;
    cout << "Choose one of the following:" << endl << "scissor (0), rock (1), paper (2): ";
    cin >> userNumber;
    
    // Keeps asking for input when entering an invalid number 
    while (userNumber < 0 || userNumber > 2) 
    {
        cout << "Enter a number between 0 and 2: ";
        cin >> userNumber;
    }
    
    // Gets the choice names for both
    string userChoiceName = getChoiceName(userNumber);
    string randomChoiceName = getChoiceName(randomNumber);

    // Output for displaying the choices
    cout << endl << "The computer is " << randomChoiceName << ". You are " << userChoiceName << ".";

    // Determining the winner and displaying it to the screen
    cout << winner(userNumber, randomNumber) << endl;




    return 0;
}