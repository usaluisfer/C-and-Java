// This program includes a function to find the index in which the sum is stored, named findSumIndex.
// User is asked for size of array and values/elements inside the array.
#include <iostream>

using namespace std;

// Function for finding the index element that has the sum
int findSumIndex(int elements[], int n)
{
   int sum = 0;     // Counter set to 0
   
   // Adding all the elements for finding total sum
   for (int i = 0; i < n; i++)
   {
      sum += elements[i];
   }
   
   // Checking if any element is equal to the sum of all other elements
   for (int i = 0; i < n; i++)
   {
      if (elements[i] == sum - elements[i])
      {
         return i;
      }
      
   }
   
   return -1;
}


// Main
int main()
{
    int n;

    // Getting the size of the array from the user
    cin >> n;
    
    // Getting the elements of the array from the user
    int elements[n];
    
    for (int i = 0; i < n; i++)
    {
       cin >> elements[i];
    }
    
    // Find out the element with the sum
    int index = findSumIndex(elements, n);
    
    // Making sure that element exists (index)
    if (index != -1)
    {
       // If index is found with the sum
       cout << "Index " << index << " has the sum" << endl; 
    }
    
    else
    {
       // If no index is found with the sum
       cout << "No index has the sum" << endl;
    }


    return 0;
}