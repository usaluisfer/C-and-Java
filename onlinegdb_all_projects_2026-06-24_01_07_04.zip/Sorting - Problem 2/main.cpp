// This program lets the user enter a charge account number. 
// The program determines if the number is valid by checking for it in the array list 
#include <iostream>

using namespace std;

// Function prototype
bool searchList(long [], int, long);
void selectionSort(long[], int);

// Constant for the array size
const int SIZE = 18;

int main()
{
   // Array of account numbers
   long accounts[SIZE] = { 5658845,  4520125,  7895122,
                           8777541,  8451277,  1302850,
                           8080152,  4562555,  5552012,
                           5050552,  7825877,  1250255,
                           1005231,  6545231,  3852085,
                           7576651,  7881200,  4581002 };
                         
    
   // Prompting user for entering account number 
   int chargeNum;
   cout << endl << "Please enter a 7-digit account number: ";
   cin >> chargeNum;
    
    
   selectionSort(accounts, SIZE);
   // searchList function defined
   searchList(accounts, chargeNum, SIZE);
        
}

// selectionSort function
void selectionSort(long accounts[], int SIZE)
{
    // min index
    int minIndex;
    // min value
    int minValue;
    
    // selection sort for locating smallest element in array and exchanging with element at first position
    for (int start = 0; start < (SIZE - 1); start++)
    {
        minIndex = start;
        minValue = accounts[start];
        
        // Keeps checking for other elements
        for (int index = start + 1; index < SIZE; index++)
        {
           // Checking if index element is smaller than the minimum value found
            if (accounts[index] < minValue)
            {
               // Updating minimum value and index
                minValue = accounts[index];
                minIndex = index;
            }
        }
        // swaping elements
        swap(accounts[minIndex], accounts[start]);
    }
}



// searchList function
bool searchList(long accounts[], int chargeNum, long SIZE)
{
   // Initializing first element
    int first = 0;
    // Last element
    int last = SIZE - 1;
    // middle element
    int middle;
    // Position of search value
    int position = -1;
    
    bool found = false;    // Flag "found" is first set as false
    
    // Calculating the middle of the array
    while (!found && first <= last)
    {
        middle = (first + last) / 2;
        
        // if found at middle, found becomes true, meaning number is valid
        if (accounts[middle] == chargeNum)
        {
            found = true;
            position = middle;
            // Message displayed
            cout << " The number you entered is valid." << endl;
        }
        
        // If value is in the lower half
        else if (accounts[middle] > chargeNum)
            last = middle - 1;
            
        // If value is in the upper half
        else
            first = middle + 1;
            
            
        // If false, error message displayed
        if (accounts[middle] == false)
        {
            cout << "The number you entered is invalid." << endl;
            break;
        }
    }
    
    return position;
    
    
}
