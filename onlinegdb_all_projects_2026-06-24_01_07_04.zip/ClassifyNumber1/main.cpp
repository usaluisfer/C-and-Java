// This program gets an unspecified number of whole numbers from the user and displays:
// the sum of the positive numbers entered and the product of the negative numbers entered. 
// Using a while loop to control the number of iterations, ending the input when the user enters a 0.
// In addition to displaying the sum of the positive numbers entered and the product of the negative numbers entered,
// the program displays the number of positive and the number of negative values entered.
// Using ints for all of the variables.
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    // Declaring int variables
    int wholeNumber;
    int positives = 0;   // For carrying the count of positive numbers
    int negatives = 0;   // For carrying the count of negative numbers
    int sum = 0;   // For the sum of positives
    int product = 1;   // Product of negatives
    
    // Asking the user for a whole number
    cout << "Enter a whole number [enter 0 to end input]: ";
    cin >> wholeNumber;
    
    // When the number entered is not equal to zero
    while (!(wholeNumber == 0))
    {
        // Checking for positive numbers
        if (wholeNumber > 0)
        {
            sum += wholeNumber;   // Adding and storing
            positives++;   // positive count increments
        }
        
        // If negative
        else 
        {
            product *= wholeNumber;   // Multiplying the whole numbers
            negatives++;   // negative count increments
        }
        
        // Program continues asking until user enters zero
        cout << "Enter another whole number [enter 0 to end input]: ";
        cin >> wholeNumber;
    }
    
    
    // Displaying number of positives and their sum
    if (positives > 1)
    {
        cout << endl << positives << " positive numbers were entered." <<  " Their sum was " << sum << "." << endl << endl;
    }

    // If there was only one positive
    else if (positives == 1)
    {
        cout << "1 positive number was entered. It was a " << sum << "." << endl << endl;
    }
    
    // If no positive numbers were entered
    else 
    {
        cout << endl << "No positive numbers were entered." << endl << endl;
    }
    
    
    // Displaying number of negatives and their product
    if (negatives > 1)
    {
        cout << negatives << " negative numbers were entered." <<  " Their product was " << product << "." << endl;
    }

    // If there was only one negative
    else if (negatives == 1)
    {
        cout << "1 negative number was entered. It was a " << product <<  "." << endl;
    }
    
    // If no negative numbers were entered
    else 
    {
        cout << "No negative numbers were entered." << endl;
    }
    
    
    
    
    

    return 0;
}