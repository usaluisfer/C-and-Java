#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

const int NUM_PLAYERS = 50;
const int NAME_COL_WIDTH = 15;

double getAvg(int scores[], int size);
int getMin(int scores[], int size, int &minIndex);
int getMax(int scores[], int size, int &maxIndex);



int main()
{
    int pscores[NUM_PLAYERS];
    string pname[NUM_PLAYERS];
    int i = 0;
    int minIndex;
    int maxIndex;
    
    // Attempt to open the file
    ifstream infile("nbaStatsFN.txt");
    
    
    
    string temp;
    
    
    if (infile) 
    {
        //string temp;
        // Skip  the header line
        getline(infile, temp);
    
        while (infile >> pname[i] >> pscores[i]) 
        {
            i++;
            if (i >= NUM_PLAYERS) break; // Prevent reading more than NUM_PLAYERS
        }
    }
    
    else
    {
       cout << "Error opening the file";
    }
    
    infile.close();
    
    // Number of players read
    int numPlayers = i;
    
    cout << "SNO " << temp << endl;
    
    // Display player data
    for (int j = 0; j < numPlayers; ++j) 
    {
        cout << setw(2) << j + 1 << "  " << setw(NAME_COL_WIDTH) << pname[j] << " " << pscores[j] << endl;
    }
    
    // Calculate the average score
    double avg = getAvg(pscores, numPlayers);
    cout << fixed << setprecision(2);
    cout << "\nThe average score is " << avg << endl;

    // Find and display the minimum score
    int minScore = getMin(pscores, numPlayers, minIndex);
    cout << "Minimum score by " << pname[minIndex] << " = " << minScore << endl;

    // Find and display the maximum score
    int maxScore = getMax(pscores, numPlayers, maxIndex);
    cout << "Maximum score by " << pname[maxIndex] << " = " << maxScore << endl;

    return 0;
}



double getAvg(int scores[], int size) 
{
    double sum = 0;
    for (int i = 0; i < size; ++i) 
    {
        sum += scores[i];
    }
    return sum / size;
}

int getMin(int scores[], int size, int &minIndex) 
{
    int minScore = scores[0];
    minIndex = 0;
    for (int i = 1; i < size; ++i) 
    {
        if (scores[i] < minScore) 
        {
            minScore = scores[i];
            minIndex = i;
        }
    }
    return minScore;
}

int getMax(int scores[], int size, int &maxIndex) 
{
    int maxScore = scores[0];
    maxIndex = 0;
    
    for (int i = 1; i < size; ++i) 
    {
        if (scores[i] > maxScore) 
        {
            maxScore = scores[i];
            maxIndex = i;
        }
    }
    
    return maxScore;
}


