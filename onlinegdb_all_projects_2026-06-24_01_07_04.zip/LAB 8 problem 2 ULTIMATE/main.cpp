#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std; // This allows us to avoid using std:: prefix

int main() 
{
    string inputFileName;
    ifstream inputFile;
    ofstream outputFile("badvalues.txt");
    
    // Prompt user for input file name
    cout << "Enter the input file name: " << endl;
    getline(cin, inputFileName);
    
    // Attempt to open the input file
    inputFile.open(inputFileName);
    
    // Check if input file was opened successfully
    if (!inputFile) {
        cout << "The file \"" << inputFileName << "\" could not be opened." << endl;
        return 1; // Exit the program with an error code
    }

    double value;
    int totalValues = 0, validCount = 0, invalidCount = 0;
    double sumValid = 0;

    // Read values from the input file
    while (inputFile >> value) {
        totalValues++;
        validCount++;
        sumValid += value; // Add to sum of valid values
    }

    // Close files
    inputFile.close();
    outputFile.close();

    // Calculate and display results
    cout << endl << "Total number of values read: " << totalValues << endl;
    cout << "Valid values read: " << validCount << endl;
    cout << "Invalid values read: " << invalidCount << endl;

    // Calculate and display the average of valid values
    if (validCount > 0) {
        double average = sumValid / validCount;
        cout << "The average of the valid numbers read = " << fixed << setprecision(2) << average << endl;
    } else {
        cout << "The file did not contain any valid values." << endl;
    }

    return 0; // Successful execution
}
