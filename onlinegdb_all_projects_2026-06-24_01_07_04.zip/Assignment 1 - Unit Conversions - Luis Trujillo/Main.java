// This program displays a menu for the user to select an option for unit conversions
// 1st option converts Fahrenheit to Celsius degrees, 
// 2nd option Gallons to Liters
// 3rd option Pounds to Kilograms
// 4th option Miles to Kilometers
// 5th option Inches to Centimeters
// 6th option Yards to Meters
// 7th option exits the program
import java.util.Scanner;
import java.text.DecimalFormat;   // For displaying two decimals

public class Main 
{
    // Method for converting Fahrenheit to Celsius
    public static double fahrenheitToCelsius(double fahrenheit)
    {
        return (fahrenheit - 32) * 5 / 9;    // Formula
    }

    // Method for converting Gallons to Liters
    public static double gallonsToLiters(double gallons)
    {
        return gallons * 3.78541;
    }

    // Method for converting Pounds to Kilograms
    public static double poundsToKilograms(double pounds)
    {
        return pounds * 0.453592;
    }

    // Method for converting Miles to Kilometers
    public static double milesToKilometers(double miles)
    {
        return miles * 1.60934;
    }

    // Method for converting Inches to Centimeters
    public static double inchesToCentimeters(double inches)
    {
        return inches * 2.54;
    }

    // Method for converting Yards to Meters
    public static double yardsToMeters(double yards)
    {
        return yards * 0.9144;
    }
    
    // Main method
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        
        // For printing result with two decimals
        DecimalFormat df = new DecimalFormat("0.00");

        // Display menu
        System.out.println("1.  Convert Fahrenheit to Celsius");
        System.out.println("2.  Convert Gallons to Liter");
        System.out.println("3.  Convert Pounds to Kilograms");
        System.out.println("4.  Convert Miles to Kilometers");
        System.out.println("5.  Convert Inch to Centimeters");
        System.out.println("6.  Convert Yards to Meter");
        System.out.println("7.  Exit the program.");
        System.out.println();

        // Letting user enter an option
        System.out.println("Enter your option: ");
        int option = sc.nextInt();

        // If option 7 is selected, program exits
        if (option == 7)
        {
            sc.close();
            return;
        }

        // If user enters an option that is not in the menu
        if (option < 1 || option > 7)
        {
            System.out.println("Invalid option");
            System.out.println();
            main(args);
            return;
        }
        
        // If user enters an option that is inside the range, it asks them for a number to be converted
        System.out.println();
        System.out.println("Enter a number to be converted: ");
        double number = sc.nextDouble();
        
        // Checking for negative values for length or weight, except for temperature
        if (option != 1 && number < 0)
        {
            System.out.println();
            System.out.println("Negative numbers not allowed!");
            System.out.println();
            main(args);
            return;
        }
        
        // printing result according to the conversion
        double result;
        
        
        // if and else if statements for making sure the conversions are displayed correcly according to the option
        if (option == 1)
        {
            result = fahrenheitToCelsius(number);
            System.out.println(number + " Fahrenheit = " + df.format(result) + " Celsius");
            System.out.println();
        }
        
        else if (option == 2)
        {
            result = gallonsToLiters(number);
            System.out.println(number + " Gallons = " + df.format(result) + " Liters");
            System.out.println();
        }
        
        else if (option == 3)
        {
            result = poundsToKilograms(number);
            System.out.println(number + " Pounds = " + df.format(result) + " Kilograms");
            System.out.println();
        }
        
        else if (option == 4)
        {
            result = milesToKilometers(number);
            System.out.println(number + " Miles = " + df.format(result) + " Kilometers");
            System.out.println();
        }
        
        else if (option == 5)
        {
            result = inchesToCentimeters(number);
            System.out.println(number + " Inches = " + df.format(result) + " Centimeters");
            System.out.println();
        }
        
        else if (option == 6)
        {
            result = yardsToMeters(number);
            System.out.println(number + " Yards = " + df.format(result) + " Meters");
            System.out.println();
        }
        
        
        System.out.println();
        main(args);
        
    }
}
        
        
        
        
        
        
        
        
        
        
        