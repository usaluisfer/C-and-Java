// This program, using String operations and assuming that we have a text file,
// finds the number of proper names in the file.
// Proper names are identified by the words having first letter capital.
import java.util.*;

// Assuming a file was opened and called
public class Main
{
    public static void main(String args[])
    {
        // Assuming this came from a file
        String text = "Welcome to Java.";
        
        int count = 0;
        
        // .split() for splitting lines into words
        String[] words = text.split(" ");
        
        for (int i = 0; i < words.length; i++)
        {
            // .trim() for deleting extra spaces
            String word = words[i].trim();
            
            if (word.length() > 0)
            {
                // .charAt(0) for finding first character
                char first = word.charAt(0);
                
                // checking if first letter is uppercase
                if (first >= 'A' && first <= 'Z')
                {
                    count++;
                }
            }
        }
        
        System.out.println("Number of proper names: " + count);
        
    }

    
}