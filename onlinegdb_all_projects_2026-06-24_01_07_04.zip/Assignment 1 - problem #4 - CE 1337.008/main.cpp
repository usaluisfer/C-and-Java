// This program generates a random number and asks the user to guess what the number is.
// If the user’s guess is higher than the random number, the program displays “Too high, try again.” 
// If the user’s guess is lower than the random number, the program displays “Too low, try again.”
// The program uses a while loop for repeating and keeps asking until the number is guessed
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    srand(time(0));    // Seeds random number generator
    int randomNum = rand() % 100 + 1;      // Generating a number between 1 and 100
    int userGuess;
    
    // Asking user for a number guess
    cout << "Guess a number between 1 and 100: ";
    cin >> userGuess;
    
    // When number entered is not the right one, it keeps asking user for the correct one
    while (userGuess != randomNum)
    {
        // If user guess is a greater number than the random one, program gives the user a hint, stating that a lower number should be entered.
        if (userGuess > randomNum)
        {
            cout << "Too high, try again: ";
        }
        
        // Otherwise, if it's less than the random one, it displays a message saying that the number entered is too low
        else if (userGuess < randomNum)
        {
            cout << "Too low, try again: ";
        }
        
        cin >> userGuess;
    }
    
    // Finally, when user guesses the right number
    cout << "You guessed the right number!" << endl;
    
    
    

    return 0;
}