// This program reads in 20 strings from a file (names.txt file).
// Uses Selection Sort to sort the names. Uses readline function for reading from file name.txt, and calls it in a loop to read 20 lines.
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

// Function prototypes
void selectionSort(string[], int);
void displayArray(string[], int);
void readNames(string[], int);

int main()
{
    const int NUM_NAMES = 20;
    string names[NUM_NAMES];

    // Reading the names from the file names.txt
    readNames(names, NUM_NAMES);

    // Displaying unsorted array.
    cout << "Here are the unsorted names:\n";
    cout << "--------------------------\n";
    displayArray(names, NUM_NAMES);

    // Sorting the array
    selectionSort(names, NUM_NAMES);

    // Displaying the sorted array
    cout << "\nHere are the names sorted:\n";
    cout << "--------------------------\n";
    displayArray(names, NUM_NAMES);

    return 0;
}

// Function that reads names from file
void readNames(string names[], int NUM_NAMES)
{
    ifstream inputFile("names.txt");     // Opening file

    // Check if file opens successfully
    if (!inputFile)
    {
        // Error message
        cout << "Error opening file.\n";
        return;
    }

    for (int i = 0; i < NUM_NAMES; i++)
    {
        // Reading each name into the array
        getline(inputFile, names[i]);
    }

    // Closing the file
    inputFile.close();
}


// Function "displayArray" that displays the array
void displayArray(string names[], int NUM_NAMES)
{
    for (int i = 0; i < NUM_NAMES; i++)
    {
        // Displaying array to the user
        cout << names[i] << endl;
    }
}


// Selection Sort function
void selectionSort(string names[], int NUM_NAMES)
{
    // minimum index
    int minIndex;
    // minimum value as string
    string minValue;

    // selection sort for locating smallest element in array and exchanging with element at first position
    for (int start = 0; start < (NUM_NAMES - 1); start++)
    {
        minIndex = start;
        minValue = names[start];

        // Keeps checking for other elements
        for (int index = start + 1; index < NUM_NAMES; index++)
        {
            // Checking if index element is smaller than the minimum value found
            if (names[index] < minValue)
            {
                // Updating minimum value and index
                minValue = names[index];
                minIndex = index;
            }
        }

        // swaping elements if needed
        if (minIndex != start)
        {
            swap(names[minIndex], names[start]);
        }
    }
}
