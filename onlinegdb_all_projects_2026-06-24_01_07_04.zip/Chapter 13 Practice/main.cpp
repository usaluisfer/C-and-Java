// Chapter 13 Practice
#include <iostream>

using namespace std;

class Date
{
    private:
        double month;
        double day;
        double year;
    public:
        void setMonth(double);      // mutators
        void setDay(double);
        void setYear(double);
        
        double getMonth() const;    // accessors
        double getDay() const;
        double getYear() const;
        void getResult() const;
            
};


// Defining member functions
void Date::setMonth(double m)
{
    month = m;
}


void Date::setDay(double d)
{
    day = d;
}

void Date::setYear(double y)
{
    year = y;
}


double Date::getMonth() const
{
    return month;
}


double Date::getDay() const
{
    return day;
}

double Date::getYear() const
{
    return year;
}

void Date::getResult() const
{
    cout << "The formatted date is " << month << "/" << day << "/" << year << endl;
}






int main()
{
    
    double number;               // To hold a number
    double finalDate;            // The final date
    Date *data = nullptr;  // To point to kitchen dimensions
    
    // Dynamically allocate the objects.
    data = new Date;
  
    // Get the kitchen dimensions.
    cout << "What is the month? ";
    cin >> number;                         // Get the month
    data->setMonth(number); // Store 
    
    cout << "What is the day? ";
    cin >> number;                         // Get 
    data->setDay(number);              // Store 
   
    // Get the year
    cout << "What is the year? ";
    cin >> number;                         // Get 
    data->setYear(number);             // Store 
    
   
   
    // Displaying the formatted date
    data->getResult();
    
    
    // Delete the objects from memory.
    delete data;
    
    // Make date a null pointer.
    data = nullptr;    
    
    

    

    return 0;
}