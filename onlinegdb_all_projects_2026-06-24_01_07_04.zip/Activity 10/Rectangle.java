// This is a Rectangle class which has length and width as attributes to the class 
// There are two methods: getArea() and getPerimeter()
// In main user enters a length and a width for the rectangle and then results for area and perimeter are also displayed
import java.util.Scanner;

// Rectangle class
public class Rectangle
{
    // Assigning attributes
    double length;
    double width;
    
    // Constructor
    Rectangle(double l, double w)
    {
        length = l;
        width = w;
    }
    
    // Method for area
    double getArea()
    {
        return length * width;
    }
    
    // Method for perimeter
    double getPerimeter()
    {
        return 2 * (length + width);
    }
    


    // Main
    public static void main (String[] args) 
    {
        Scanner input = new Scanner(System.in);
        
        // Enter length
        System.out.println("Enter length of rectangle: ");
        double l = input.nextDouble();
        
        // Enter width
        System.out.println("Enter width of rectangle: ");
        double w = input.nextDouble();
    
        // Object for Rectangle class
        Rectangle rec = new Rectangle(l, w);
    
        // Displaying calculations for area and perimeter by calling methods
        System.out.println();
        System.out.println("Length: " + rec.length);
        System.out.println("Width: " + rec.width);
        System.out.println("Area: " + rec.getArea());
        System.out.println("Perimeter: " + rec.getPerimeter());
    
    
    }
    
    
}