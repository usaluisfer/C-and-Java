// This program includes a function that accepts an array and the array’s size as arguments.
// The function (expandArray) creates a new array that is twice the size of the argument array. 
// The function copies the contents of the argument array to the new array and initializes the unused elements of the second array with 0.
// The function also returns a pointer to the new array.
#include <iostream>

using namespace std;

// Function prototypes
int *expandArray(int[], int);
void showArray(int[], int);

int main()
{
    // constant int
	const int SIZE = 5;
	int values[SIZE] = {1, 2, 3, 4, 5};

	// Displaying the contents of the array.
	cout << "The contents of the original array are:\n";
	showArray(values, SIZE);
	cout << endl;

	// Making an expanded copy of the array. Calling "expandArray"
	int *expandedArray = expandArray(values, SIZE);

	// Displaying the contents of the new array.
	cout << "The contents of the expanded array are:\n";
	showArray(expandedArray, SIZE * 2);     // Size gets doubled
	cout << endl;
	
	// Free allocated memory
	delete[] expandedArray;

	return 0;
}



// ********************************************************
// The expandArray function accepts an int array and an   *
// int indicating the array's size. The function returns  *
// a pointer to an array that is twice the size of the    *
// array that was passed as an argument. The elements of  *
// the argument array are copied to the new array, and    *
// the remaining elements are set to 0.                   *
// ********************************************************
int *expandArray(int array[], int SIZE) 
{
    // Allocating a new array
    int *newArray = new int[SIZE * 2];    // original size getting doubled
    
    // Copying contents of original array
    for (int i = 0; i < SIZE; i++)
    {
        newArray[i] = array[i];
    }
    
    // Initializing remaining elements with 0
    for (int i = SIZE; i < SIZE * 2; i++)
    {
        newArray[i] = 0;
    }
    
    return newArray;
   
   
}



// Function for showing the arrays to the user
void showArray(int array[], int SIZE)
{
	// Displaying the array
	for (int i = 0; i < SIZE; i++)
	{
	    cout << array[i] << " ";
	}
	
	cout << endl;

	
}
