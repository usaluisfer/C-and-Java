// 
#include <iostream>
#include <iomanip>

using namespace std;

void getOrder(int &spoolsAmount, double &discount, char &indicator, double &customShipping);
double calculateSpoolCharges(int spools, double discount);
void orderSummary(int spoolsOrdered, int spoolsInStock, double discount, double shippingCharge);
double getShippingCharge(char indicator, double customShipping, int spoolsShip);



int main()
{
    int spoolsOrdered;
    int spoolsInStock;
    double discount;
    double customShipping = 15.00;
    char indicator;

    // Get user order information
    getOrder(spoolsOrdered, discount, indicator, customShipping);

    // Ask for spools in stock and validate input
    cout << "Enter the number of spools in stock: ";
    cin >> spoolsInStock;
//    cout << "\t";
    
    while (spoolsInStock < 0) 
    {
        cout << "The number of spools cannot be negative.\n";
//        cin.clear();
//        cin.ignore(10000, '\n');
        cout << "Enter the number of spools in stock: ";
        cin >> spoolsInStock;
//        cout << "\n";
    }
    cout << "     ";

    // Check if there are any spools in stock to fulfill the order
    if (spoolsInStock == 0) 
    {
        cout << "\nSorry, there are currently no spools in stock, ready to ship.\n";
    } 
    
    else
    {
        // Display order summary if stock is available
        orderSummary(spoolsOrdered, spoolsInStock, discount, customShipping);
        cout << "\nThank you, please shop again.\n";
    }

    return 0;
    
    
}



void getOrder(int &spoolsAmount, double &discount, char &indicator, double &customShipping)
{
    cout << "Please enter the number of spools ordered: ";
    cin >> spoolsAmount;
    
    while (spoolsAmount < 1)
    {
        cout << "Invalid input. Spools must be at least one." << endl;
        cin.clear();
        cin.ignore(10000, '\n');
        cin >> spoolsAmount;
    }
    
    cout << "Enter the discount percentage for the customer: ";
    cin >> discount;
    
    while (discount < 0)
    {
        cout << "Invalid input. The percentage cannot be negative." << endl;
        cin.clear();
        cin.ignore(10000, '\n');
        cin >> discount;
    }
    
    cout << "Does the order include custom shipping and handling charges? [Enter Y for Yes or N for No]: ";
    cin >> indicator;
    
    while (indicator != 'y' && indicator != 'Y' && indicator != 'n' && indicator != 'N') 
    {
        cout << "Error, invalid response. The response should be Y for Yes or N for No.\n";
        cout << "Does the order include custom shipping and handling charges? [Enter Y for Yes or N for No]: ";
        cin >> indicator;
    }
    
    
    if (indicator == 'Y' || indicator == 'y')
    {
        cout << "Enter the shipping and handling charge: ";
        cin >> customShipping;
        
        while (customShipping < 0)
        {
            cout << "Error, invalid charges entered. Shipping and handling cannot be negative.\n";
            cin.clear();
            cin.ignore(10000, '\n');
            cin >> customShipping;
        }
    }
    
    if (indicator == 'N' || indicator == 'n')
    {
        return;
    }
    
    
}



double calculateSpoolCharges(int spoolsAmount, double discount)
{

    double totalCost = (134.95 * spoolsAmount);
    double amountOfDiscount = totalCost * (discount / 100);
    return totalCost - amountOfDiscount;
    
}



double getShippingCharge(char indicator, double customShipping, int spoolsAmount) 
{
    double shippingCharges;
    
    if (indicator == 'y' || indicator == 'Y') 
    {
        shippingCharges = customShipping * spoolsAmount;
    } 
    
    else 
    {
        shippingCharges = customShipping * spoolsAmount;
    }
    
    return shippingCharges;
}



void orderSummary(int spoolsOrdered, int spoolsInStock, double discount, double shippingCharge) 
{
    int spoolsShip;
    int spoolsBackOrdered;

    if (spoolsOrdered <= spoolsInStock) 
    {
        spoolsShip = spoolsOrdered;
        spoolsBackOrdered = 0;
        
    } 
    
    else 
    {
        spoolsShip = spoolsInStock;
        spoolsBackOrdered = spoolsOrdered - spoolsInStock;
    }
    
    
    double spoolCharges = calculateSpoolCharges(spoolsShip, discount);
    double shippingCharges = getShippingCharge(shippingCharges, shippingCharge, spoolsShip);
    double totalCharges = spoolCharges + shippingCharges;

    // Display order summary
    cout << "\t";
    cout << "Order Summary\n" << "==============================\n";
    
    if (spoolsBackOrdered > 0) 
    {
        cout << spoolsBackOrdered << " spools are on back order.\n";
    }
    
    cout << spoolsShip << " spools are ready to ship.\n";
    
    if (discount > 0)
    {
        cout << "The charges for " << spoolsShip << " spools (including a " << fixed << setprecision(1) << discount << "% discount): $";
    }
    
    else
    {
        cout << "The charges for " << spoolsShip << " spools : $";
    }
    
    cout << fixed << setprecision(2) << spoolCharges << "\n";
    cout << "Shipping and handling for " << spoolsShip << " spools: $" << shippingCharges << "\n" << "The total charges (incl. shipping & handling): $" << totalCharges << "\n";
}





