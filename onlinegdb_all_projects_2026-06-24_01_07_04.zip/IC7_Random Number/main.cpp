// This program generates two random numbers.
// One number is between 43 and 87. The second number is between 35 and 93.
// At the end, it displays the sum of the two random numbers.
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    // Declaring variables for random numbers between 43 and 87
    int min1 = 43;
    int max1 = 87;
    
    int random_number1;
    
    // Getting the system time
    unsigned seed = time(0);
    // Seed the random number generator
    srand(seed);
    
    // Calculating random number using rand()
    random_number1 = (rand() % (max1 - min1 + 1)) + min1;
    
    
    // Declaring variables for random numbers between 35 and 93
    int min2 = 35;
    int max2 = 93;
    
    int random_number2;
    
    // Calculating second random number using rand()
    random_number2 = (rand() % (max2 - min2 + 1)) + min2;
    
    // Finding the sum of both random numbers
    int sum;
    sum = random_number1 + random_number2;
    
    // Displaying the sum to the screen
    cout << sum;



    return 0;
}