#include <iostream>
#include <iomanip>
using namespace std;

// Function to get order details from the user
void getOrder(int &numSpools, double &discount, char &customShipping, double &shippingCharge) {
    // Get number of spools ordered
    do {
        cout << "Please enter the number of spools ordered: ";
        cin >> numSpools;
        if (numSpools < 1) {
            cout << "Error, invalid input. Spools must be at least one.\n";
        }
    } while (numSpools < 1);
    
    // Get discount percentage
    do {
        cout << "Enter the discount percentage for the customer: ";
        cin >> discount;
        if (discount < 0) {
            cout << "Error, invalid input. The percentage cannot be negative.\n";
        }
    } while (discount < 0);
    
    // Get custom shipping info
    do {
        cout << "Does the order include custom shipping and handling charges? [Enter Y for Yes or N for No]: ";
        cin >> customShipping;
        if (customShipping != 'Y' && customShipping != 'y' && customShipping != 'N' && customShipping != 'n') {
            cout << "Error, invalid response. The response should be Y for Yes or N for No.\n";
        }
    } while (customShipping != 'Y' && customShipping != 'y' && customShipping != 'N' && customShipping != 'n');
    
    // Get custom shipping charge if applicable
    if (customShipping == 'Y' || customShipping == 'y') {
        do {
            cout << "Enter the shipping and handling charge: ";
            cin >> shippingCharge;
            if (shippingCharge < 0) {
                cout << "Error, invalid charges entered. Shipping and handling cannot be negative.\n";
            }
        } while (shippingCharge < 0);
    }
}

// Function to calculate spool charges after applying discount
double calculateSpoolCharges(int numSpools, double discount) {
    const double pricePerSpool = 134.95;
    double totalCharges = numSpools * pricePerSpool;
    double discountAmount = totalCharges * (discount / 100);
    return totalCharges - discountAmount;
}

// Function to calculate shipping charges
double calculateShippingCharges(int numSpools, char customShipping, double customShippingCharge) {
    const double standardShippingCharge = 15.00;
    if (customShipping == 'Y' || customShipping == 'y') {
        return numSpools * customShippingCharge;
    } else {
        return numSpools * standardShippingCharge;
    }
}

// Function to print the order summary
void orderSummary(int numSpoolsOrdered, int numSpoolsInStock, double discount, char customShipping, double customShippingCharge) {
    if (numSpoolsInStock == 0) {
        cout << "Sorry, there are currently no spools in stock, ready to ship.\n";
        return;
    }
    
    int spoolsReadyToShip = (numSpoolsOrdered <= numSpoolsInStock) ? numSpoolsOrdered : numSpoolsInStock;
    int spoolsBackOrdered = numSpoolsOrdered - spoolsReadyToShip;
    
    // Calculate charges
    double chargesForSpools = calculateSpoolCharges(spoolsReadyToShip, discount);
    double shippingCharges = calculateShippingCharges(spoolsReadyToShip, customShipping, customShippingCharge);
    double totalCharges = chargesForSpools + shippingCharges;
    
    // Display order summary
    cout << "\tOrder Summary\n";
    cout << "==============================\n";
    
    if (spoolsBackOrdered > 0) 
    {
        cout << spoolsBackOrdered << " spools are on back order.\n";
    }
    
    cout << spoolsReadyToShip << " spools are ready to ship.\n";
    
    
    if (discount > 0)
    {
        cout << "The charges for " << spoolsReadyToShip << " spools (including a " << fixed << setprecision(1) << discount << "% discount): $" << fixed << setprecision(2) << chargesForSpools << endl;

    }
    else
    {
        cout << "The charges for " << spoolsReadyToShip << " spools : $" << endl;
    }
    
    cout << "Shipping and handling for " << spoolsReadyToShip << " spools: $" << fixed << setprecision(2) << shippingCharges << endl;

    cout << "The total charges (incl. shipping & handling): $" << fixed << setprecision(2) << totalCharges << endl;

    cout << "\nThank you, please shop again.\n";
}

int main() {
    int numSpoolsOrdered, numSpoolsInStock;
    double discount, shippingCharge;
    char customShipping;
    
    // Get user input
    getOrder(numSpoolsOrdered, discount, customShipping, shippingCharge);

    // Validate number of spools in stock
    do {
        cout << "Enter the number of spools in stock: ";
        cin >> numSpoolsInStock;
        if (numSpoolsInStock < 0) {
            cout << "The number of spools cannot be negative.\n";
        }
    } while (numSpoolsInStock < 0);

    // Print the order summary
    orderSummary(numSpoolsOrdered, numSpoolsInStock, discount, customShipping, shippingCharge);
    
    return 0;
}
