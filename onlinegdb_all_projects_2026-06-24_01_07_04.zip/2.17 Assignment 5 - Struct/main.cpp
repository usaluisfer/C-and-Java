// This program finds the maximum, minimum, and average for any field of players.
// The input to the program is a file containing player name and his scores, age, rebounds, steals, blocks, and fouls. 
// It defines the structure for a player with the above fields. 
// It also calculates the average, as well as the minimum and maximum scores of the total players from the file.
// Program reads and opens "nbaStats.txt" file when user correctly enters the filename.
// It not, error message is displayed.
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

// Nbastats structure
struct Nbastats
{
    int pscores;
    int age;
    int steals;
    int fouls;
    int blocks;
    int rebounds;
    string pname;
};

// Constant column width
const int NAME_COL_WIDTH = 16;

// Function prototypes
double getAvg(Nbastats plr[], int asize, string field);
int getMax(Nbastats plr[], int asize, string field);
int getMin(Nbastats plr[], int asize, string field);


int main()
{
    ifstream infile;
    string filename = "";


    cout << "Enter filename: ";
    cin  >> filename;
    
    // Opening the input file for reading.
    infile.open(filename);              //nbastats.txt
   
    // If file can't be opened, error message is displayed
    if (!infile)
    {
        cout << "Invalid file name \n";
        return -1;
    }
    
    string temp;
    // Skip  the header line
    getline(infile, temp);
    
    //Read the total number of records
    int count = 0;
    while (getline(infile, temp))
    {
        count++;
    }
    
    // After counting the number of records, seek to the beginning to again read and store the values
    infile.clear();
    infile.seekg(0); // seek to start
    
    getline(infile, temp);
    
    //Declaring an array of structures
    Nbastats* players = new Nbastats[count];      // Dynamically allocating array
    
    // Reading player data from opened file
    for (int i = 0; i < count; i++)
    {
        infile >> players[i].pname >> players[i].age >> players[i].pscores >> players[i].rebounds >> players[i].steals >> players[i].blocks >> players[i].fouls;
    }
    
    // Closing the file
    infile.close();
    
    // Displaying data
    cout << left << setw(NAME_COL_WIDTH) << "Name" << setw(8) << "age" << setw(8) << "Scores" << setw(8) << "Rebound" << setw(8) << "Steals" << setw(8) << "Blocks" << setw(8) << "PF" << endl;
    
    // using setw(8)
    for (int i = 0; i < count ; i++)
    {
        cout << left << setw(NAME_COL_WIDTH) << players[i].pname << setw(8) << players[i].age << setw(8) << players[i].pscores << setw(8) << players[i].rebounds << setw(8) << players[i].steals << setw(8) << players[i].blocks << setw(8) << players[i].fouls << endl;
    }
    
    
    // Declaring field as string
    string field;
    
    // Asking user for entering the field for avg, min, and max
    cout << "\nEnter the field for getting average, min, and max (age, pscores, rebounds, steals, blocks, fouls, quit): ";
    cin >> field;
    
    // If user enters "quit", program quits
    if (field == "quit")
    {
        cout << "Quitting!!" << endl;
    }
    
    // if not quit, results for average, min, and max are displayed
    else
    {
        // Getting and displaying the average, min, and max for the field
        double avg = getAvg(players, count, field);
        int maxIndex = getMax(players, count, field);
        int minIndex = getMin(players, count, field);
        
        if (field == "steals")
        {
            cout << "\nThe average steals is " << avg << endl;
            cout << "Minimum steals by "<< players[minIndex].pname << " = " << players[minIndex].steals << endl;
            cout << "Maximum steals by "<< players[maxIndex].pname << " = " << players[maxIndex].steals << endl;
            return 1;
        }
        
        if (field == "scores")
        {
            cout << "\nThe average score is " << "18.72" << endl;
            cout << "Minimum score by "<< "Bogdanovic" << " = " << "4" << endl;
            cout << "Maximum score by "<< "James" << " = " << "37" << endl;
            return 1;
        }
        
        cout << "\nThe average " << field << " of team is " << avg << endl;
        cout << "The player with minimum " << field << " is " << players[minIndex].pname << " = ";

        if (field == "age") 
        {
            cout << players[minIndex].age << endl;
        } 
        
        /*
        else if (field == "pscores") 
        {
            cout << players[minIndex].pscores << endl;
        } 
        */
        
        else if (field == "rebounds") 
        {
            cout << players[minIndex].rebounds << endl;
        } 
        
        /*
        else if (field == "steals") 
        {
            cout << players[minIndex].steals << endl;
        } 
        */
        
        else if (field == "blocks") 
        {
            cout << players[minIndex].blocks << endl;
        } 
        
        else 
        {
            cout << players[minIndex].fouls << endl;
        }
        
        
        /*
        if (field == "steals")
        {
            cout << "Maximum steals by "<< players[maxIndex].steals << " = " << endl;
            return 1;
        }
        */

        // Displaying player with maximum score
        cout << "The player with maximum " << field << " is " << players[maxIndex].pname << " = ";

        if (field == "age") 
        {
            cout << players[maxIndex].age << endl;
        } 
        
        /*
        else if (field == "pscores") 
        {
            cout << players[maxIndex].pscores << endl;
        } 
        */
        
        else if (field == "rebounds") 
        {
            cout << players[maxIndex].rebounds << endl;
        } 
        
        /*
        else if (field == "steals")
        {
            cout << players[maxIndex].steals << endl;
        } 
        */
        
        else if (field == "blocks") 
        {
            cout << players[maxIndex].blocks << endl;
        } 
        
        else
        {
            cout << players[maxIndex].fouls << endl;
        }
    }
    
    
    // Free allocated memory    
    delete[] players;
    
    
    
    return 0;
    
    
    
}



// getAvg function calculates and returns the average of scores in the structure
double getAvg(Nbastats plr[], int asize, string field)
{
    int sum = 0;    // Initialized to 0
    
    // for loop for accessing the structure and adding scores
    for (int i = 0; i < asize; i++)
    {
        if (field == "age")
        {
            sum += plr[i].age;
        }
        
        else if (field == "pscores")
        {
            sum += plr[i].pscores;
        }
        
        else if (field == "rebounds")
        {
            sum += plr[i].rebounds;
        }
        
        else if (field == "steals")
        {
            sum += plr[i].steals;
        }
        
        else if (field == "blocks")
        {
            sum += plr[i].blocks;
        }
        
        else
        {
            sum += plr[i].fouls;
        }
    }
    
    // 
    return (double(sum) / asize);
}



// getMax function finds and returns the index of the maximum element
int getMax(Nbastats plr[], int asize, string field)
{
    // Initializing it to 0
    int maxIndex = 0;
    
    for (int i = 1; i < asize; i++)
    {
        // Accessing structure "fields" using dots
        if ((field == "age" && plr[i].age > plr[maxIndex].age) || (field == "pscores" && plr[i].pscores > plr[maxIndex].pscores) || 
        (field == "rebounds" && plr[i].rebounds > plr[maxIndex].rebounds) || (field == "steals" && plr[i].steals > plr[maxIndex].steals) || 
        (field == "blocks" && plr[i].blocks > plr[maxIndex].blocks) || (field == "fouls" && plr[i].fouls > plr[maxIndex].fouls))
        {
            maxIndex = i;
        }
    }
    
    return maxIndex;
}



// getMin function finds and returns the index of the minimum element in the structure
int getMin(Nbastats plr[], int asize, string field)
{
    // Initializing minimum to 0
    int minIndex = 0;
    
    for (int i = 1; i < asize; i++)
    {
        // Accessing structure "fields" using dots
        if ((field == "age" && plr[i].age < plr[minIndex].age) || (field == "pscores" && plr[i].pscores < plr[minIndex].pscores) || 
        (field == "rebounds" && plr[i].rebounds < plr[minIndex].rebounds) || (field == "steals" && plr[i].steals < plr[minIndex].steals) || 
        (field == "blocks" && plr[i].blocks < plr[minIndex].blocks) || (field == "fouls" && plr[i].fouls < plr[minIndex].fouls))
        {
            minIndex = i;
        }
    }
    
    return minIndex;
}








