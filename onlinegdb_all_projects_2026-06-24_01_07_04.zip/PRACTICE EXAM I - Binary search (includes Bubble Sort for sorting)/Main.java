// Binary search (includes Bubble Sort for sorting)
import java.util.Scanner;

public class Main
{
    // Bubble Sort method
    public static void bubbleSort(int[] matrix, int size)
    {
        for (int i = 0; i < size - 1; i++)
        {
            for (int j = 0; j < size - 1 - i; j++)
            {
                if (matrix[j] > matrix[j + 1])
                {
                    int temp = matrix[j];
                    matrix[j] = matrix[j + 1];
                    matrix[j + 1] = temp;
                }
            }
        }
    }
    
    
    
    // Binary search method
    public static int binarySearch(int[] matrix, int key)
    {
        int low = 0;
        int high = matrix.length - 1;
        
        while(high >= low)
        {
            int mid = (low + high) / 2;
            
            if (key < matrix[mid])
            {
                high = mid - 1;
            }
            
            else if (key == matrix[mid])
            {
                return mid;
            }
            
            else 
            {
                low = mid + 1;
            }
        }
        
        return -1-low;
        
        
        
    }
    
    
	public static void main(String[] args)
	{
	    Scanner input = new Scanner(System.in);
	    
	    System.out.println("Enter number of elements: ");
	    int size = input.nextInt();
	    
	    // Creating array
	    int[] matrix = new int[size];
	    
	    // Filling the array
	    System.out.println("Enter " + size + " elements:");
	    
	    for (int i = 0; i < size; i++)
	    {
	        matrix[i] = input.nextInt();
	    }
	    
	    // Binary search needs elements to be sorted
	    bubbleSort(matrix, size);
	    
	    System.out.println("Sorted array:");
        for (int i = 0; i < size; i++)
        {
            System.out.print(matrix[i] + " ");
        }
        
        System.out.println();
	    
	
	    // User enters a key element for binary search
	    System.out.println();
	    System.out.print("Enter value to search: ");
        int key = input.nextInt();
	    
	    
	    
	    System.out.println();
		System.out.println("Element was found at index " + binarySearch(matrix, key));
	
		
		
		
	}
}
