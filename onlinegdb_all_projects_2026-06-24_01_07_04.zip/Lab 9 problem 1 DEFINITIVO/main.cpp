// This program calculates the distance an object falls in a specified number of seconds when dropped on earth or on the moon.
//The distance travelled is a function of the acceleration due to gravity and the time of the fall. The formula for calculating the distance of the fall in meters is:
// Distance = 0.5 x g x t^2
// The program gets the time of the fall from the user in seconds.
// Uses double variables/constants
// It also consists of three called functions (also the main), getSeconds, findEarthFallDist, and findMoonFallDist.
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// double constants declared
const double earthAcceleration = 9.81;     // acceleration due to gravity on Earth in meters/sec^2
const double moonAcceleration = 1.625;     // acceleration due to gravity on Earth's moon in meters/sec^2

// time in seconds
//double timeOfFall;

// getSeconds function prompts the user for time of the fall in seconds. It checks if value entered is 0 or greater, otherwise an error is displayed and asks again for a new value.
double getSeconds()    // Passing by reference (&)
{
	double timeOfFall;
	// Asking user for time
	cout << "Please enter the time of the fall (in seconds): ";
	cin >> timeOfFall;
//	cout << endl;
//    return timeOfFall;    // returning value

	// If time is less than zero, error message is displayed
	while (timeOfFall < 0)
	{
		cout << "Error. The time must be at least zero." << endl;
		cout << "Please enter the time of the fall (in seconds): ";    // Asking the user again
		cin >> timeOfFall;
		cout << endl;
//        return timeOfFall;
	}
	return timeOfFall;
}

// findEarthFallDist function calculates and returns the distance the object would fall on Earth given the time of the fall in seconds as the only argument.
double findEarthFallDist(double timeOfFall)    // double timeOfFall as argument
{
	// Calculating Earth's distance using the formula: Distance = 0.5 x g x t^2
	double earthDistance = 0.5 * earthAcceleration * timeOfFall * timeOfFall;
	return earthDistance;     // returning the Earth's distance
}

// findMoonFallDist function calculates and returns the distance the object would fall on the Earth's moon given the time of the fall in seconds as the only argument.
double findMoonFallDist(double timeOfFall)     // double timeOfFall as argument
{
	// Calculating Earth's moon distance using the formula: Distance = 0.5 x g x t^2
	double moonDistance = 0.5 * moonAcceleration * timeOfFall * timeOfFall;
	return moonDistance;      // returning Earth's moon distance
}

// int main function displays the results after value was received by the getSeconds function and after calculations were done in earthDistance and moonDistance functions
int main()
{
	// Calling the getSeconds function
//    getSeconds(timeOfFall);
    double timeOfFall = getSeconds();

	// Calling the earthDistance function and displaying the distance to the user according to the seconds entered
	double earthDistance = findEarthFallDist(timeOfFall);
	// using three digits of precision to the right of the decimal point for the distance
	// one digit to the right of the decimal point for the time
	cout << endl << "The object traveled " << fixed << setprecision(3) << earthDistance << " meters in " << fixed << setprecision(1) << timeOfFall << " seconds on Earth." << endl;

	// Calling the moonDistance function and displaying the distance to the user according to the seconds entered
	double moonDistance = findMoonFallDist(timeOfFall);
	cout << "The object traveled " << fixed << setprecision(3) << moonDistance << " meters in " << fixed << setprecision(1) << timeOfFall << " seconds on the Moon." << endl;


	return 0;
}