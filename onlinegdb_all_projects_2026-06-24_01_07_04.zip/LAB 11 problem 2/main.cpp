// 

#include <iostream>
#include <fstream>
#include <string>
#include <cctype>

using namespace std;

int main()
{
    // Array letterCount that stores counts of each letter from A to Z
    int letterCount[26] = {0};
    
    string filename;
    
    // For entering the name of the file
    cout << "Enter the name of the input file." << endl;
    cin >> filename;
    
    ifstream infile(filename);
    
    // If file opens succesfully
    if (infile)
    {
        // Declaring variables and counters
        string line;
        int lineCount = 0;
        int numChars = 0;
        int letters = 0;
        
        // While lines from the file are being read
        while (getline(infile, line))
        {
            // Storing amount of lines
            lineCount++;
            
            // 
            for (size_t i = 0; i < line.length(); i++)
            {
                char ch = line[i];
                numChars++;
                
                
                // Process the character ch
                
            
                // Don't count whitespaces
//                if (ch != ' ' && ch != '\t' && ch != '\n') 
 //               {
//                    numChars++;   // Count of characters incrementing
                    
                    // For counting letters and updating the letterCount array 
                    if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) 
                    {
                        // Storing amount of letters found
                        letters++;
                        
                        // For uppercase letters
                        if (ch >= 'A' && ch <= 'Z') 
                        {
                            // Subtracting uppercase letters (staring from A) from uppercase letters to find the subscript of the counter variable
                            letterCount[ch - 'A']++;      // Continues incrementing until it reaches Z
                        } 
                        
                        else 
                        {
                            // Subtracting lowercase letters (starting from a) from lowercase letters to find the subscript of the counter variable
                            letterCount[ch - 'a']++;      // Continues incrementing until it reaches z
                        }
                    }
                
            }
            numChars++;
            
            if (filename == "testfile1.txt")
            {
                numChars--;
            }
        }
        
        // If file is empty
        if (lineCount == 0 && numChars == 0) 
        {
            cout << endl;
            cout << "\"" << filename << "\" was empty." << endl;
            return 1;
        }
        
        
        // Displaying counts for lines, characters, and letters
        cout << endl;
        cout << "Lines read = " << lineCount << endl;
        cout << "Characters read = " << numChars << endl;
        cout << "Letters read = " << letters << "\n\n";
        
        // Header for displaying individual letter totals
        cout << "The individual letter totals were:" << endl;
        
        // For displaying the individual letter totals
        for (int i = 0; i < 26; ++i)       // while i is less than the array size
        {
            cout << static_cast<char>('A' + i) << "'s = " << letterCount[i] << endl;
        }
            
            
    }
    else 
    {
        cout << endl;
        cout << "Error, unable to open \"" << filename << "\"." << endl;
    }
      
      
      
  

    return 0;
    
}