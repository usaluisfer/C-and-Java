// This program asks the user to enter a month (letting the user enter an integer in the range of 1 through 12) and the year. 
// Then displays the number of days in that month
#include <iostream>
using namespace std;

int main()
{
    int month;
    int days;
    int year;
    
    cout << "Enter a month (1-12): ";   // Letting user enter a month inside the allowed range
    cin >> month;
    
    // if a number outside the range was entered, it asks for a month again
    while (month < 1 || month > 12)
    {
        cout << "Enter a month between the range(1-12): ";
        cin >> month;
    }
    
    // User is asked for a specific year
    cout << "Enter a year: ";
    cin >> year;
    
    if (month == 2)    // Number 2 for the month of February 
    {
        if ((year % 100 == 0 && year % 400 == 0) || (year % 100 != 0 && year % 4 == 0))
        {
            days = 29;   // February in a leap year (29 days)
        }
        else
        {
            days = 28;   // Normal February
        }
    }
    
    // For the months that contain 30 days (April, June, September, and November)
    else if (month == 4 || month == 6 || month == 9 || month == 11)
    {
        days = 30;
    }
    
    // The rest of the months (which have 31 days)
    else
    {
        days = 31;
    }
    
    // Displaying total days in the month of the year entered
    cout << days << " days" << endl;

    return 0;
}