// Transpose of given matrix:
// {2, 3, 7},
// {8, 9, 2},
// {7, 5, 1}

// Using a separate method for transpose

import java.util.Scanner;

public class Main 
{
    public static int[][] transpose(int[][] matrix)
    {
        int rows = matrix.length;
        int columns = matrix[0].length;
        
        int[][] transposed = new int[columns][rows];
        
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                transposed[j][i] = matrix[i][j];
            }
        }
        
        return transposed;
    }
    
    
    
    
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        int matrix[][] = {
            {2, 3, 7},
            {8, 9, 2},
            {7, 5, 1}
        };
        
        // Initializing an array for storing the final transposed matrix
        int[][] result = transpose(matrix);
        
        System.out.println("Transpose of the matrix:");
        System.out.println();
        
        for (int i = 0; i < result.length; i++)
        {
            for (int j = 0; j < result[i].length; j++)
            {
                System.out.print(result[i][j] + " ");
            }
            
            System.out.println();
        }
        
    }
}