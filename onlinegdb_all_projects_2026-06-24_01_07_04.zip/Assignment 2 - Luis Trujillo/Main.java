// This program performs the Tic-Tac-Toe game, which allows two players to take turns (X and O)
// It uses a 2D array (3x3) which is initially filled with empty spaces
// There is a method (playerMoves) that allows the players to enter their moves
// There is a method (boardStatus) that displays the board after each move is made
// There is also a method (checkWin) that checks for a winning condition (horizontally, vertically, or diagonal)
// Another method for Draw Condition (checkDraw) is also implemented
// If an invalid move is entered (like a repeated move in the same place), an error message is displayed and the player can then enter a valid choice
import java.util.Scanner; 

public class Main
{
    // Method for displaying the current state of the game board
    public static void boardStatus(char [][] board)
    {
        System.out.println("-------------");
        
        for (int i = 0; i < 3; i++)
        {
            System.out.print("| ");
            
            for (int j = 0; j < 3; j++)
            {
                System.out.print(board[i][j] + " | ");
            }
            
            System.out.println("\n-------------");
        }
    }
    
    
    // Method for taking input from user
    public static void playerMoves(char [][] board, Scanner input, char player)
    {
        int row;
        int column;
        
        // while (true) makes sure player enters a valid move
        while (true)
        {
            System.out.println("Player " + player + ", enter row and column (0-2)");
            row = input.nextInt();
            column = input.nextInt();
            
            // making sure that a correct row and column inside the board has been chosen
            // also makes sure a move was made inside an empty spot
            if (row >= 0 && row <= 2 && column >= 0 && column <= 2 && board[row][column] == ' ')
            {
                board[row][column] = player;
                break;
            }
            
            // If move is invalid, it displays error message and lets the user enter again another move
            else
            {
                System.out.println();
                System.out.println("Invalid move, try again!");
                System.out.println();
            }
        }
        
        // displaying updated board after each move
        boardStatus(board);
            
    }
    
    
    // Method that checks if a player won
    public static char checkWin(char [][] board)
    {
        for (int i = 0; i < 3; i++)
        {
            // Checking win by evaluating each row
            if (board[i][0] != ' ' && board[i][0] == board[i][1] && board[i][1] == board[i][2])
            {
                return board[i][0];
            }
                
            // Checking win by evaluating each column
            if (board[0][i] != ' ' && board[0][i] == board[1][i] && board[1][i] == board[2][i])
            {
                return board[0][i];
            }
            
        }
        
        // Checking win by evaluating diagonals
        // First from top left to bottom right
        if (board[0][0] != ' ' && board[0][0] == board[1][1] && board[1][1] == board[2][2])
        {
            return board[0][0];
        }
        
        // Now from top right to botton left
        if (board[0][2] != ' ' && board[0][2] == board[1][1] && board[1][1] == board[2][0])
        {
            return board[0][2];
        }
        
        return ' ';
    }
    
        
    // Method for determining if no one won and if all the spaces were filled, resulting in a draw
    public static char checkDraw(char [][] board)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                // If there are still empty spaces, its not a draw 
                if (board[i][j] == ' ')
                {
                    return ' ';
                }
            }
        }
        
        // Otherwise returns 'D' for draw
        return 'D';
    }
    
    

    
    // Main
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        // 2D array declaration
        char[][] board = new char[3][3];
        
        for (int i = 0; i < board.length; i++)
        {
            for (int j = 0; j < board.length; j++)
            {
                board[i][j] = ' ';     // Adding empty spaces
            }
        }
        
        int moves = 0;
        char winner = ' ';
        
        // While the moves are inside the allowed range (3x3 board)
        while (moves < 9 && winner == ' ')
        {
            // player X starts (even moves)
            if (moves == 0 || moves == 2 || moves == 4 || moves == 6 || moves == 8)
            {
                playerMoves(board, input, 'X');
            }
            
            // player O (odd moves)
            else 
            {
                playerMoves(board, input, 'O');
            }
            
            // Calling the checkWin method
            winner = checkWin(board);
            moves++;
        }
        
        // if the spot where a player was declared a winner is not an empty space, a message is printer to the winner
        if (winner != ' ')
        {
            System.out.println("Player " + winner + " wins!");
        }
        
        // If all spots where filled and no winner was declared, it was a draw
        else if (checkDraw(board) == 'D')
        {
            System.out.println("Its a draw!");
        }
        
        input.close();
        
        
        
    }
    
    
}

