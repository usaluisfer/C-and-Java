
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    string s;
    getline(cin, s);
    
    int word = 1;
    for (int l = 0; l < s.length(); l++)
    {
        if (s[1] == ' ')
        {
            word++;
        }
    }
    cout << "The number of words is " << word << endl;

    return 0;
}