//
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
   // strinng for storing the names of the files for input and output
   string filename[] = {"salesb.txt", "salesb2.txt", "salesb2b.txt", "salesb3.txt", "salesb4.txt", "salesb5.txt", "salesb6.txt"};
//   string outputFiles[] = {"saleschart.txt"};
   ofstream outputFile;
   string inputFileName;
   
   
   for (int i = 0; i < 7; i++)
   {
      ifstream inputFile(filename[i]);  // For input from a file
//      ofstream outputFile(outputFiles[i]);    // For output to a file
     
      
      cout << "Please enter the input file name." << endl;
      cin >> inputFileName;
      
      inputFile.open(inputFileName.c_str());
      if (!inputFile) 
      {
        cout << "\"" << inputFileName << "\" could not be opened." << endl;
        return 1;
      }
      
      unsigned int number;
      long long int sales;
      
      
//      inputFile.open(filename[i]);
      
//      if (inputFile)
//      {
          while (inputFile >> number >> sales) 
          {
              // Validate store number (1 to 99 inclusive)
              if (number < 1 || number > 99) 
              {
                  cout << number << " is not in the range 1 through 99." << endl;
                  continue; // Skip to next record
              }

              // Validate sales (non-negative)
              if (sales < 0) 
              {
                  cout << "Skipped store #" << number << " due to invalid sales value." << endl;
                  continue; // Skip to next record
              }
          
              if (!outputFile.is_open()) 
              {
                  outputFile.open("saleschart.txt");
                  if (!outputFile) 
                  {
                      cout << "The output file \"saleschart.txt\" could not be opened." << endl;
                      inputFile.close();
                      return 1;
                  }
          
          
          
          
          
          
//          outputFile.open(outputFiles[i]);
//            outputFile.open("saleschart.txt");
          
//          if (outputFile)
//          {
              outputFile << "SALES BAR CHART\n";
              outputFile << "(Each * equals 5,000 dollars)\n";
              }
          
          long long int starCount = sales / 5000;

          // Write store number and corresponding bar chart line to the output file
          outputFile << "Store " << (number < 10 ? " " : "") << number << ": ";
          for (int i = 0; i < starCount; ++i) 
          {
            outputFile << "*";
          }
          outputFile << endl;
              
          
          
          }
          
          // Close files
          inputFile.close();
   
          if (outputFile.is_open()) 
          {
              outputFile.close(); // Close output file only if it was opened
          }
   }
   

    return 0;
}
          
          

              
//              inputFile.close();
//              outputFile.close();
//          }   
/*          
          else
          {
              cout << "Error opening the file.\n";
              inputFile.close();
          }
          outputFile.close();
    
      }
      
      
      
         cout << "Error opening the file.\n"; 
      
      }
   }
   
   return 0;
}
*/