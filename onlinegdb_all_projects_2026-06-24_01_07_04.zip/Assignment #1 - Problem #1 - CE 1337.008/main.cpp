// This program asks the user to enter a number of seconds,
// According to the amount of seconds entered, it outputs the convertion in minutes (if 60 or greater), hours (if 3600 or greater), or days (if 86400 or greater)
#include <iostream>
using namespace std;

int main()
{
    double number;    // Declaring number variable
    cout << "Enter a number of seconds: ";    // Asking user for entering a seconds amount
    cin >> number;
    
    if (number >= 60)    // If amount entered is greater than or equal to 60, it calculates and gives the amount of minutes
    {
        double minutes = number / 60;    // Seconds entered divided by total seconds in a minute.
        cout << "There are " << minutes << " minutes in " << number << " seconds." << endl;
    }
    
    if (number >= 3600)    // If amount entered is greater than or equal to 3600, it calculates and gives the amount of hours
    {
        double hours = number / 3600;    // For getting hours, number of seconds entered was divided by the amount of seconds in an hour.
        cout << "There are " << hours << " hours in " << number << " seconds." << endl;
    }
    
    if (number >= 86400)    //If amount entered is greater than or equal to 86400, it calculates and gives the amount of days
    {
        double days = number / 86400;    // For getting days, number of seconds entered was divided by the total amount of seconds in a day (86400).
        cout << "There are " << days << " days in " << number << " seconds." << endl;
    }

    return 0;
}