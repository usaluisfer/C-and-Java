// This program dynamically allocates an array of pointers called arrayP.
// The first element of arrayP points to the address of the first element of array1 and so on.
// It dereferences the pointers stored in arrayP for printing the contents of where the pointers in arrayP are pointing to.
// selectionSort function sorts the contents of arrayP.
// Finally, the sorted array with addresses and values is printed.
#include <iostream>

using namespace std;

void selectionSort(int **, int);

int main()
{ 
    const int SIZE = 10; 
    int array1[SIZE] = {10,25,4,15,21,12,32,18,3,14}; 

    // Declaring arrayP 
//    int **arrayP = nullptr;
    
    // Allocating arrayP using new 
    int **arrayP = new int *[SIZE];
 
    //Initializing arrayP to addresses of each element of array1 
    for (int i = 0; i < SIZE; i++)
    {
        arrayP[i] = &array1[i];
    }
    
    // Printing arrayP, (the addresses and the values that they point to)
    cout << "Before sorting: " << endl;

    for (int i = 0; i < SIZE; i++)
    {
        cout << "Address: " << arrayP[i] << " " << "Value: " << *arrayP[i] << endl;
    }

    // Calling the selectionSort function for sorting the values and addresses
    selectionSort(arrayP, SIZE);
    
    
    // Printing sorted arrayP, the addresses and the values that they point to 
    cout << endl << "Sorted values: " << endl;
    
    for (int i = 0; i < SIZE; i++)
    {
        cout << "Address: " << arrayP[i] << " " << "Value: " << *arrayP[i] << endl;
    }
    
    
    
    //deallocate arrayP
    delete[] arrayP;
    arrayP = nullptr;
   
    return 0;

} 

    
    
// selectionSort for sorting the contents in arrayP    
void selectionSort(int **array, int SIZE) 
{

    // Sorting array using selection sort
    for (int start = 0; start < (SIZE - 1); start++)
    {
        // min index
        int minIndex = start;
        
        // Keeps checking for other elements
        for (int index = start + 1; index < SIZE; index++)
        {
           // Checking if index element is smaller than the minimum value found
            if (*array[index] < *array[minIndex])
            {
                // Updating minimum value and index
                minIndex = index;
            }
        }
        // swaping elements
        swap(array[start], array[minIndex]);
    }
}

