// This program converts and prints the transpose of a given 3x3 array
// It swaps the original row index with the column index 
// The original matrix given contains: 
//{1, 2, 3}
//{4, 5, 6}
//{7, 8, 9}
public class Main
{
	public static void main(String[] args) 
	{
	    // Matrix declaration
		int[][] matrix = {
		    {1, 2, 3},
		    {4, 5, 6},
		    {7, 8, 9}
		};
		
		// 3x3 matrix
		int rows = 3;
		int columns = 3;
		
		// Transpose matrix declaration
		int[][] transpose = new int[columns][rows];
		
		for (int i = 0; i < rows; i++)
		{
		    for (int j = 0; j < columns; j++)
		    {
		        // This swaps the row index with the column index
		        transpose[j][i] = matrix[i][j];
		    }
		}
		
		// Displaying transpose 
		System.out.println("Transpose: ");
		System.out.println();
		
		// Now i is column and j is row
		for (int i = 0; i < columns; i++)
		{
		    for (int j = 0; j < rows; j++)
		    {
		        System.out.print(transpose[i][j] + " ");
		    }
		    
		    System.out.println();
		}
		
		
		
		
		
	}
}
