// Summing elements by column after getting input from user
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		
		// Prompt user for array dimensions
        System.out.println("Enter # of rows: ");
        int row = input.nextInt();
        
        System.out.println("Enter # of columns: ");
        int column = input.nextInt();
        
		int matrix[][] = new int[row][column];
		
		System.out.println();
		
		
		// User enters array elements
		System.out.println("Enter " + row + " rows and " + column + " columns: ");
		System.out.println();
		
        for (int i = 0; i < row; i++) 
        {
            for (int j = 0; j < column; j++) 
            {
                matrix[i][j] = input.nextInt();
            }
        }
        

        // Summing elements by column
        for (int j = 0; j < column; j++) 
        {
            int total = 0;
            
            for (int i = 0; i < row; i++)
            {
                total += matrix[i][j];
            }
            
            System.out.println();
            System.out.println("Sum for column " + j + " is " + total);
            
        }
		
	}
}
