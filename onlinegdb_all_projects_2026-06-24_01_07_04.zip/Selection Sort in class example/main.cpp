
#include <iostream>
#include <string>

using namespace std;

void selectionSort(string[], float[], int);

//void selectionSort(string[], int);
//void selectionSort(float[], int);

//void displayArray(string[], int)
//void displayArray(float[], int);

const int SIZE = 6;

int main()
{
    string student[SIZE] = {"Collins, Bill", "Smith, Bart", "Allen, Jim", "Griffin, Jim", "Stamey, Marty", "Rose, Geri"};
    
    float gpa[SIZE] = {3.5, 4.0, 2.75, 3.25, 3.0, 2.0};
    
    // Sort the names array alphabetically
    // Make sure to keep the gpa array updated
    
    selectionSort(student, gpa, SIZE);
    
    

    return 0;
}


