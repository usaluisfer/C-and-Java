#include <iostream>
using namespace std;

#include "ItemToPurchase.h"

int main() 
{
   
   ItemToPurchase item1;
   ItemToPurchase item2;
   
   string firstItemName, secondItemName;
   int firstItemPrice, secondItemPrice;
   int firstItemQuantity, secondItemQuantity;
   int total;
   
   // For first item
   cout << "Item 1" << endl;
   cout << "Enter the item name:\n";
   getline(cin, firstItemName);
   item1.SetName(firstItemName);
   cout << "Enter the item price:\n";
   cin >> firstItemPrice;
   item1.SetPrice(firstItemPrice);
   cout << "Enter the item quantity:\n";
   cin >> firstItemQuantity;
   item1.SetQuantity(firstItemQuantity);
   
   // To allow the user to input a new string
   cin.ignore();
   
   // Second item
   cout << endl << "Item 2" << endl;
   cout << "Enter the item name:\n";
   getline(cin, secondItemName);
   item2.SetName(secondItemName);
   cout << "Enter the item price:\n";
   cin >> secondItemPrice;
   item2.SetPrice(secondItemPrice);
   cout << "Enter the item quantity:\n";
   cin >> secondItemQuantity;
   item2.SetQuantity(secondItemQuantity);
   
   
   total = (item1.GetPrice() * item1.GetQuantity()) + (item2.GetPrice() * item2.GetQuantity());
   
   cout << endl;
   cout << "TOTAL COST" << endl;
   cout << item1.GetName() << " " << item1.GetQuantity() << " @ $" << item1.GetPrice() << " = $" << (item1.GetPrice() * item1.GetQuantity()) << endl;
   cout << item2.GetName() << " " << item2.GetQuantity() << " @ $" << item2.GetPrice() << " = $" << (item2.GetPrice() * item2.GetQuantity()) << endl;
   cout << endl << "Total: $" << total;

   
   
   
   
   return 0;
}