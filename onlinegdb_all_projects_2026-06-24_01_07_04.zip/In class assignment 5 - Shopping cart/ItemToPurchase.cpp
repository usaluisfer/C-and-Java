#include <iostream>
using namespace std;

#include "ItemToPurchase.h"

// Constructor that accepts arguments
/*
ItemToPurchase::ItemToPurchase(string n = "none", int p = 0, int q = 0)
{
    itemName = n;
    itemPrice = p;
    itemQuantity = q;
}
*/



//
void ItemToPurchase::SetName(string n = "none")
{
    itemName = n;
}

//
void ItemToPurchase::SetPrice(int p = 0)
{
    itemPrice = p;
}

//
void ItemToPurchase::SetQuantity(int q = 0)
{
   itemQuantity = q;
   
}
 

 
      
      
      