#ifndef ITEM_TO_PURCHASE_H
#define ITEM_TO_PURCHASE_H

#include <string>
using namespace std;

class ItemToPurchase
{
   private:
      string itemName;
      int itemPrice;
      int itemQuantity;

   public:
      // Default constructor initializing itemName, itemPrice, and itemQuantity
      //ItemToPurchase(std::string, int, int);
      
      // mutators
      void SetName(string);
      void SetPrice(int);
      void SetQuantity(int);
      
      // accessors
      string GetName() const
      {
          return itemName;
      }
      
      int GetPrice() const
      {
          return itemPrice;
      }
      
      int GetQuantity() const
      {
          return itemQuantity;
      }
      
};

#endif