#include <iostream>
#include <fstream>
#include <iomanip>

int main() {
    std::string inputFileName;
    std::ifstream inputFile;
    std::ofstream outputFile("badvalues.txt");
    
    // Prompt user for input file name with a period at the end
    std::cout << "Enter the input file name." << endl;
    std::getline(std::cin, inputFileName);
    
    // Attempt to open the input file
    inputFile.open(inputFileName);
    
    // Check if input file was opened successfully
    if (!inputFile) {
        std::cout << "The file \"" << inputFileName << "\" could not be opened." << std::endl;
        return 1; // Exit the program with an error code
    }

    double value;
    int totalValues = 0, validCount = 0, invalidCount = 0;
    double sumValid = 0;

    // Read values from the input file
    while (inputFile >> value) {
        totalValues++;
        
        // Check for valid values
        if (value >= 1 && value <= 110) {
            validCount++;
            sumValid += value; // Add to sum of valid values
        } else {
            invalidCount++;
            outputFile << std::fixed << std::setprecision(3) << value << std::endl; // Write invalid value
        }
    }

    // Close files
    inputFile.close();
    outputFile.close();

    // Display results
    std::cout << endl << "Total number of values read: " << totalValues << std::endl;
    std::cout << "Valid values read: " << validCount << std::endl;
    std::cout << "Invalid values read: " << invalidCount << std::endl;

    // Calculate and display the average of valid values
    if (validCount > 0) {
        double average = sumValid / validCount;
        std::cout << "The average of the valid numbers read = " << std::fixed << std::setprecision(2) << average << std::endl;
    } else {
        std::cout << "The file did not contain any valid values." << std::endl;
    }

    return 0; // Successful execution
}
