// This program includes an Employee class with 2 subclasses for part time and full time,
// each of them containing their calculations for the salaries
// For part-time it is number of hours * 25
// For full- time it is 10000

import java.util.Scanner;

// Employee class (Parent)
public class Employee
{
    String name; 
    
    // Default constructor
    Employee()   
    {
        
    }
    
    Employee(String n)
    {
        name = n;
    }
    
    double calculateSalary()
    {
        return 0;
    }
    
    void display()
    {
        System.out.println("Employee Name: " + name);
        System.out.println("Salary: " + calculateSalary());
    }
    
    
    // Main
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        // Asking user for part time and full time names
        System.out.println("Enter part-time employee name: ");
        String partTimeName = input.nextLine();
        
        System.out.println();
        // For part time workers, it asks how many hours
        System.out.println("Enter number of hours worked: ");
        int hours = input.nextInt();
        input.nextLine();
        
        System.out.println();
        System.out.println("Enter full-time employee name: ");
        String fullTimeName = input.nextLine();
        
        // Creating objects for PartTimeEmployee and FullTimeEmployee
        PartTimeEmployee pT = new PartTimeEmployee(partTimeName, hours);
        FullTimeEmployee fT = new FullTimeEmployee(fullTimeName);
        
        // Displaying salaries with their names
        System.out.println();
        System.out.println("Part-Time Employee: ");
        pT.display();
        
        System.out.println();
        System.out.println("Full-Time Employee: ");
        fT.display();
    }

}




// Subclass #1 (Part-Time)
class PartTimeEmployee extends Employee 
{
    int hours;
    
    PartTimeEmployee(String n, int h)
    {
        name = n;
        hours = h;
    }
    
    double calculateSalary()
    {
        return hours * 25;
    }
    
}



// Subclass #2 (Full-Time)
class FullTimeEmployee extends Employee
{
    FullTimeEmployee(String n)
    {
        name = n;
    }
    
    double calculateSalary()
    {
        return 10000;
    }
    
}




