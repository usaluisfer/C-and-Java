// // This program calculates the present value of an investment. The program uses this three functions: readYears, presentValue, and displayResults, including main function.
// This formula is used for calculating the presenta value: P = F / ( (1 + r) ^ n), were (F) is the future value, (r) is the annual interest rate, (n) is the number of years the money will sit in the account, unchanged.
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// Function prototypes
int readYears();    // readYears function declared as integer 
double presentValue(double futureValue, double interestRate, int numOfYears);     // double presentaValue function
void displayResults(double presentVal, double futureVal, double interestRate, int numOfYears);     // void displayResults function

// Main function
int main()
{
    // declaring variables
    double futureValue;
    double interestRate;
    int numOfYears;

    // Asking user for future value
    cout << "Enter the future value of the investment: ";

    // if value is negative, error message is displayed and asks the user again for a number
    while (!(cin >> futureValue) || futureValue <= 0) 
    {
        cout << "Error. The future value must be greater than zero.\n";
        cout << "Enter the future value of the investment: ";
        cin.clear(); // Clears error state
        cin.ignore(10000, '\n'); // Ignores invalid input
    }

    // Asking user for annual interest rate
    cout << "Enter the annual interest rate: ";

    // If negative, error message is displayed and asking user again for a value
    while (!(cin >> interestRate) || interestRate <= 0) 
    {
        cout << "Error. The annual interest rate must be greater than zero.\n";
        cout << "Enter the annual interest rate: ";
        cin.clear(); 
        cin.ignore(10000, '\n'); 
    }
    
    // interest rate needs to be converted to decimal
    interestRate /= 100;
    // Getting number of years from the readYears function
    numOfYears = readYears();
    // Calling the presentVal function for calculating and displaying the present value according to the formula
    double presentVal = presentValue(futureValue, interestRate, numOfYears);
    // Calling the displayResults function for displaying the results to the user
    displayResults(presentVal, futureValue, interestRate, numOfYears);

    return 0;
}


// readYears function asks the user for the number of years of investment, and then checks whether number entered is positive or not. If not, error message is displayed, asking the user again for a positive value.
int readYears()
{
    // declaring int variable for the years
    int numOfYears;
    // Asking user for the number of years
    cout << "Enter the whole number of years of the investment: ";

    // If negative, error message the user is asked again for input
    while (!(cin >> numOfYears) || numOfYears <= 0) 
    {
        cout << "Error. The number of years must be greater than zero.\n";
        cout << "Enter the whole number of years of the investment: ";
        cin.clear(); // Clear the error state
        cin.ignore(10000, '\n'); // Ignore invalid input
    }
    return numOfYears;
    
}


// presentValue function makes sure that the number of years is not equal to zero, so the calculation for the present value can take place
double presentValue(double futureValue, double interestRate, int numOfYears) 
{
    // using P = F / ( (1 + r) ^ n), present value (P) is calculated
    return futureValue / pow(1 + interestRate, numOfYears);      // (F) is future value, (r) is interest rate, and (n) is number of years
}


// Displays and outputs the results for each: the present value, future value, annual interest rate, and years.
void displayResults(double presentVal, double futureVal, double interestRate, int numOfYears) 
{
    // two digits of precision to the right of the decimal point
    cout << endl;
    cout << fixed << setprecision(2);
    cout << "Present value: $" << presentVal << endl;
    cout << "Future value: $" << futureVal << endl;

    cout << fixed << setprecision(3);
    cout << "Annual interest rate: " << (interestRate * 100) << "%" << endl;       // three digits to the right of the decimal point.
    cout << "Years: " << numOfYears << endl;
}