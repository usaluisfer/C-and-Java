// This program checks whether a student that plans to take the class 3345 is eligible or not
import java.util.Scanner;

public class Main
{
	public static void main(String[] args) 
	{
	    Scanner input = new Scanner(System.in);
	    
		System.out.println("Have you taken 2336 or 2337? (yes/no) ");
		String answer1 = input.nextLine();
		
		System.out.println("Have you also taken 2305? (yes/no) ");
		String answer2 = input.nextLine();
		
		System.out.println("Are you enrolling in 3345? (yes/no) ");
		String answer3 = input.nextLine();
		
		System.out.println("Are you enrolling in 3377? (yes/no) ");
		String answer4 = input.nextLine();
		
		// If user is planning on taking 3345
		if (answer3.equals("yes"))
		{
		    // The prerequisite can be either 2336 or 2337
		    // Everyone must take 2305 before taking 3345
		    if (answer1.equals("yes") && answer2.equals("yes") && answer4.equals("yes"))
		    {
		        System.out.println("You are eligible to take the class 3345!");
		    }
		    
		    // If user answers no, they don't meet the requirements
		    else
		    {
		        System.out.println("You are not eligible to take the class 3345.");
		    }
		}
		
		// If user is not taking 3345, error message
		else
		{
		    System.out.println("You are not taking the class 3345.");
		}
		
		
		input.close();
		
	}
}
