
#include <iostream>

class A
{

};

class B: public A 
{
    B() 
    {
        A();
        ....
        ....
    }
};

class C: public B 
{
    C() 
    {
        B();
        ....
        ....
    }
    
    C(const &x)
    {
        
    }
};




void print(A y) {

}



int main()
{
	A x(2);
	A y = x;
	A y(x);
	print(x);

	y = x;

	return 0;
}