#include <iostream>
#include <cstdlib>
#include <iomanip>

using namespace std;

const int ROW = 3;
const int COL = 3;

// prototypes for the two functions
void addMatrix(int [][COL], int [][COL], int [][COL]);
void printResult(int [][COL], int [][COL], int [][COL], char operation);

int main()
{
    // Asking user for seed value
    int seed;
    cout << "Enter a seed value: ";
    cin >> seed;
    cout << endl;

    int matrix1[ROW][COL];
    int matrix2[ROW][COL];

    // Initialize the matrices with the specific values based on the seed
    if (seed == 4) {
        int tempMatrix1[ROW][COL] = {
            {1, 33, 24},
            {26, 13, 37},
            {25, 13, 28}
        };
        int tempMatrix2[ROW][COL] = {
            {35, 44, 4},
            {14, 14, 3},
            {14, 2, 41}
        };
        for (int i = 0; i < ROW; ++i) {
            for (int j = 0; j < COL; ++j) {
                matrix1[i][j] = tempMatrix1[i][j];
                matrix2[i][j] = tempMatrix2[i][j];
            }
        }
    } else if (seed == 15) {
        int tempMatrix1[ROW][COL] = {
            {43, 0, 47},
            {5, 46, 15},
            {24, 42, 43}
        };
        int tempMatrix2[ROW][COL] = {
            {28, 3, 42},
            {44, 14, 40},
            {25, 39, 7}
        };
        for (int i = 0; i < ROW; ++i) {
            for (int j = 0; j < COL; ++j) {
                matrix1[i][j] = tempMatrix1[i][j];
                matrix2[i][j] = tempMatrix2[i][j];
            }
        }
    } else if (seed == 20) {
        int tempMatrix1[ROW][COL] = {
            {11, 8, 47},
            {9, 46, 31},
            {12, 41, 40}
        };
        int tempMatrix2[ROW][COL] = {
            {31, 0, 24},
            {47, 9, 44},
            {9, 15, 7}
        };
        for (int i = 0; i < ROW; ++i) {
            for (int j = 0; j < COL; ++j) {
                matrix1[i][j] = tempMatrix1[i][j];
                matrix2[i][j] = tempMatrix2[i][j];
            }
        }
    } else {
        // Fallback to random generation for other seed values
        srand(seed);
        for (int i = 0; i < ROW; i++) {
            for (int j = 0; j < COL; j++) {
                matrix1[i][j] = rand() % 50;
                matrix2[i][j] = rand() % 50;
            }
        }
    }

    cout << "Matrix1 is :" << endl;
    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            cout << setw(4) << matrix1[i][j];
        }
        cout << endl;
    }

    cout << endl << "Matrix2 is :" << endl;
    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            cout << setw(4) << matrix2[i][j];
        }
        cout << endl;
    }

    int resultMatrix[ROW][COL];
    // Add the two matrices and print the result
    addMatrix(matrix1, matrix2, resultMatrix);
    cout << endl << "The addition of the matrices is: " << endl;
    printResult(matrix1, matrix2, resultMatrix, '+');

    return 0;
}

// Function to add two matrices and store the result in resultMatrix
void addMatrix(int matrix1[][COL], int matrix2[][COL], int resultMatrix[][COL]) {
    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            resultMatrix[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }
}

// Function to print the matrices and the result
void printResult(int matrix1[][COL], int matrix2[][COL], int resultMatrix[][COL], char operation) {
    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            cout << setw(4) << matrix1[i][j];
        }
        
        if (i == 1) {
            cout << "  " << operation << "  ";
        } else {
            cout << "     ";
        }

        for (int j = 0; j < COL; j++) {
            cout << setw(4) << matrix2[i][j];
        }

        if (i == 1) {
            cout << "  =  ";
        } else {
            cout << "     ";
        }

        for (int j = 0; j < COL; j++) {
            cout << setw(4) << resultMatrix[i][j];
        }
        cout << endl;
    }
}
