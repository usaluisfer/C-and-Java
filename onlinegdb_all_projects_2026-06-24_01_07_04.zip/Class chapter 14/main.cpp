/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

int main()
{
    int x, y, z;
    
    x = y = z;
    
    A x,y,z;
    y = z; x = y;
    
    x = y;
    x.operator(y);
    cout << "Hello";

    return 0;
}