#include <iostream>
using namespace std;

int count = 0;
int itself(int);

int main()
{
    int number;
    cout << "Enter a value: " << endl;
    cin >> number;
    
    int recursion = itself(number);
    cout << "The value is " << recursion << endl;

    return 0;
}

int itself(int i)
{
    count++;
    if (i > 20)
    {
        cout << "The count is " << count << endl;
        return i;
    }
    
    else 
    {
        return (itself(i + 5) + i);
    }
}