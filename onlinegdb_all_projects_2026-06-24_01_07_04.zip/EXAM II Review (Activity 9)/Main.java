// Activity 9 Practice

import java.util.Scanner;

/*
class Employee
{
    String name;
    int hoursWorked;
    double salary;
    
    Employee(String n, int h)
    {
        name = n;
        hoursWorked = h;
    }
    
    void calculateSalary()
    {
        salary = hoursWorked * 20;
    }
    
    void display()
    {
        System.out.println("Employee name: " + name);
        System.out.println("Hours worked: " + hoursWorked);
        System.out.println("Salary: " + salary);
    }
}




public class Main
{
	public static void main(String[] args) 
	{
	    Scanner input = new Scanner(System.in);
	    
	    // Letting user enter employee name and hours worked
	    System.out.println("Enter employee name: ");
	    String name = input.nextLine();
	    
	    System.out.println();
	    System.out.println("Enter number of hours worked: ");
	    int hours = input.nextInt();
	    System.out.println();
	    
	    // Object instance for Employee class 
	    Employee y = new Employee(name, hours);
	    
	    // Calling methods
	    y.calculateSalary();
	    y.display();
	    
	    
		
	}
}
*/



/*
// Activity 10 Practice
class Rectangle
{
    double length;
    double width;
    
    Rectangle(double l, double w)
    {
        length = l;
        width = w;
    }
    
    double getArea()
    {
        return length * width;
    }
    
    double getPerimeter()
    {
        return 2 * (length + width);
    }
    
}


//Main 
public class Main
{
	public static void main(String[] args) 
	{
	    Scanner input = new Scanner(System.in);
	    
	    // Letting user enter employee name and hours worked
	    System.out.println("Enter length: ");
	    double length = input.nextDouble();
	    
	    System.out.println();
	    System.out.println("Enter width: ");
	    double width = input.nextDouble();
	    System.out.println();
	    
	    // Object instance 
	    Rectangle r = new Rectangle(length, width);
	    
	    // Displaying results & calling methods
	    System.out.println("Length: " + r.length);
        System.out.println("Width: " + r.width);
	    System.out.println("Area: " + r.getArea());
        System.out.println("Perimeter: " + r.getPerimeter());

    }
}
*/



class Employee 
{
    String name;
    
    Employee()
    {
    }
    
    Employee(String n)
    {
        name = n;
    }
    
    double calculateSalary()
    {
        return 0;
    }
    
    void display()
    {
        System.out.println("Employee Name: " + name);
        System.out.println("Salary: " + calculateSalary());
    }
    
}



public class Main
{
	public static void main(String[] args) 
	{
	    Scanner input = new Scanner(System.in);
	    
	    // Letting user enter employee name and hours worked
	    System.out.println("Enter part-time employee name: ");
	    String partTimeName = input.nextLine();
	    
        System.out.println();
        // For part time workers, it asks how many hours
        System.out.println("Enter number of hours worked: ");
        int hours = input.nextInt();
        input.nextLine();
        
        System.out.println();
        System.out.println("Enter full-time employee name: ");
        String fullTimeName = input.nextLine();
        
        PartTime pt = new PartTime(partTimeName, hours);
        FullTime ft = new FullTime(fullTimeName);
        
        // Displaying salaries with their names
        System.out.println();
        System.out.println("Part-Time Employee: ");
        pt.display();
        
        System.out.println();
        System.out.println("Full-Time Employee: ");
        ft.display();
	    
	    
	}
}








//Subclass 1
class PartTime extends Employee 
{
    int hours;
    
    PartTime(String n, int h)
    {
        name = n;
        hours = h;
    }
    
    double calculateSalary()
    {
        return hours * 25;
    }
}


//Subclass 2
class FullTime extends Employee 
{
    FullTime(String n)
    {
        name = n;
    }
    
    double calculateSalary()
    {
        return 10000;
    }
}


