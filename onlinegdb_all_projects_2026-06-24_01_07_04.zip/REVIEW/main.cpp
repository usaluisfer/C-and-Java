#include <iostream>

using namespace std;

int main()
{
    /*
    int vals[] = {4,7,11};
    int *valptr = vals;
//    valptr = vals;

    cout << *(valptr+1) << endl; //displays 7
    cout << *(valptr+2); //displays 11
    */
    
    
    const int SIZE = 6;
    const double payRates[SIZE] = {18.55, 17.45, 12.85, 14.97, 10.35, 18.89};
    const double *ptr = payRates;
    
    cout << *(ptr) << endl;
    cout << *(ptr+1) << endl;
    cout << *(ptr+2);
    
}

