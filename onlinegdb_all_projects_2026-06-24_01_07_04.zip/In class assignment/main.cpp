// This program asks the user to enter an item’s wholesale cost and its markup percentage. 
// Then, it displays the item’s retail price. 
#include <iostream>
#include <iomanip>

using namespace std;

// function prototype
double calculateRetail(double, double);

int main()
{
    double wholesaleCost;
    double markupPercentage;
    
    // Entering an amount
    cout << "Enter an item's wholesale cost: " << endl;
    cin >> wholesaleCost;
    
    // Can't be negative
    if (wholesaleCost < 0)
    {
        cout << "Value should be positive. Enter again: ";
        cin >> wholesaleCost;
    }
    
    // Entering markup percentage
    cout << "Enter its markup percentage: " << endl;
    cin >> markupPercentage;
    
    // Percentage has to be positive
    if (markupPercentage < 0)
    {
        cout << "Value should be positive. Enter again: ";
        cin >> markupPercentage;
    }
    
    // For two decimal points
    cout << fixed << setprecision(2);
    
    // Calling the calculateRetail function and showing result to user
    cout << "The item's retail price is: $" << calculateRetail(wholesaleCost, markupPercentage) << endl;
    

    return 0;
    
    
}

// calculateRetail function for calculating the retail price
double calculateRetail(double wholesaleCost, double markupPercentage)
{
    return wholesaleCost + (wholesaleCost * (markupPercentage / 100));       // Percentage entered is divided by 100, then result is multiplied by the wholesale cost and finally added.
}

