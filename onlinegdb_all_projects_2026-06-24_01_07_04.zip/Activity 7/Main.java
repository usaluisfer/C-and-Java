// This program displays a pattern using a 2D array
// It uses 5 rows and 5 columns 
// The pattern is made out of "#" symbols, which are only displayed on the borders and corners forming a rectangular shape
// The rest of the pattern is filled with "    " blank spaces.
import java.util.Scanner; 

public class Main
{
    public static void main(String[] args)
    {
        // 5 rows and 5 columns
        int rows = 5;
        int columns = 5;
        
        // 2D array declaration
        char[][] pattern = new char[rows][columns];
        
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                // making sure "#" is inserted in the borders of each row and column (first and last for each row/column)
                if (i == 0 || i == rows - 1 || j == 0 || j == columns - 1)
                {
                    pattern[i][j] = '#';
                }
                
                // if i and j are not the first or last for each row and column, a blank space is displayed
                else
                {
                    pattern[i][j] = ' ';
                }
            }
        }
        
        // Displaying the final pattern
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                System.out.print(pattern[i][j] + "   ");
            }
            
            System.out.println();
        }
        
    }
    
}
        