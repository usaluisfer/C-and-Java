#include <iostream>
using namespace std;

int count = 0;

int itself(int i);

int main()
{
   int x;
   cout << "Enter a value to find recursion: ";
   cin >> x;

   int recValue = itself(x);
   cout << "The value is " <<  recValue << endl;
   
   return 0;
	
}

int itself(int i)
{
    count++;
	
	if (i > 20)
	{
	   //write your base case
		cout << "count is " << count << endl;
		return i;
		
	}
	else
	{
	   //write your recursion case
	   return itself(i + 5) + i;
	   
	}
}
