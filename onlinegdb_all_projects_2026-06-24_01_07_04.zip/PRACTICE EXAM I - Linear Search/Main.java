// Linear search
import java.util.Scanner;

public class Main
{
    public static int linearSearch(int[] matrix, int key)
    {
        for (int i = 0; i < matrix.length; i++)
        {
            if (key == matrix[i])
            {
                return i;
            }
        }
        
        return -1;
    }
    
    
	public static void main(String[] args)
	{
	    Scanner input = new Scanner(System.in);
	    
	    System.out.println("Enter number of elements: ");
	    int size = input.nextInt();
	    
	    // Creating array
	    int[] matrix = new int[size];
	    
	    // Filling the array
	    System.out.println("Enter " + size + " elements:");
	    
	    for (int i = 0; i < size; i++)
	    {
	        matrix[i] = input.nextInt();
	    }
	    
	    // User enters a key element for linear search
	    System.out.println();
	    System.out.print("Enter value to search: ");
        int key = input.nextInt();
	    
	    System.out.println();
		System.out.println("Element was found at index " + linearSearch(matrix, key));
	
		
		
		
	}
}
