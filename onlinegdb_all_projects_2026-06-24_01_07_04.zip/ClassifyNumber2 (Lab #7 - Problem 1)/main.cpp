// This program gets an unspecified number of whole numbers from the user and displays: 
// the number of positive values entered, the sum of the positive values entered, the number of negative values entered, the product of the negative values entered, and the number of zeroes entered.
// After the user enters a number, it display a message asking the user if they would like to enter another number and asking for a response of Y for Yes or N for No. 
// Using a do-while loop to control the number of iterations.
// Using ints for the variables in the program.
// This program includes input validation. If any character other than Y(y) or N(n) is entered in response to the Yes or No question about continuing,
// the program displays an error message telling the user the input “is not a valid response” and allows them to re-enter.
#include <iostream>

using namespace std;

int main()
{
    // Declaring int variables
    int wholeNumber;
    int positives = 0;   // For carrying the count of positive numbers
    int negatives = 0;   // For carrying the count of negative numbers
    int sum = 0;   // For the sum of positives
    int product = 1;   // Product of negatives
    int zeroes = 0;   // For carrying the count of zeroes
    int count = 1;   // # of whole number
    string yesOrNo;   // For yes or no choice
    
    // Using do-while
    do
    {
        // Asking the user for a whole number
        cout << "Enter whole number " << count << ": ";
        cin >> wholeNumber;
    
        // Checking for positive numbers
        if (wholeNumber > 0)
        {
            
            sum += wholeNumber;   // Adding and storing
            positives++;   // positive count increments
        }
        
        // If equal to zero
        else if (wholeNumber == 0)
        {
            zeroes++;   // Storing amount of zeroes
        }
        
        // If negative
        else 
        {
            product *= wholeNumber;   // Multiplying the whole numbers
            negatives++;   // negative count increments
        }

        // For entering another number
        do 
        {
            // Asking user to enter Y for yes and N for no; other digits will cause error
            cout << "Would you like to enter another number?" << endl << "Enter Y for Yes or N for No: ";
            cin >> yesOrNo;
            
            // If user enters other than yes or no
            if (yesOrNo != "Y" && yesOrNo != "y" && yesOrNo != "N" && yesOrNo != "n")
            {
                cout << "Error, " << yesOrNo << " is not a valid response." << endl;
            }
        }
        // While user doesn't enter Y or N
        while (yesOrNo != "Y" && yesOrNo != "y" && yesOrNo != "N" && yesOrNo != "n");
        
        count++;
    }
    
    // While user enters Yes or No
    while (yesOrNo == "Y" || yesOrNo == "y");
            
            
    cout << endl;   
            
    
    // Displaying number of positives and their sum
    if (positives > 1)
    {
        cout << positives << " positive values were entered." <<  " Their sum was " << sum << "." << endl;
    }

    // If there was only one positive
    else if (positives == 1)
    {
        cout << "One positive value was entered. It was a " << sum << "." << endl;
    }
    
    // If no positive numbers were entered
    else 
    {
        cout << endl << "No positive values were entered." << endl;
    }
    
    
    // Displaying number of negatives and their product
    if (negatives > 1)
    {
        cout << negatives << " negative values were entered." <<  " Their product was " << product << "." << endl;
    }

    // If there was only one negative
    else if (negatives == 1)
    {
        cout << "One negative value was entered. It was a " << product <<  "." << endl;
    }
    
    // If no negative numbers were entered
    else 
    {
        cout << "No negative values were entered." << endl;
    }
    
    
    // Displaying total zeros if more than one zero is found
    if (zeroes > 1)
    {
        cout << zeroes << " zeroes were entered." << endl;
    }

    // If there was only one zero
    else if (zeroes == 1)
    {
        cout << "One zero was entered." << endl;
    }
    
    // If no zeroes were entered
    else 
    {
        cout << "No zeroes were entered." << endl;
    }
    
    

    return 0;
}