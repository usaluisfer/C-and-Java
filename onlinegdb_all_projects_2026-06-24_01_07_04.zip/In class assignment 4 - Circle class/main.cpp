// This program demonstrates a simple class.
#include <iostream>
using namespace std;

#define PI 3.14
// Circle class declaration.
class Circle
{
   private:
      double radius;

   public:
      void setRadius(double);
      double getRadius() const;
      double getDiameter() const;
      double getArea() const;
};


// setRadius assigns a value to the radius member.
void Circle::setRadius(double r)
{
    radius = r;
}

// getRadius assigns a value to the radius member.
double Circle::getRadius() const
{
    return radius;
}

// getDiameter 
double Circle::getDiameter() const
{
    return 2 * radius;
}

// getArea
double Circle::getArea() const
{
    return PI * radius * radius;
}





// Main function
int main()
{
   Circle c1;     // Defining an instance of the Circle class
   double rad, rad1;  // Local variable for radius

   // Getting the radius from the user.
   cout << "This program will calculate the area of a circle.\n";
   cout << "What is the radius? ";
   cin >> rad;
   
   // Asking for c2 (pointer)
   cout << "What is the radius of the object pointed by c2? ";
   cin >> rad1;


   // Store the radius of the circle in the c1 object.
   // Checking if value is positive
   if (rad > 0)
   {
       c1.setRadius(rad);
   }
   
   // If not positive, displays error message
   else
   {
       cout << "Radius must be a positive value";
   }
 

   // Display the circle's data.
   cout << "\nHere is the circle's data:\n";
   cout << "Radius: " << c1.getRadius() << endl;
   cout << "Diameter: " << c1.getDiameter() << endl;
   cout << "Area: " << c1.getArea() << endl;

   // Pointer for c2
   Circle *c2 = new Circle;
    

   // Store the radius of the circle in the c2 object.
   // Checking if value is positive
   if (rad1 > 0)
   {
       c2->setRadius(rad1);
   }
   
   // If not positive, displays error message
   else 
   {
       cout << "Radius must be a positive value";
   }
   

   // Display the circle's data.
   cout << "\nHere is the circle's data through the pointer:\n";
   cout << "Radius: " << c2->getRadius() << endl;
   cout << "Diameter: " << c2->getDiameter() << endl;
   cout << "Area: " << c2->getArea() << endl;

   return 0;
}