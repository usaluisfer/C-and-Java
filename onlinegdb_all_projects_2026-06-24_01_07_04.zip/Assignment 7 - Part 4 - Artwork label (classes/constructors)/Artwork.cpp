#include "Artwork.h"
#include <iostream>

// TODO: Define default constructor
Artwork::Artwork() : title("unknown"), yearCreated(-1), artist() {}

// TODO: Define second constructor to initialize private fields (title, yearCreated, artist)
Artwork::Artwork(string artTitle, int creationYear, Artist theArtist)
{
    title = artTitle;
    yearCreated = creationYear;
    artist = theArtist;
}

// TODO: Define get functions: GetTitle(), GetYearCreated()
string Artwork::GetTitle()
{
   return title;
}

int Artwork::GetYearCreated()
{
   return yearCreated;
}


// TODO: Define PrintInfo() function
//       Call the PrintInfo() function in the Artist class to print an artist's information  
void Artwork::PrintInfo()
{
   artist.PrintInfo();
   
   cout << "Title: " << title << ", " << yearCreated << endl;
}




