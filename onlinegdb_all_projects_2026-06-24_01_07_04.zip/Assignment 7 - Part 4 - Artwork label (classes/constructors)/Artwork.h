#ifndef ARTWORKH
#define ARTWORKH

#include "Artist.h"

class Artwork
{
   public:
      Artwork();

      Artwork(string artTitle, int creationYear, Artist theArtist);

      string GetTitle();

      int GetYearCreated();

      void PrintInfo();
   
   private:
      // TODO: Declare private data members - title, yearCreated
      string title;
      int yearCreated;

      // TODO: Declare private data member artist of type Artist
      Artist artist;

};

#endif