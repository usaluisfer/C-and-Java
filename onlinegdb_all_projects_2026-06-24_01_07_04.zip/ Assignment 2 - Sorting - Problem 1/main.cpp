// This program lets the user enter a charge account number. 
// The program determines if the number is valid by checking for it in the array list 
#include <iostream>

using namespace std;

// Function prototype
bool searchList(long [], int, long);

// Constant for the array size
const int SIZE = 18;

int main()
{
   // Array of account numbers
   long accounts[SIZE] = { 5658845,  4520125,  7895122,
                           8777541,  8451277,  1302850,
                           8080152,  4562555,  5552012,
                           5050552,  7825877,  1250255,
                           1005231,  6545231,  3852085,
                           7576651,  7881200,  4581002 };
                         
    
   // Prompting user for entering account number 
   int chargeNum;
   cout << endl << "Please enter a 7-digit account number: ";
   cin >> chargeNum;
    
    
   // searchList function defined
   searchList(accounts, chargeNum, SIZE);
        
}

// searchList function
bool searchList(long accounts[], int chargeNum, long SIZE)
{
    // Subscript to search the array
    int index = 0;
    int position = -1;      // To record position of search value
    bool found = false;     // Flag to indicate if value is found
    
   // Making sure value is not greater than 7-digits 
   if (chargeNum > 9999999)
    {
        cout << " The number you entered is invalid." << endl;
    }
    
    // Checking if value was found
    while (index < SIZE && !found)
    {
        if (accounts[index] == chargeNum)
        {
            found = true;    // Set to true when found
            position = index;      // Recording value's subscript
            cout << " The number you entered is valid." << endl;
        }
        
        index++;     // Going to next element
        
        // If false, error message displayed
        if (accounts[index] == false)
        {
            cout << "The number you entered is invalid." << endl;
            break;
        }
    }
    
    return position;
    
}