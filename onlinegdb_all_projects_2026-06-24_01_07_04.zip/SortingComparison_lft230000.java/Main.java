// This program compares the performance of three different sorting algorithms (bubble sort, selection sort, and insertion sort),
// A random array of size 10,000 is created and a copy of the original array for each algorithm is also performed.
// For measuring the time in miliseconds System.currentTimeMillis() is used, by comparing the starting time and final time and subtracting them for getting the time spent by the algorithm.
// Also, the first 20 elements of the random array are printed after each sorted array
import java.util.Scanner;
import java.util.Arrays;

public class Main
{
    
    // bubble sort method
    public static void bubbleSort(int array[]) 
    {
        // This means a swap is needed
        boolean needNextPass = true;
    
        for (int k = 1; k < array.length && needNextPass; k++)
        {
            // Stops the loop if array is already sorted
            needNextPass = false;
            
            // If the left element is bigger than the right one, swap
            for (int i = 0; i < array.length - k; i++) 
            {
                if (array[i] > array[i + 1]) 
                {
                    int temp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = temp;
          
                    needNextPass = true;
                }
            }
        }
    }
    
    
    
    
    
    // selection sort method
    public static void selectionSort(int array[])
    {
        int size = array.length;
        int minIndex;
        int minValue;
    
        // start is the actual position where the smallest element will be placed
        for (int start = 0; start < (size - 1); start++)
        {
            // minIndex for smallest value
            minIndex = start;
            minValue = array[start];
        
            // Finding the smallest value
            for (int index = start + 1; index < size; index++)
            {
                // If a smaller value is found, minValue becomes the new smallest
                if (array[index] < minValue)
                {
                    minValue = array[index];
                    minIndex = index;
                }
            }
            
            // Swapping smallest element into correct position
            int temp = array[minIndex];
            array[minIndex] = array[start];
            array[start] = temp;
            
        }
    }
    
    
    
    
    
    // insertion sort method
    public static void insertionSort(int array[]) 
    {
        for (int i = 1; i < array.length; i++) 
        {
            int currentElement = array[i];
            int k;
            
            // Shifting elements to the right as long as they are greater than currentElement
            for (k = i - 1; k >= 0 && array[k] > currentElement; k--) 
            {
                array[k + 1] = array[k];
            }

            // currentElement gets placed into its sorted position
            array[k + 1] = currentElement;
            
        }
    }





    // Main method
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		// Random array of size 10000
		int array[] = new int[10000];
		
		// Filling the array with random elements
		for (int i = 0; i < array.length; i++)
		{
		    array[i] = (int)(Math.random() * 10000);
		}
		
		
		
		// Making a copy of the original array for each sorting algorithm 
		// Bubble sort 
		int bubbleArray[] = Arrays.copyOf(array, array.length);
		
		// Measuring the time the algorithm takes by subtracting the ending time minus the starting time
		long startingTime = System.currentTimeMillis();
		
		// Running the sorting algorithm
		bubbleSort(bubbleArray);
		
		long endingTime = System.currentTimeMillis();
		
		// Results for Bubble Sort
		System.out.println("Bubble Sort time: " + (endingTime - startingTime) + " ms");
		System.out.println("First 20 elements after sorting: ");
		
		// Printing first 20 elements for verification
	    for (int i = 0; i < 20; i++)
	    {
		    System.out.print(array[i] + " ");
	    }
	
	    System.out.println("\n");
	    
	    
	    
	    // Selection Sort 
	    int selectionSortArray[] = Arrays.copyOf(array, array.length);
		
		// Doing the same procedure for Selection sort
		startingTime = System.currentTimeMillis();
		selectionSort(selectionSortArray);
		endingTime = System.currentTimeMillis();
		
		// Results for Selection Sort
		System.out.println("Selection Sort time: " + (endingTime - startingTime) + " ms");
		System.out.println("First 20 elements after sorting: ");
		
		// Printing first 20 elements
	    for (int i = 0; i < 20; i++)
	    {
		    System.out.print(array[i] + " ");
	    }
	
	    System.out.println("\n");
	    
	    
		
		
		
		// Insertion Sort
		int insertionSortArray[] = Arrays.copyOf(array, array.length);
		
		// Doing the same procedure but now for Insertion Sort
		startingTime = System.currentTimeMillis();
		insertionSort(insertionSortArray);
		endingTime = System.currentTimeMillis();
		
		// Results for Insertion Sort
		System.out.println("Insertion Sort time: " + (endingTime - startingTime) + " ms");
		System.out.println("First 20 elements after sorting: ");
		
		// Printing first 20 elements
	    for (int i = 0; i < 20; i++)
	    {
		    System.out.print(array[i] + " ");
	    }
	
	    System.out.println("\n");
	    
		
		
		
		
	}
}
