// This program simulates repeatedly flipping a coin.
// Uses the random number generator to simulate flipping the coin. 
// The number 1 represents Heads and the number 2 represents Tails.
// Using variables of type unsigned int for storing the seed and the coin flips.
// Displaying the result of each flip on the computer screen and after each flip it asks the user whether they want to flip the coin again. 
// The program accepts either uppercase or lowercase Y or N as valid responses to the question.
// For other characters it displays an error message and allows the user to reenter (as many times as necessary).
// After the user indicates that they want to stop flipping, it displays both the number and percentage of Heads flipped and the number and percentage of Tails flipped.
// Uses variables of type double for storing the percentages.
#include <iostream>
#include <cstdlib>
#include <iomanip>

using namespace std;

int main()
{
    // Declaring unsigned int variables
    unsigned int seed;
    unsigned int flipCoin;
    unsigned int heads = 0;
    unsigned int tails = 0;
    unsigned int total = 0;
    string yesOrNo;
    
    cin >> seed;
    // Calling the srand function to seed the random number generator
    
    srand(seed);
    
    // do-while
    do
    {
        flipCoin = rand() % 2 + 1;   // adding 1 makes it 1 or 2
        
        // If 1 = heads
        if (flipCoin == 1)
        {
            cout << "Flip = Heads" << endl;
            heads++;
        }
        
        // If not = tails
        else 
        {
            cout << "Flip = Tails" << endl;
            tails++;
        }
        
        // Incrementing total
        total++;
        
        // Asking to flip again
        do
        {
            cout << "Would you like to flip again?" << endl;
            cout << "Enter Y for Yes or N for No: ";
            cin >> yesOrNo;
            
            // Error message if not equal to yes or no
            if (yesOrNo != "Y" && yesOrNo != "y" && yesOrNo != "N" && yesOrNo != "n")
            {
                cout << endl << "Error, " << yesOrNo << " is not a valid response." << endl;
            }
        }
        
        while (yesOrNo != "Y" && yesOrNo != "y" && yesOrNo != "N" && yesOrNo != "n");
    }
    
    // When user enters Yes
    while (yesOrNo == "Y" || yesOrNo == "y");
    
    // Calculating percentages
    double percentageHeads = (double(heads) / total) * 100;
    double percentageTails = (double(tails) / total) * 100;
    
    // Displaying the number and percentages of heads and tails
    cout << endl;
    cout << heads << " of the " << total << " flips were Heads or " << fixed << setprecision(2) << percentageHeads << "% were Heads." << endl;
    cout << tails << " of the " << total << " flips were Tails or " << fixed << setprecision(2) << percentageTails << "% were Tails." << endl;
    
    
    
    
    return 0;
}