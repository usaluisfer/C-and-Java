
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    srand(time(0));
    
    int number1 = rand() % 51;
    int number2 = rand() % 101;
    
    cout << "What is " << number1 << " + " << number2 << "? ";
    
    int answer;
    cin >> answer;
    
    int sum = number1 + number2;
    
    while (answer != sum)
    {
        cout << "Answer is incorrect. Try again. What is " << number1 << " + " << number2 << "? ";
        cin >> answer;
    }
    cout << "Answer is correct!";
    
    
    
    

    return 0;
}