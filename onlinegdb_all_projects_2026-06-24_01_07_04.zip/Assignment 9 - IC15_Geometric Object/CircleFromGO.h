#ifndef CIRCLEFROMGO_H
#define CIRCLEFROMGO_H
#include "GeometricObject.h"
//#include <math.h>

// CircleFromGO class using inheritance
class CircleFromGO : public GeometricObject
{
    private:
        double radius;
        
    public:
        CircleFromGO();
        CircleFromGO(double r);
        CircleFromGO(double r, string c, bool f);
        
        void setRadius(double r);
        //void setColor(string c);
        //void setFilled(bool f);
        
        double getRadius() const
        {
            return radius;
        }
        
        double getArea() const;
        double getPerimeter() const;
        double getDiameter() const;
        void print();
        
        // friend object
        friend ostream& operator<<(ostream& strm, const CircleFromGO& obj);
        
        
};

#endif