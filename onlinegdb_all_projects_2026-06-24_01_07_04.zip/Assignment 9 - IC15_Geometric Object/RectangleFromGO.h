#ifndef RECTANGLEFROMGO_H
#define RECTANGLEFROMGO_H
#include "GeometricObject.h"

// RectangleFromGO class using inheritance
class RectangleFromGO : public GeometricObject
{
    private:
        double width;
        double height;
        
    public:
        RectangleFromGO();
        RectangleFromGO(double w, double h);
        RectangleFromGO(double w, double h, string c, bool f);
        
        void setWidth(double w);
        void setHeight(double h);
        
        double getWidth() const
        {
            return width;
        }
        
        double getHeight() const
        {
            return height;
        }
        
        double getArea() const;
        double getPerimeter() const;
        void print();
        
        // friend object
        friend ostream& operator<<(ostream& strm, const RectangleFromGO& obj);
        
        
};

#endif