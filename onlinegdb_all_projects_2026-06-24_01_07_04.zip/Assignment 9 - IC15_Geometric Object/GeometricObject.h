#ifndef GEOMETRICOBJECT_H
#define GEOMETRICOBJECT_H
#include <iostream>
#include <string>
using namespace std;

class GeometricObject
{
    private:
       string color;
       bool filled;
       
    public:
        // Constructors
        GeometricObject();
        GeometricObject(string c, bool f);
        
        // mutators
        void setColor(string c);
        void setFilled(bool f);
        
        // accessors
        string getColor() const
        {
            return color;
        }
        
        bool getFilled()
        {
            return filled;
        }
};

#endif