#include "RectangleFromGO.h"

RectangleFromGO::RectangleFromGO() : GeometricObject()
{
    width = 0.0;
    height = 0.0;
}

RectangleFromGO::RectangleFromGO(double w, double h) : GeometricObject()
{
    width = w;
    height = h;
}

RectangleFromGO::RectangleFromGO(double w, double h, string c, bool f) : GeometricObject(c, f)
{
    width = w;
    height = h;
}

void RectangleFromGO::setWidth(double w)
{
    width = w;
}

void RectangleFromGO::setHeight(double h)
{
    height = h;
}

// getArea
double RectangleFromGO::getArea() const
{
    return width * height;
}

// getPerimeter
double RectangleFromGO::getPerimeter() const
{
    return 2 * (width + height);
}


// print
void RectangleFromGO::print()
{
    cout << "The rectangle width is " << width << " and the height is " << height << endl;
    cout << "Color: " << getColor() << " and filled: " << getFilled() << endl;
}


// Operator overload for the output stream operator <<
ostream& operator<<(ostream& strm, const RectangleFromGO& obj) {
    strm << "The Rectangle printed with ostream!\n";
    strm << "The width and height is " << obj.width << ", " << obj.height << "\n";
    strm << "Color: " << obj.getColor() << " and Area: " << obj.getArea();
    return strm;
}





