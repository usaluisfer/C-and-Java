//This program creates a Student class
// It calculates grade of student based on average of Exam1 and Exam 2 
// Also finds the number of students in the class.
// It includes getAverage, getGrade, and getStudentCount methods
import java.util.Scanner;

public class Student
{
    // Attributes
    double exam1;
    double exam2;
    static int studentCount = 0;
    
    // Constructor
    Student(double ex1, double ex2)
    {
        exam1 = ex1;
        exam2 = ex2;
        studentCount++;
    }
    
    // getAverage method 
    double getAverage()
    {
        return (exam1 + exam2) / 2;
    }
    
    // getGrade method
    char getGrade()
    {
        double average = getAverage();
        
        // Determining letter grade according to average 
        // If 90 or more = A
        if (average >= 90)
        {
            return 'A';
        }
        
        // If 80 or more = B
        else if (average >= 80)
        {
            return 'B';
        }
        
        // If 70 or more = C
        else if (average >= 70)
        {
            return 'C';
        }
        
        // If 60 or more = D
        else if (average >= 60)
        {
            return 'D';
        }
        
        // Else = F
        else 
        {
            return 'F';
        }
        
        
        
    }
    
    // getStudentCount method
    static int getStudentCount()
    {
        return studentCount;
    }
    
    
    
    
    
    
    // Main 
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        // Asking for number of students
        System.out.println("Enter number of students: ");
        int students = input.nextInt();
        
        // for loop for showing each student's grade
        for (int i = 1; i <= students; i++)
        {
            System.out.println("\nStudent " + i + ":");
            
            // Letting user enter score for Exam 1
            System.out.println("Enter score for Exam 1: ");
            double ex1 = input.nextDouble();
            
            // Letting user enter score for Exam 2
            System.out.println("Enter score for Exam 2: ");
            double ex2 = input.nextDouble();
            
            // Object for Student class
            Student s = new Student(ex1, ex2);
            
            // Displaying grades and average
            System.out.println("\nAverage: " + s.getAverage());
            System.out.println("Grade: " + s.getGrade());
            
        }
        
        // Displaying number of students
        System.out.println("\nTotal students: " + Student.getStudentCount());
        
        
    }
    
	    
}

