// This program gets ten whole numbers from the user and displays a count of: 
// the number of zeroes, the number of negative values, and the number of positive values entered, 
// followed by the product of the negative numbers entered, and the sum of the positive values entered. 
// It uses a for loop to control the number of iterations.
// Uses ints for the variables.
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    // Declaring int variables
    int wholeNumber;
    int zeros = 0;
    int positives = 0;   // For carrying the count of positive numbers
    int negatives = 0;   // For carrying the count of negative numbers
    int sum = 0;   // For the sum of positives
    int product = 1;   // Product of negatives
    
    // for loop for the count to ten
    for (int i = 1; i <= 10; i++)
    {
        // Asking the user for a whole number (repeats until 10)
        cout << "Enter whole number " << i << ": ";
        cin >> wholeNumber;
        
        // If the number is equal to zero
        if (wholeNumber == 0)
        {
            zeros++;   // zeros increment
        }
        
        // If number is greater than zero
        else if (wholeNumber > 0)
        {
            sum += wholeNumber;   // adding the positives
            positives++;   // positives increment
        }
        
        // If negative
        else
        {
            product *= wholeNumber;   // Finding the production (multiplication)
            negatives++;   // negatives increment
        }
    }
        
    
    // Displaying the results to the screen
    cout << endl;
    cout << "Of the 10 numbers entered:" << endl;
    cout << "\t" << zeros << " were 0's." << endl;
    cout << "\t" << negatives << " were negative." << endl;
    cout << "\t" << positives << " were positive." << endl;
    cout << endl;

    // Displaying the product for negatives
    if (negatives > 0) 
    {
        cout << "The product of the negative numbers was " << product << "." << endl;
    } 
    
    // If there were no negatives
    else 
    {
        cout << "There were no negative numbers to calculate the product." << endl;
    }

    // Displaying sum of positives
    cout << "The sum of the positive numbers was " << sum << "." << endl;
    
    
    
    

    return 0;
}