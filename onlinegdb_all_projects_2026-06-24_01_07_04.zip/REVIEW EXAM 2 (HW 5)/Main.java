import java.util.Scanner;
public class Main 
{
    public static void main(String[] args) 
    {
        Graph g = new Graph(4);
        
        g.addEdge(0,1);
        g.addEdge(0,2);
        g.addEdge(0,3);
        g.addEdge(1,2);
        g.addEdge(1,3);
        g.addEdge(2,3);
        
        g.printMatrix();
        
        if (g.isComplete())
        {
            System.out.println("Graph is complete.");
        }
        
        else 
        {
            System.out.println("Graph is not complete.");
        }
        
    }
}
        
        