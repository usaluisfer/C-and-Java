public class Graph
{
    private int[][] matrix;
    private int vertices;
    
    Graph(int v)
    {
        vertices = v;
        matrix = new int[v][v];
    }
    
    void addEdge(int i, int j)
    {
        if (i >= 0 && j >= 0 && i < vertices && j < vertices && i != j)
        {
            matrix[i][j] = 1;
            matrix[j][i] = 1;
        }
    }
    
    boolean isComplete()
    {
        for (int i = 0; i < vertices; i++)
        {
            for (int j = 0; j < vertices; j++)
            {
                if (i == j && matrix[i][j] != 0)
                {
                    return false;
                }
                
                if (i != j && matrix[i][j] != 1)
                {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    
    void printMatrix()
    {
        for (int i = 0; i < vertices; i++)
        {
            for (int j = 0; j < vertices; j++)
            {
                System.out.print(matrix[i][j] + " "); 
            }
            
            System.out.println();
        }
        
    }
    
    
    
    
}