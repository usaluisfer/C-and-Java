// This program determines whether a given matrix is symmetric.
#include <iostream>

using namespace std;

int main()
{
   // User enter number of rows and columns
   int mrow, mcol;
   cout <<  "Enter the number of rows and columns: ";
   cin >> mrow >> mcol;
   
   // If different, enter again
   while (mrow != mcol) // input validation
   {
      cout << "The number of rows and columns must be same." << endl;
      cout << "Enter the number of rows and columns: ";
      cin >> mrow >> mcol;
   }
 
   int A[mrow][mcol];
    
   // Asking for matrix values 
   cout << "Enter the values for the matrix: \n";
   
   for (int i = 0; i < mrow; i++)
   {
      for (int j = 0; j < mcol; j++)
      {
         cin >> A[i][j];
      }
   }
   
   // Checking if matrix is symmetrical
   bool isSymmetric = true;     // Set to symmetric
   for (int i = 0; i < mrow; i++)
   {
      for (int j = 0; j < mcol; j++)
      {
         if (A[i][j] != A[j][i])
         {
            isSymmetric = false;
            break;
         }
      }
      
      if (!isSymmetric)
      {
         break;
      }
   }
   
   // Letting user know if its symmetrical or not
   if (isSymmetric)
   {
      cout << "The matrix is symmetrical." << endl;
   }
   
   else
   {
      cout << "The matrix is not symmetrical." << endl;
   }
   
   return 0;
}
