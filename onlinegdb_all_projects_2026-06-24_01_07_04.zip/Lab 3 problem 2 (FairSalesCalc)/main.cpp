// A vendor at the county fair sells chili dogs for $8.5, corn dogs for $7, chips for $2.5, soft drinks for $4.5, bottles of water for $4.
// This program asks the user to enter the number of chili dogs, corn dogs, chips, soft drinks, and water bottles sold in order.
// All of the items but the water bottles are taxable at a rate of 6.5 percent. 
// The program displays the dollar amount of the taxable items sold, the dollar amount of the taxes, the dollar amount of non-taxable items sold, 
// and the total of the three values: taxable amount, taxes, and non-taxable amount.
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
    
    // Prices declared constant (all are double)
    const double chiliDogs = 8.5;
    const double cornDogs = 7.0;
    const double chips = 2.5;
    const double softDrinks = 4.5;
    const double waterBottles = 4.0;
    const double tax = 0.065;
    
    // int variables for asking the user for amounts
    int chiliDogs_sold;
    int cornDogs_sold;
    int chips_sold;
    int softDrinks_sold;
    int waterBottles_sold;
    
    cout << "How many chili dogs were sold? ";
    cin >> chiliDogs_sold;
    
    cout << "How many corn dogs were sold? ";
    cin >> cornDogs_sold;
    
    cout << "How many bags of chips were sold? ";
    cin >> chips_sold; 
    
    cout << "How many soft drinks were sold? ";
    cin >> softDrinks_sold;
    
    cout << "How many bottles of water were sold? ";
    cin >> waterBottles_sold; 
    cout << endl;
    
    
    // Calculating the price of each according to the amount entered by the user
    double chiliDogs_Amount = chiliDogs_sold * chiliDogs;
    double cornDogs_Amount = cornDogs_sold * cornDogs;
    double chips_Amount = chips_sold * chips;
    double softDrinks_Amount = softDrinks_sold * softDrinks;
    
    // Adding the prices (no tax)
    double taxableAmount = (chiliDogs_Amount + cornDogs_Amount + chips_Amount + softDrinks_Amount);
    
    // Calculating the price with the tax included
    double taxAmount = taxableAmount * tax;
    
    // Water bottles with no tax
    double nonTaxableAmount = waterBottles_sold * waterBottles;
    
    // Calculating the total amount for everything
    double TotalAmount = taxableAmount + taxAmount + nonTaxableAmount;
    
    
    // Displaying all the amounts
    cout << fixed << setprecision(2); // Set precision to 2 decimal places
    cout << left << setw(15) << "Taxable:" << "$" << right << setw(10) << taxableAmount << endl;
    cout << left << setw(15) << "Tax amount:" << "$" << right << setw(10) << taxAmount << endl;
    cout << left << setw(15) << "Non-taxable:" << "$" << right << setw(10) << nonTaxableAmount << endl;
    cout << left << setw(15) << "Total:" << "$" << right << setw(10) << TotalAmount << endl;





    return 0;
    
}