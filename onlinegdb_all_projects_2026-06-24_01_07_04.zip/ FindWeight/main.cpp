// This program asks the user to enter the mass of an object in kilograms and then it displays the weight of the object on:
// the Earth, the Moon, Mercury, and on Venus in Newtons.
// This program also displays a message indicating that the object is heavy is if weighs over 1250 Newtons on Earth,
// it can also display a message indicating that the object is light if it weighs less than 20 Newtons on Earth.
// If the mass entered is not greater than zero, an error message will be displayed to the screen.
#include <iostream>
#include <iomanip>


using namespace std;

int main()
{
    // Declaring as constant variables the accelleration due to gravity for earth, moon, mercury, and venus
    const double earth = 9.807;   // m/sect^2
    const double moon = 1.62;   // m/sec^2
    const double mercury = 3.7;   // m/sec^2
    const double venus = 8.87;   // m/sect^2
    
    // Asking the user to enter the mass of an object in kilograms
    double mass;
    cout << "Please enter the mass of an object in kilograms: ";
    cin >> mass;
    cout << endl;
    
    // Calculating the weight of the object in Newtons (multiplying the mass in kg by the accelleration due to gravity)
    double earthWeight = earth * mass;
    double moonWeight = moon * mass;
    double mercuryWeight = mercury * mass;
    double venusWeight = venus * mass;
    
    // If else statement for determining if the mass entered is greater than 0
    // If the mass is less than 0, it displays an error message
    if (mass < 0)
    {
        cout << "Error, invalid mass entered." << endl << "The entered mass must be greater than 0.";
    }
    else 
    {
        // Displaying the results in tabular form
        // The first column will have a heading (Planet/Satellite) and the planets; the second column will have the heading (Weight (N)) and the weights for each planet
        cout << setw(16) << left << endl;   // Planets and heading are left justified in a field 16 char wide
        cout << "Planet/Satellite" << '\t' << right << setw(14) << "Weight (N)" << endl << endl;   // Weights and heading are right justified in a field 14 char wide
        cout << setw(16) << left << "Earth" << '\t'<< setprecision(3) << fixed << setw(14) << right << earthWeight;
        
        // If weights over 1250 Newtons on Earth, a message indicating "the object is heavy" will be displayed
        if (earthWeight >= 1250)
        {
            cout << '\t' << "The object is heavy";
        }
        // If it weights less than 20 Newtons on Earth, a message indicating "the object is light" will be displayed
        else if (earthWeight <= 20)
        {
            cout << '\t' << "The object is light";
        }
        
        // It continues printing each of the planet's names and their weights
        cout << endl;
        cout << setw(16) << left << "Moon" << '\t' << setprecision(3) << fixed << setw(14) << right << moonWeight << endl;
        cout << setw(16) << left << "Mercury" << '\t' << setprecision(3) << fixed << setw(14) << right << mercuryWeight << endl;
        cout << setw(16) << left << "Venus" << '\t' << setprecision(3) << fixed << setw(14) << right << venusWeight << endl;
    }
    
    
    

    return 0;
}