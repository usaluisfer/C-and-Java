// This program randomly generates a lottery of a two-digit number, prompts the user to enter a two-digit number, and determines whether the user wins according to the following rule: 
// If the user input matches the lottery in exact order, the award is $10,000;
// If the user input matches the lottery(ex 63 and 36), the award is $3,000;
// If one digit in the user input matches a digit in the lottery(ex 83 and 39), the award is $1,000.
// Else no award
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    // Random number generator
    srand(time(0));
    
    // Declare random variable
    int randomNumber;
    randomNumber = (rand() % 90) + 10; // Generates a random number between 10 and 99
    
    // Input the user for a two-digit number
    int userNumber;
    cout << "Enter a two-digit number: ";
    cin >> userNumber;
    
    // Finding the two digits from the random generated number
    int random_FirstDigit = randomNumber / 10;
    int random_SecondDigit = randomNumber % 10;
    
    // Finding the two digits from the user's number
    int user_FirstDigit = userNumber / 10;
    int user_SecondDigit = userNumber % 10;
    
    // if statements for determining the award
    if (userNumber == randomNumber)    // If numbers are the same
    {
        cout << "Your award is $10,000" << endl;
    }
    else if (user_FirstDigit == random_SecondDigit && user_SecondDigit && random_FirstDigit)    // If input matches the lottery, no matter the order
    {
        cout << "Your award is $3,000" << endl;
    }
    else if (user_FirstDigit == random_FirstDigit || user_FirstDigit == random_SecondDigit || user_SecondDigit == random_FirstDigit || user_SecondDigit == random_SecondDigit)    // If one digit in the user input matches a digit in the lottery (random number)
    {
        cout << "Your award is $1,000" << endl;
    }
    else    // If nothing matches, no reward
    {
        cout << "No award" << endl;
    }
    
    

    return 0;
}