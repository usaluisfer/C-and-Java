#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;

int main() 
{
    string filename;
    
    cout << "Enter the input file name." << endl;
    cin >> filename;
    
    ifstream inFile(filename);
    
    if(!inFile) 
    {
        cout << endl << "Cannot open file " << filename;
        
        return 1;  
    }  
    
    ofstream fout;
    
    ifstream fin;

    fin.open("invalid-numbers.txt");  

    fout.open ("invalid-numbers.txt");  // , ios::app

    double sum = 0; 
    int valid = 0; 
    int invalid = 0;
    double num = 0;
    
    while(!inFile.eof()) 
    {
        inFile >> num;
        
        if(num >= 0 && num <= 110)
        {
            sum+=num; valid++;
        }
        
        else
        { 
            invalid++;
            
            if(fin.is_open())
            {
                fout << fixed << setprecision(2) << num << "\n";    
                
            }  
            
        }  
        
    }
    
    fin.close();
    fout.close();
    inFile.close();
    
    cout << "Total number of values read: " << valid + invalid << endl;
    cout << "Valid values read: " << valid << endl;
    cout << "Invalid values read: " << invalid << endl;
    cout << "The average of the valid numbers read = " << fixed << setprecision(2) << sum / valid << endl;    
    
    double inv;

    ifstream inFiles("invalid-numbers.txt");
    
    while(!inFiles.eof()) 
    {
        inFiles >> inv;
        
        cout << inv << "\n";
    }

    inFiles.close();

    return 0;

}