#include "Complex.h"
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

//write the parametrized constructor
Complex::Complex(double rreal, double imag)
{
    real = rreal;
    imaginary = imag;
}

//we are assuming string is of format "10.1 20.2"
Complex::Complex(string input) 
{
  real = imaginary = 0; //additional safety!
  istringstream iss(input);
  iss >> real >> imaginary;
}

// Destructor definition
Complex::~Complex()
{
    cout << "Destructor called" << endl;
}

//Write getters and setters
double Complex::getReal()
{
   return real;
}

double Complex::getImaginary()
{
   return imaginary;
}

void Complex::setReal(double rreal)
{
   real = rreal;
}

void Complex::setImaginary(double imag)
{
   imaginary = imag;
}


//write overloaded operators for + and =+
Complex Complex::operator+(const Complex &second) const
{
   return Complex(real+second.real, imaginary+second.imaginary);
}

void Complex::operator+=(const Complex &second)
{
   real += second.real;
   imaginary += second.imaginary;
}



//return conjugate?
Complex Complex::operator~()
{
   return Complex(real, -imaginary);
}


//treat input like cin
istream& operator>>(istream& input, Complex &object) 
{
    string str;
    getline (input >> ws, str);
    object = Complex(str);
    return input;
    
    /*
    input >> "(" >> object.real >> "," >> object.imaginary >> ")";
    return input;
    */
}


//treat output like cout
ostream& operator<<(ostream& output, const Complex &object) 
{
    output << "(" << object.real << "," << object.imaginary << ")";
    return output;
}
