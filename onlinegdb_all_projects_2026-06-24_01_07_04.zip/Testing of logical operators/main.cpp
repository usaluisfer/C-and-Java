//This program implements testing of logical operators
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    //choices = 3 7 13 17 23
    int x = 5, a = 10, b = 15, c = 20, choice;
    cout << "Enter choice: " ;
    cin >> choice;
    if ((choice < (x += 1)) || (choice > (a += 1)) && (choice < (b +=1)) || (choice > (c += 1)))
    {
        cout << "L15: " << "good"<< endl;
    }
    cout << "x = " << x << endl;
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
    cout << "c = " << c << endl << endl;

    if (((choice < (x += 1)) || (choice > (a += 1))) && ((choice < (b +=1)) || (choice > (c += 1))))
    {
        cout << "L25: " << "good" << endl;
    }
    cout << "x = " << x << endl;
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
    cout << "c = " << c << endl << endl;


    // if we do this way the results might be wrong keeping b and c first
    if ( (choice < b) || (choice > (c += 1)) && (choice < (x += 1)) || (choice > (a += 1)) )
    {
        cout << "L35: " << "good"<< endl;
    }
    cout << "x = " << x << endl;
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
    cout << "c = " << c << endl << endl;


    // if we do this way the results might be wrong keeping b and c first
    if ( ((choice < b) || (choice > (c += 1)))&& ((choice < (x += 1)) || (choice > (a += 1))))
    {
        cout << "L45: " << "good"<< endl;
    }
    cout << "x = " << x << endl;
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
    cout << "c = " << c << endl << endl;

}

/*

while choice is 7
15 F||F &&NC||F        --> F
25 (F||F) && NC         --> F
35 T|| NC                    -->T
45 (T||NC)&&(T||NC)  -->T

*/