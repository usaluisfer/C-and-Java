// This program implements a graph data structure using an adjacency matrix 
// There is a graph class for creating the adjacency matrix and including methods for adding edges, 
// checking if the graph is a complete graph or not,
// and printing the matrix

// Graph class

public class Graph
{
    // adjacency matrix
    private int[][] matrix;
    private int vertices;
    
    // Constructor
    public Graph(int v)
    {
        vertices = v;
        matrix = new int[v][v];
    }
    
    // Method to add an edge
    public void addEdge(int i, int j)
    {
        if (i >= 0 && j >= 0 && i < vertices && j < vertices && i != j)
        {
            matrix[i][j] = 1;
            matrix[j][i] = 1;
        }
    }
    
    // Method for checking if graph is complete
    public boolean complete()
    {
        for (int i = 0; i < vertices; i++)
        {
            for (int j = 0; j < vertices; j++)
            {
                // Diagonal must contain only 0s
                if (i == j && matrix[i][j] != 0)
                {
                    return false;
                }
                
                // Making sure the rest of the matrix is filled with 1s, if not, boolean is still set to false
                if (i != j && matrix[i][j] != 1)
                {
                    return false;
                }
                
                
            }
        }
        
        // Returning true if complete
        return true;
        
    }
    
    
    
    
    // Method for printing the adjacency matrix
    public void printMatrix()
    {
        System.out.println("Adjacency Matrix:");
        
        for (int i = 0; i < vertices; i++)
        {
            for (int j = 0; j < vertices; j++)
            {
                System.out.print(matrix[i][j] + " ");
                
            }
            
            System.out.println();
        }
    }
    
    
}