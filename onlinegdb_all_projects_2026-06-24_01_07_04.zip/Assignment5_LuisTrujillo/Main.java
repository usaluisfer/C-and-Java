// Main class for displaying the matrix and results in the case of a complete graph or not
import java.util.Scanner;
public class Main 
{
    public static void main(String[] args) 
    {
        // 4x4 adjacency matrix
        Graph g = new Graph(4);
        
        // For a complete graph
        g.addEdge(0,1);
        g.addEdge(0,2);
        g.addEdge(0,3);
        g.addEdge(1,2);
        g.addEdge(1,3);
        g.addEdge(2,3);

        
        // Printing adjacency matrix 
        g.printMatrix();
        
        // Checking if it is a complete graph
        if (g.complete()) 
        {
            System.out.println("The graph is a complete graph.");
        } 
    
        else 
        {
            System.out.println("The graph is not a complete graph.");
        }
        
        
    }
        
      
        
}





