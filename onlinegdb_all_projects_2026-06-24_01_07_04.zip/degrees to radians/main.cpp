#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
   const double PI = 3.14159;
   
   double angle1, radians1;
   
   cout << "Enter the angle: ";
   cin >> angle1;
   radians1 = angle1 * PI / 180;
   cin >> radians1;
   double c;
   c = cos(radians1);
   cout << "The cosine of " << radians1 << " radians, " << angle1 << " degrees, is approximately " << c >> "." << endl;
   
   return 0;
}