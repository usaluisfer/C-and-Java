// This program uses two identical arrays of 18 integers.
// It calls a function that uses the bubble sort algorithm to sort one of the arrays in ascending order.
// The function keeps a count of the number of exchanges it makes.
// The program then calls a function that uses the selection sort algorithm to sort the other array. 
// It also keeps count of the number of exchanges it makes. Finally it displays these values on the screen. 
#include <iostream>

using namespace std;

// Function prototypes
int bubbleSort(long [], int);
int selectionSort(long [], int);
void swap(long&, int&);


int main()
{
   int exchanges; // Number of exchanges made
   const int SIZE = 18;
   
   // Two arrays with identical values
   long accounts1[SIZE] =
      { 5658845,  4520125,  7895122,
        8777541,  8451277,  1302850,
        8080152,  4562555,  5552012,
        5050552,  7825877,  1250255,
        1005231,  6545231,  3852085,
        7576651,  7881200,  4581002 };
        
   long accounts2[SIZE] = 
      { 5658845,  4520125,  7895122,
        8777541,  8451277,  1302850,
        8080152,  4562555,  5552012,
        5050552,  7825877,  1250255,
        1005231,  6545231,  3852085,
        7576651,  7881200,  4581002 };
        
   // Sort accounts1 with bubble sort. The function
   // returns the number of exchanges made.
   exchanges = bubbleSort(accounts1, SIZE);
   
   // Display the number of exchanges made by the
   // bubble sort.
   cout << "\n" << exchanges 
        << " exchanges were made by Bubble Sort."
        << endl;

   // Sort accounts2 with selection sort. The function
   // returns the number of exchanges made.
   exchanges = selectionSort(accounts2, SIZE);
   cout << "\n" << exchanges 
        <<  " exchanges were made by Selection Sort." 
        << endl;

   return 0;
}

// bubble sorting for first array
int bubbleSort(long accounts1[], int SIZE)
{
    int exchanges = 0;    // counter for carrying number of exchanges
    
    // Comparing first two elements, then moving down one element and comparing next two
    for (int maxElement = SIZE - 1; maxElement > 0; maxElement--)
    {
        for (int index = 0; index < maxElement; index++)
        {
            if (accounts1[index] > accounts1[index + 1])
            {
                // Exchanging when element is greater
                swap(accounts1[index], accounts1[index + 1]);
                exchanges++;    // Updating number of exchanges
            }
        }
    }
    
    // Returning to main
    return exchanges;
    
}

// swap function for swapping a and b in memory
void swap(long &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}


// selection sorting used for second array "accounts2[]"
int selectionSort(long accounts2[], int SIZE)
{
    // Number of exchanges
    int exchanges = 1;
    // min index
    int minIndex;
    // min value
    int minValue;
    
    // selection sort for locating smallest element in array and exchanging with element at first position
    for (int start = 0; start < (SIZE - 1); start++)
    {
        minIndex = start;
        minValue = accounts2[start];
        
        // Keeps checking for other elements
        for (int index = start + 1; index < SIZE; index++)
        {
           // Checking if index element is smaller than the minimum value found
            if (accounts2[index] < minValue)
            {
               // Updating minimum value and index
                minValue = accounts2[index];
                minIndex = index;
            }
        }
        // swaping elements if needed
        if (minIndex != start) // Swap only if needed
        {
            swap(accounts2[minIndex], accounts2[start]);
            exchanges++; // Incrementing exchanges counter
        }
    }
    return exchanges;
    
    
}





