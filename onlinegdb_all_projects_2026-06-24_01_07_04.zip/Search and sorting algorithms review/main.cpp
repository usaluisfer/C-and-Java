// Linear search algorithm
int linearSearch(int array[], int size, int value)
{
    int index = 0;
    int position = -1;
    bool found = false;
    
    while (index < size && !found)
    {
        if (array[index] == value)
        {
            found = true;
            position = index;
        }
        index++;
    }
    return position;
}



// binary search
int binarySearch(int array[], int size, int value)
{
    int first = 0;
    int last = size - 1;
    int middle;
    int position = -1;
    bool found = false;
    
    while (!found && first <= last)
    {
        middle = (first + last) / 2;
        
        if (array[middle] == value)
        {
            found = true;
            position = middle;
        }
        
        else if (array[middle] > value)
        {
            last = middle - 1;
        }
        
        else
        {
            first = middle + 1;
        }
        
        
        
    }
    
    return position;
    
}



// bubble sort
void bubbleSort(int array[], int size)
{
    int maxElement;
    int index;
    
    for (maxElement = size - 1; maxElement > 0; maxElement--)
    {
        for (index = 0; index < maxElement; index++)
        {
            if (array[index] > array[index + 1])
            {
                swap(array[index], array[index + 1]);
            }
        }
    }
}

// swap function
void swap (int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}




// Selection sort
void selectionSort(int array[], int size)
{
    int minIndex;
    int minValue;
    
    for (int start = 0; start < (size - 1); start++)
    {
        minIndex = start;
        minValue = array[start];
        
        for (int index = start + 1; index < size; index++)
        {
            if (array[index] < minValue)
            {
                minValue = array[index];
                minIndex = index;
            }
        }
        
        swap(array[minIndex], array[start]);
    }
}















