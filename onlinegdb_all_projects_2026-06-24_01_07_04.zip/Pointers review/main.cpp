
#include <iostream>
using namespace std;

int main()
{

    // Program for displaying array contents using pointer
    const int size = 8;
    int set[size] = {5, 10, 15, 20, 25, 30, 35, 40}; 
    int *numPtr = nullptr;
    int count;
    
    numPtr = set;
    
    cout << "Displaying array contents:\n" << endl;
    
    // Using pointer to display array contents
    for (count = 0; count < size; count++)
    {
        cout << *numPtr << " " << endl;
        numPtr++;
    }
    
    // Displaying array contents in reverse order
    cout << endl << "Displaying in reverse:\n" << endl;
    
    for (count = 0; count < size; count++)
    {
        numPtr--;
        cout << *numPtr << " " << endl;
    }
    


    
    
    
    // Other way for displaying array contents using pointer
    /*
    int array[] = {10,2,3,9}; 
    int *start = &array[0];
    int *end = &array[3];
    
    while (start <= end) 
    {
        cout << *start << endl;
        start++;
    }
    
    */
    
    
    
    
    
    


    return 0;
}