#include <iostream>
#include "Triangle.h"

using namespace std;

int main() 
{
   Triangle triangle1;
   Triangle triangle2;

   // Read and set base and height for triangle1 (use SetBase() and SetHeight())
   double triangleBase1, triangleBase2, triangleHeight1, triangleHeight2;
   
   // Reading input from user
   cin >> triangleBase1 >> triangleHeight1;
   
   // setting base and height for triangle #1
   triangle1.SetBase(triangleBase1);
   triangle1.SetHeight(triangleHeight1);
   

   // Read and set base and height for triangle2 (use SetBase() and SetHeight())
   cin >> triangleBase2 >> triangleHeight2;
   
   // setting base and height for triangle #2 
   triangle2.SetBase(triangleBase2);
   triangle2.SetHeight(triangleHeight2);
   

   //
   cout << "Triangle with smaller area:" << endl;
       
   // Determine smaller triangle (use GetArea()) and output smaller triangle's info (use PrintInfo())
   if (triangle1.GetArea() < triangle2.GetArea())
   {
       triangle1.PrintInfo();
   }
   
   else
   {
       triangle2.PrintInfo();
   }
   
   
   
   
   
  
   
   return 0;
}