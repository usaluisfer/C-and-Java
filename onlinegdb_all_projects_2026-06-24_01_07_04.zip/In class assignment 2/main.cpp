// This program modifies selectionSort to take a parallel array as a second argument.
// As selectionArray is sorted, the parallel array (gpa) is sync with the other array.
#include <iostream>
#include <string>

using namespace std;

// Calling selectionSort with the array to be sorted and the parallel array
void selectionSort(string[], float[], int); 
void selectionSort(float[], string[], int);

// Function prototype for displayArray to display the two types of array
void displayArray(string[],int);
void displayArray(float[],int);


int main()
{
    const int SIZE = 6;
   
    string student[SIZE] = {
                       "Collins,Bill", 
                       "Smith, Bart", 
                       "Allen, Jim", 
                       "Griffin, Jim", 
                       "Stamey, Marty", 
                       "Rose, Geri"
                      };
        
    float gpa[SIZE] = {3.5,4.0,2.75,3.25,3.0,2.0};
    
   // Sort the names array alphabetically. Make sure to keep the gpa array updated 
   
   selectionSort(student,gpa,SIZE);
   
   cout << "Display array after sorting by names\n" << endl;
   
   // Displaying student names alphabetically
   displayArray(student, SIZE);
   cout << endl;
   
   // Displaying gpa values (same array positions)
   displayArray(gpa, SIZE);
   
   // Sort the gpa array in ascending order. Make sure to keep the student array updated 
   
   selectionSort(gpa,student,SIZE);
   cout << "\nDisplay array after sorting by gpa\n" << endl;
   
   // Displaying the student array in sync with their gpa
   displayArray(student, SIZE);
   cout << endl;
   
   // Displaying the gpa of each student in order (sync)
   displayArray(gpa, SIZE);
   
   return(0);
   
}


// Function for sorting the names alphabetically using selection sort
void selectionSort(string student[], float gpa[], int SIZE)
{
    int minIndex;
    string minValue;    // string for names
    
    for (int start = 0; start < (SIZE - 1); start++)
    {
        minIndex = start;
        minValue = student[start];
        
        for (int index = start + 1; index < SIZE; index++)
        {
            if (student[index] < minValue)
            {
                minValue = student[index];
                minIndex = index;
            }
        }
        
        // swapping indexes for student and gpa arrays
        swap(student[minIndex], student[start]);
        swap(gpa[minIndex], gpa[start]);
        
    }
}



// Function for sorting the names from lowest to high, with their corresponding gpa values
void selectionSort(float gpa[], string student[], int SIZE)
{
    int minIndex;
    float minValue;
    
    for (int start = 0; start < (SIZE - 1); start++)
    {
        minIndex = start;
        minValue = gpa[start];
        
        for (int index = start + 1; index < SIZE; index++)
        {
            if (gpa[index] < minValue)
            {
                minValue = gpa[index];
                minIndex = index;
            }
        }
        
        // swapping indexes for student and gpa arrays
        swap(gpa[minIndex], gpa[start]);
        swap(student[minIndex], student[start]);


            
    }
}



// Displaying sorted student array
void displayArray(string student[], int SIZE)
{
    for (int i = 0; i < SIZE; i++)
    {
        cout << student[i] << endl;
    }
}



// Displaying sorted gpa array
void displayArray(float gpa[], int SIZE)
{
    for (int i = 0; i < SIZE; i++)
    {
        cout << gpa[i] << endl;
    }
}




