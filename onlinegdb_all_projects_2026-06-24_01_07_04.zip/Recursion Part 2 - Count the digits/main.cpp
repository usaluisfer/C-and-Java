#include <iostream>
using namespace std;

/* TODO: Write recursive DigitCount() function here. */
int DigitCount(int num)
{
    if (num < 10)
    {
        return 1;
    }
    
    else
    {
        return 1 + DigitCount(num / 10);
    }
    

}


int main() 
{
   int num;
   int digits;

   cin >> num;
   digits = DigitCount(num);
   cout << digits << endl;
   
   return 0;
}
