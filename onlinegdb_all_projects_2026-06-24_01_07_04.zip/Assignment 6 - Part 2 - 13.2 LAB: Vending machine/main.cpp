#include <iostream>

#include "VendingMachine.h"
using namespace std;

int main() 
{
   // Variables to store input
   int purchaseNum1, restockNum, purchaseNum2;
   
   // Getting data from user
   cin >> purchaseNum1 >> restockNum >> purchaseNum2;
   
   // VendingMachine object
   VendingMachine machine;
   
   // First purchase
   machine.Purchase(purchaseNum1);
   
   // Restock
   machine.Restock(restockNum);
   
   // Second purchase
   machine.Purchase(purchaseNum2);
   
   // Final inventory
   machine.Report();
   
   
   
	
	return 0;
}