/* A program to demonstrate the use of the stream manipulators to format output.
   The program displays student names and GPA's in tabular form
*/

#include <iostream>
#include <iomanip>

#define NAME_COL_WIDTH 40
#define FNAME_COL_WIDTH 20
#define LNAME_COL_WIDTH 20
#define GPA_COL_WIDTH 4

using namespace std;

int main()
{
    // Display headings
    cout << "LAST NAME, FIRST NAME";
    cout << '\t';
    cout << "GPA";
    cout << endl;

    // Display the data in the table under the headings

    // ROW 1

    cout << "Ables, Jack";
    cout << '\t';
    cout << 3.1;
    cout << endl;

    // ROW 2

    cout << "Westermann, Celeste";
    cout << '\t';
    cout << 2.0;
    cout << endl;

    // ROW 3

    cout << "Johnson, Vonda";
    cout << '\t';
    cout << 3.67;
    cout << endl;
    cout << endl;

    // Use stream manipulators to format

    cout << "-----------------------------------------------------------------------\n";

   
   
    // Second set of printing
    // Display headings
   
    // The headings LAST NAME, FIRST NAME should be left justified and heading GPA should be right justified
    cout << left << "LAST NAME, FIRST NAME";
    cout << '\t';
    cout << setw(25) << right << "GPA";
    cout << endl;

    // Display the data in the table under the headings

    // ROW 1
    // The actual names should be left justified and the gpa values should be right justified
    cout << left << "Ables, Jack";
    cout << '\t';
    cout << setw(53) << right << 3.10;
    cout << endl;

    // ROW 2

    cout << left << "Westermann, Celeste";
    cout << '\t';
    cout << setw(35) << right << 2.00;
    cout << endl;

    // ROW 3

    cout << left << "Johnson, Vonda";
    cout << '\t';
    cout << setw(50) << right << 3.67;
    cout << endl;

    // Use stream manipulators to format

    cout << "-----------------------------------------------------------------------\n";

    
    
    // Third set of printing
    // Display headings
    // Last Names and first Names are left-justified but a little separate from each other
    cout << setw(20) << left << "LAST NAME";
    cout << "FIRST NAME";
    cout << '\t';
    cout << setw(17) << right << "GPA";
    cout << endl;

    // Display the data in the table under the headings

    // ROW 1
    // Actual names are left-justified and gpa's are right justified
    cout << setw(27) << left << "Ables";
    cout << "Jack";
    cout << '\t';
    cout << setw(37) << right << 3.10;
    cout << endl;

    // ROW 2

    cout << setw(21) << left << "Westermann"; 
    cout << "Celeste";
    cout << '\t';
    cout << setw(27) << right << 2.00;
    cout << endl;

    // ROW 3

    cout << setw(24) << left << "Johnson";
    cout << "Vonda";
    cout << '\t';
    cout << setw(34) << right << 3.67;
    cout << endl;
    cout << endl;

    // Use stream manipulators to format

    cout << "-----------------------------------------------------------------------\n";

    cout << endl;
   
   
   
   

    return 0;
}