// This program randomly generates two single-digit integers number1 and number2. 
// Asks the user to input the difference of the two numbers with always the greater number as the first operand. 
// If the user inputs wrong answer, the following message is printed to the screen: “Your answer is wrong. The correct answer is ” with the correct answer. 
// Otherwise it will print “Your answer is correct.”
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main()
{
    // Declaring random numbers and other variables as integers
    int random_num1;
    int random_num2;
    int temp;
    int userAnswer;
    int correctAnswer;
    
    // This function initializes random number generator with unsigned int x
    srand(time(0));
    
    random_num1 = (rand() % 10);  // rand() returns a random number (int) between 0 and the largest int the compute holds
    random_num2 = (rand() % 10);
    
    // Check if number1 < number2, otherwise swap them
    if (random_num1 < random_num2)
    {
        temp = random_num1;
        random_num1 = random_num2;
        random_num2 = temp;
    }
    
    {
        // Ask the user,  what is “number1 – number2”?
        cout << "What is " << random_num1 << " - " << random_num2 << "? ";
        cin >> userAnswer;
    }
    
    // Calculating the real difference
    correctAnswer = random_num1 - random_num2;
    
    // if statement for checking if the user enter the right/wrong answer
    if (userAnswer == correctAnswer)
    {
        cout << "Your answer is correct" << endl;
    }
    
    else
    {
        cout << "Your answer is wrong. The correct answer is " << correctAnswer;
    }
    
    

    return 0;
}