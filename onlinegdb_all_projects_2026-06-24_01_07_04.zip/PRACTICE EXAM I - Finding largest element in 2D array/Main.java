// Finding max element from 2D array
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
	    Scanner input = new Scanner(System.in);
	    
	    System.out.println("Enter # of rows: ");
		int row = input.nextInt();
		
		System.out.println("Enter # of columns: ");
		int column = input.nextInt();
		
		// Declaring a array
		int[][] matrix = new int[row][column];
		
		// User enters array elements
		System.out.println("Enter " + row + " rows and " + column + " columns: ");
		System.out.println();
		
		for (int i = 0; i < row; i++)
		{
		    for (int j = 0; j < column; j++)
		    {
		        matrix[i][j] = input.nextInt();
		    }
		}
		
		
		// Displaying array 
		System.out.println();
		System.out.println("Displaying array: ");
		
		for (int i = 0; i < row; i++)
		{
		    for (int j = 0; j < column; j++)
		    {
		        System.out.print(matrix[i][j] + " ");
		    }
		    
		    System.out.println();
		}
		
	
		// Finding max element
		int max = matrix[0][0];
		for (int i = 0; i < row; i++)
		{
		    for (int j = 0; j < column; j++)
		    {
		        if (matrix[i][j] > max)
		        {
		            max = matrix[i][j];
		        }
		    }
		}
		
		System.out.println();
		System.out.println("Max element is " + max);
		
		
		
	}
}
