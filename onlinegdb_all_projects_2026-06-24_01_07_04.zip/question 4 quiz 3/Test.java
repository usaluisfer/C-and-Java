//
public class Test
{
    public static void main(String[] args) 
    {
        new Circle();
    }
}


/*
public abstract class GeometricObject 
{
    protected GeometricObject() 
    {
        System.out.print("A");
    }
    
    protected GeometricObject(String color, boolean filled) 
    {
        System.out.print("B");
    }

}
*/


/*
public class Circle extends GeometricObject 
{
    // Default constructor 
    public Circle() 
    {
        this(1.0);
        System.out.print("C");
    }
    
    // Construct circle with a specifi ed radius
    public Circle(double radius) 
    {
        this(radius, "white", false);
        System.out.print("D");
    }
    
    //Construct a circle with specifi ed radius, fi lled, and color
    public Circle(double radius, String color, boolean filled) 
    {
    super(color, filled);
    System.out.print("E");
    }
}
*/