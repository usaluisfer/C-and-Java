public class Circle extends GeometricObject 
{
    /** Default constructor */
    public Circle() 
    {
        this(1.0);
        System.out.print("C");
    }
    
    /** Construct circle with a specifi ed radius */
    public Circle(double radius) 
    {
        this(radius, "white", false);
        System.out.print("D");
    }
    
    /** Construct a circle with specifi ed radius, fi lled, and color */
    public Circle(double radius, String color, boolean filled) 
    {
    super(color, filled);
    System.out.print("E");
    }
}