/*
// Activity 5
// This program randomly generates an integer between 100 and 999, inclusive. 
// It prompts the user to enter a number continuously until the the number is entered 7 times.
// For each user input, the program tells the user if the number was guessed correctly.
import java.util.Scanner; 
import java.util.Random; 

public class Main 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int number1 = rand.nextInt(900) + 100;  // Generating a random number between 100–999

        // count variable for holding the number of times it asks the user (7)
        int count = 0;
        
        // while loop for asking user until the guess is correct
        while (count < 7) 
        {
            System.out.println("Guess a number between 100 and 999: ");
            int guess = input.nextInt();

            // If user guesses correctly, program ends
            if (guess == number1) 
            {
                System.out.println("Correct!");
                break;
            }
            
            // If guess is wrong, it displays "Wrong" message and a hint if number is higher or lower
            else 
            {
                System.out.println("Wrong.");
                if (guess < number1) 
                {
                    System.out.println("Guess higher next time.\n");
                } else 
                {
                    System.out.println("Guess lower next time.\n");
                }
                // Increments until program gives user 7 attemps
                count++;
            }
        }

        input.close();
    }
}
*/





//Using Math.random() is easier 

import java.util.Scanner; 

public class Main 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        
        // Using Math.random() to generate a number between 100–999
        int number1 = (int)(Math.random() * 900) + 100;

        // count variable for holding the number of times it asks the user (7)
        int count = 0;
        
        // while loop for asking user until the guess is correct or max attempts
        while (count < 7) 
        {
            System.out.println("Guess a number between 100 and 999: ");
            int guess = input.nextInt();

            // If user guesses correctly, program ends
            if (guess == number1) 
            {
                System.out.println("Correct!");
                break;
            }
            
            // If guess is wrong, it displays "Wrong" message and a hint if number is higher or lower
            else 
            {
                System.out.println("Wrong.");
                if (guess < number1) 
                {
                    System.out.println("Guess higher next time.\n");
                } 
                else 
                {
                    System.out.println("Guess lower next time.\n");
                }
                // Increments until program gives user 7 attempts
                count++;
            }
        }

        input.close();
    }
}
