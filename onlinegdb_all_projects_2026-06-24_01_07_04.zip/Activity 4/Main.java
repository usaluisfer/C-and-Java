// Activity 4 
// Using if else statements, this program takes a number between 1 and 122 from user,
// for a number entered between 1 and 64, it is not an ASCII code,
// for numbers between 65 and 90 it prints that the number is an ASCII code for capital letters and prints the letter,
// and for numbers greater than 97, it prints its an ASCII code for small letters and displays the letter.
// If its a number between 1 and 64, it is not an ASCII code.
import java.util.Scanner;

public class Main
{
	public static void main(String[] args) 
	{
	    Scanner sc = new Scanner(System.in);
	    
		System.out.println("Enter a number between 1 and 122: ");
		int number = sc.nextInt();
		
		if (number >= 1 && number <= 64)
		{
		    System.out.println("It is not ASCII code.");
		}
		
		else if (number >= 65 && number <= 90)
		{
		    System.out.println("It is ASCII code for capital letters: " + (char)number);     // (char) displays the respective ASCII letter
		}
		
		else if (number >= 97 && number <= 122)
		{
		    System.out.println("It is ASCII code for small letters: " + (char)number);
		}
		
		else
		{
		    System.out.println("Not in the range!");
		}
		
		sc.close();
		
	}
}
