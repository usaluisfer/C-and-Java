// This program asks the user to enter a file name. 
// Reads the filename on the same line as the prompt;
// It also reads a file name from cin. It will then open the input file.
// The program opens an output file called "badvalues.txt". 
// Invalid values are written to that file in fixed point notation with exactly three digits to the right of the decimal point.
// The processing loop reads the input data and process it until it gets an end of file indication from the file read operation.
// The average of the valid values is displayed in fixed-point notation with exactly two digits to the right of the decimal point.
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

int main() 
{
    // Declaring variables
    string inputFileName;
    
    ifstream inputFile;   // Input stream for input from a file
    ofstream badValuesFile;   // For output to a file named "badvalues.txt"
    
    // Double type for number and sum
    double number;
    double sum = 0.0;
    
    // Int variables set at 0
    int totalNumbers = 0;
    int validNumbers = 0; 
    int invalidNumbers = 0;

    // Asking user for file name
    cout << "Enter the input file name.\n";
    cin >> inputFileName;

    // Opening input file
    inputFile.open(inputFileName);
    
    // If file is not opened successfully, error message displayed
    if (!inputFile) 
    {
        cout << "The file \"" << inputFileName << "\" could not be opened." << endl;
        return 1;   // Ends program
    }

    // Opening output file
    badValuesFile.open("badvalues.txt");   // Name of output file

    // While loop for reading the numbers
    while (inputFile >> number) 
    {
        totalNumbers++;   // totalNumbers count increments
        
        // If the number is greater than or equal to 1 and less than or equal to 150, it's valid
        if (number >= 1 && number <= 150) 
        {
            validNumbers++;   // Valid count increments
            sum += number;   // Stored in sum
        } 
        
        // If it's not inside the range, it's stored as invalid
        else 
        {
            invalidNumbers++;   // Invalid count increments
            
            // It's displayed to the output file
            badValuesFile << fixed << setprecision(3) << number << endl;
        }
    }

    // Closing both files
    inputFile.close();    // Closing input
    badValuesFile.close();    // Closing output

    // Displaying total count to the user
    cout << endl << "Total number of values read: " << totalNumbers << endl;
    cout << "Valid values read: " << validNumbers << endl;
    cout << "Invalid values read: " << invalidNumbers << endl;

    // If there are valid numbers, their average is calculated
    if (validNumbers > 0) 
    {
        // Calculating average by dividing the total sum by the count of valid numbers
        double average = sum / validNumbers;    // average is double type
        
        // Average is displayed to the user
        cout << "The average of the valid numbers read = " << fixed << setprecision(2) << average << endl;
    } 
    
    // If there are no valid numbers, a message is displayed
    else 
    {
        cout << "The file did not contain any valid values." << endl;
    }

    return 0;
}
