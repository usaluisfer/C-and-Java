// This program includes a function that accepts as arguments an array of integers and an integer that indicates the number of elements in the array
// The function determines the mode (value with the greatest frequency) of the array. Then it determines which value in the array occurs most often.
// The mode is the value the function returns. If the array has no mode, the function returns −1.
#include <iostream>

using namespace std;

// Function prototypes 
int getMode(int *, int);
int *makeArray(int);

int main()
{
	// Constant for the array size
	const int SIZE = 11;
   
	// An array of test values
	int test[SIZE] = {1, 2, 3, 3, 3, 2, 2, 1, 3, 4, 5};
   
	// A variable to hold the mode of the test values
	int mode;

	// Get the mode of the test values.
	mode = getMode(test, SIZE);
   
	// Display the mode, if any.
	if (mode == -1)
		cout << "The test set has no mode.\n";
	else
		cout << "\nThe mode of the test set is: " 
		     << mode << endl;

	return 0;
}



// When this function ends, frequencies[0] will hold the frequency of the value in array[0], and so forth.
int getMode(int *array, int size) 
{
    // Dynamically allocating an array to hold the frequencies of each element in the array.
	int *frequencies = new int[size]{};
	
	int maxCount = 0;
	int mode = -1;
	
    // Calculating frequencies (assuming the first element has the highest frequency)
	for (int i = 0; i < size; i++)
	{
	   frequencies[array[i]]++;    // Updating it
	   
	   // Finding element with the highest frequency
	   if (frequencies[array[i]] > maxCount)
	   {
	       maxCount = frequencies[array[i]];
	       mode = array[i];
	   }
	}
	
	// Deallocating the frequency array
	delete[] frequencies;
	
	// Returning the element with the greatest frequency.
	if (maxCount > 1)
	{
	    return mode;
	}
	
	// If there is no mode (no element has a frequency 
	// greater than 1), then return -1.
	return -1;
	 
	
}




// This function dynamically allocates an array of ints
// and returns a pointer to it. The size parameter is
// the number of elements to allocate.       

int *makeArray(int size) 
{
   return new int[size];
   
   
}

