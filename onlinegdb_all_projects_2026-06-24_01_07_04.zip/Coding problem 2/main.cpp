// #2
// Write a function that parses a string which has two parts separated by a @ symbol. 
// The first part starts with an uppercase letter followed by two lowercase letters. 
// The second part has 3 digits. The @ symbol separates the two parts of the string.
// The length of the string is 7 characters long including the @ symbol.
// Example: “Aab@123”. After you validate and parse the string you should get firstPart as “Aab” and secondPart as “123”.
// Write a function which should accept two strings by reference. 
// The function will not return a value but will set the two parts of the parsed string into the function’s parameters.
// The functions will read the string from the user. 
// If the string is invalid, it keeps asking the user to input a valid string.
// Once a valid string is read it separates the first part and second parts of the strings and sets them to the function’s parameters.

#include <iostream>
#include <string>
#include <cctype>

using namespace std;

// Prototype
void parseString(string &, string &);

//Main
int main() 
{
    // Declaring string variables
    string part1, part2;
    
    // calling the function
    parseString(part1, part2);
    
    // Displaying first and second parts respectively
    cout << "First Part: " << part1 << endl;
    cout << "Second Part: " << part2 << endl;
    
    return 0;
}



// function for letting the user enter a product number and then separating first and second parts
void parseString(string &firstPart, string &secondPart) 
{
    // declaring string variable
    string parseString;
    
    // boolean set to true
    bool isInvalid = true;
    
    // while invalid is true
    while (isInvalid)
    {
        // letting user enter product number
        cout << "Enter the product number: ";
        cin >> parseString;
        
        // Length of string can't be more or less than 7
        if (parseString.length() != 7) 
        {
            // Still invalid
            isInvalid = true;
        }
        
        else if (isupper(parseString[0]) && islower(parseString[1]) && islower(parseString[2]) && parseString[3] == '@' &&
                   isdigit(parseString[4]) && isdigit(parseString[5]) && isdigit(parseString[6])) 
        { 
            // string is valid
            isInvalid = false;
            
            break; //not needed
 
        } //end else if
       
        if (isInvalid) 
        {
            cout << "Invalid input. Try again." << endl;
        }
        
    } //end while
    
    //loop finished, string is valid
    
    // substr used to create a substring of the first 3 elements
    firstPart = parseString.substr(0, 3); // make a string from the first three characters starting at 0
    
    // substr used to create a substring of the last 3 elements, skipping '@'' symbol
    secondPart = parseString.substr(4, 3); // skip @, start at index 3, make a string from the next three characters from index 4
}
