#include <iostream>
#include <string>

using namespace std;

int primeFile();
int readFile(string);

int main()
{
    primeFile();

    readFile("PrimeList.txt");
    return 0;
}