//
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		
		// Prompt user for array dimensions
        System.out.println("Enter # of rows: ");
        int row = input.nextInt();
        
        System.out.println("Enter # of columns: ");
        int column = input.nextInt();
        
		int matrix[][] = new int[row][column];
		
		System.out.println();
		
		
		// User enters array elements
		System.out.println("Enter " + matrix.length + " rows and " + matrix[0].length + " columns: ");
		System.out.println();
		
        for (int i = 0; i < row; i++) 
        {
            for (int j = 0; j < column; j++) 
            {
                matrix[i][j] = input.nextInt();
            }
        }
        

        // Summing all elements in array
        int total = 0;
        
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
                total += matrix[i][j];
            }
        }
        
        System.out.println();
        System.out.println("The total sum of all elements in the array is " + total);
		
	}
}
