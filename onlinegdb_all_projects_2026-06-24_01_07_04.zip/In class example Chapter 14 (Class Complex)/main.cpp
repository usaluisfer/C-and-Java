/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

Complex Complex::operator+(const Complex& c)
{
    Complex tmp(real+c.real,imag + c.imag);
    
    Complex sum;
    sum.setReal(real+c.real);
    sum.setImag(imag + c.imag);
    return(sum);
    
    
}