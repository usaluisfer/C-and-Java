// Coding Problem #1
// Write C-String functions strcpy, strcat that concatenates two strings and return a new string

#include <iostream>
#include <cstring>

using namespace std;

// Prototypes
char strlen(char *);
char *strcpy(char *, char *);
char *strcat(char [], char []);

// Main
int main() 
{
    // Declaring variables for strings
    char str1[100];       // 100 is used to fill size
    char str2[100];
    
    // User enters string
    cout << "Enter first string: ";
    cin.getline(str1, 100);

    cout << "Enter second string: ";
    cin.getline(str2, 100);

    cout << "Concatenated: " << strcat(str1, str2) << endl;


    return 0;
    
}



// strlen() returns length of C-string
char strlen(char *ptr) 
{
    int len = 0;     // set len to 0
    
    // while pointer doesn't point to null element
    while (*ptr != '\0') 
    {
        len++;    // len increases
        ptr++;    // pointer increases
    }
    
    return len;
}



// strcpy() copies str2 to str1
char *strcpy(char *str1, char *str2) 
{
    // Declaring a new pointer variable for storing string1
    char *dptr = str1; // save in another variable
    
    // while pointer for second string is not a null element
    while (*str2 != '\0') 
    {
        // New pointer declared equals second string pointer
        *dptr = *str2;
        
        // pointer for second string increments
        str2++;
        // New pointer increments
        dptr++;
   
    }
 
    *dptr = '\0';  // Null-terminate
    
    
    return str1; 
}



// strcat() appends str2 to end of str1
char *strcat(char str1[], char str2[]) 
{
    int len1 = strlen(str1);     // length of first string
    int len2 = strlen(str2);     // length of second string
    int i;
    int l;
    
    // Allocating new string
    char *newString = new char[len1 + len2 + 1];

    for (i = 0; i < len1; i++) 
    { 
        //copy first string
        newString[i] = str1[i];
    }
  
    // Adding a whitespace between string and string
    newString[i] = ' ';
    i++;
    
    for (l = 0; l < len2; l++) 
    { 
        //copy second string
        newString[i] = str2[l];
        i++;
    }
    
    newString[i] = '\0';    // Null-terminate
    
    
    return newString;

}




