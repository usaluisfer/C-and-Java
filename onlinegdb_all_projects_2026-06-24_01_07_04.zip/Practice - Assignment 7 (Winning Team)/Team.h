#ifndef TEAMH
#define TEAMH

#include <string>

using namespace std;

class Team 
{
    // TODO: Declare private data members - name, wins, losses
    private:
        string name;
        int wins;
        int losses;
        
    public:
    // TODO: Declare mutator functions - 
    //       SetName(), SetWins(), SetLosses()
        void SetName(string userName);
        void SetWins(int userWins);
        void SetLosses(int userLosses);
   
    // TODO: Declare accessor functions - 
    //       GetName(), GetWins(), GetLosses()
        string GetName() const;
        int GetWins() const;
        int GetLosses() const;
   
    // TODO: Declare GetWinPercentage()
        double GetWinPercentage();
   
    // TODO: Declare PrintStanding()
    void PrintStanding();
    
};

#endif