// This program lets the user enter a series of integers. To signal the end of the series, the user should enter −99 .
// At the end, the program displays the largest and smallest numbers entered.
#include <iostream>
using namespace std;

int main()
{
    int number;     // Declaring variable for numbers being entered
    int largestNum;    // Variable that holds the largest number
    int smallestNum;   // Variable holding the smallest number
    int count = 0;     // counter variable
    
    // Asking user to enter numbers until -99 is entered
    cout << "Please input some numbers (with –99 to end): ";
    cin >> number;
    
    largestNum = number;    // numbers are being stored in the variable for largest
    smallestNum = number;   // numbers are also being stored in the variable for smallest
    
    count++;    // counter increments for more numbers until -99 is entered
    
    while (number != -99)
    {
        cin >> number;
        
        // When -99 is received by the user, the list is complete
        if (number == -99)
        {
            break;    // used for finishing the list of numbers
        }
        
        // Checks if a number is the largest one so far, storing it in the largestNum variable.
        if (number > largestNum)
        {
            largestNum = number;
        }
        
        // Checking if a new number entered is smaller than the value previously stored in smallestNum, and gets updated.
        if (number < smallestNum)
        {
            smallestNum = number;
        }
        
        count++;   // Evaluates every number in the list
    }
    
    // Displaying the largest and the smallest numbers in the list entered
    cout << "The largest number is " << largestNum << " and the smallest is " << smallestNum << endl;
    
    

    return 0;
}