#include "CircleFromGO.h"

//GeometricObject definitions
GeometricObject::GeometricObject()
{
    color = "white";
    filled = true;
}

GeometricObject::GeometricObject(string c, bool f)
{
    color = c;
    filled = f;
}

void GeometricObject::setColor(string c)
{
    color = c;
}

void GeometricObject::setFilled(bool f)
{
    filled = f;
}



//CircleFromGO definitions
CircleFromGO::CircleFromGO() : GeometricObject()
{
    radius = 0.0;
}

CircleFromGO::CircleFromGO(double r) : GeometricObject()
{
    radius = r;
}

CircleFromGO::CircleFromGO(double r, string c, bool f) : GeometricObject(c, f)
{
    radius = r;
}

void CircleFromGO::setRadius(double r)
{
    radius = r;
}

// getArea
double CircleFromGO::getArea() const
{
    return 3.14159 * radius * radius;
}

// getPerimeter
double CircleFromGO::getPerimeter() const
{
    return 2 * 3.14159 * radius;
}

// getDiameter 
double CircleFromGO::getDiameter() const
{
    return 2 * radius;
}

// print
void CircleFromGO::print() 
{
    cout << "The circle is created and the radius is " << radius << endl;
    cout << "Color: " << getColor() << " and filled: " << getFilled() << endl;
}



// Operator overload for the output stream operator <<
ostream& operator<<(ostream& strm, const CircleFromGO& obj) 
{
    strm << "The circle printed with ostream!\n";
    strm << "The radius is " << obj.radius << "\n";
    strm << "Color: " << obj.getColor() << " and Area: " << obj.getArea();
    return strm;
}

















