#ifndef GEOMETRICOBJECT_H
#define GEOMETRICOBJECT_H
#include <iostream>
#include <string>
using namespace std;

class GeometricObject
{
    private:
        string color;
        bool filled;
        
    public:
        GeometricObject();
        GeometricObject(string c, bool f);
        void setColor(string c);
        void setFilled(bool f);
        
        string getColor() const
        {
            return color;
        }
        
        bool getFilled() const
        {
            return filled;
        }
};
        
#endif