// This program generates two random numbers.
// It then asks the user for the correct added value of the two integers
// It generates 10 questions randomly, using "count"
// If the user answers correctly, keep a count of correct answers
// If it's wrong, it displays the correct answer with a comment.
// Finally displays the count of correct answers
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    // For generating random numbers
    srand(time(0));
    
    // Declaring count variables
    int correctAnswers = 0;
    int countOfQuestions = 0;
    
    // While loop for setting the number of questions that will be asked (10 max)
    while (countOfQuestions < 10)
    {
        int number1 = rand() % 51;   // random number #1 between 0 and 50
        int number2 = rand() % 101;   // random number #2 between 50 and 100
        
        // Asking the user for entering a number
        cout << "What is " << number1 << " + " << number2 << "? ";
        int answer;
        cin >> answer;
        
        // Calculating the real added value
        int sum = number1 + number2;
        
        // If statement for determining if number entered is the right sum
        if (answer == sum)
        {
            correctAnswers++;
        }
        
        // If not, a message telling that is wrong will be displayed to the screen
        else
        {
            cout << "Your answer is wrong. The correct answer is " << sum << "." << endl;
        }
        
        // The program will continue asking the user until 10 questions are answered
        countOfQuestions++;
        

    }
    
    // After the 10 questions are answered, the program will display the total amount of correct answers
    cout << "You have answered " << correctAnswers << " questions correctly." << endl;




    return 0;
}


/*What is 25 + 14? 39
What is 41 + 22? 63
What is 25 + 56? 81
What is 7 + 13? 50
Your answer is wrong. The correct answer is 20.
What is 7 + 3? 10
What is 50 + 40? 90
What is 24 + 92? 80
Your answer is wrong. The correct answer is 116.
What is 18 + 69? 70
Your answer is wrong. The correct answer is 87.
What is 41 + 37? 78
What is 38 + 2? 40
You have answered 7 questions correctly.*/