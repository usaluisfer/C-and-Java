// This program simulates rolling two six-sided dice
// and displays a report showing the number of times each possible combination of the two dice was rolled.
// It gets the number of dice rolls from the user
// Each die roll can be an unsigned integer value from 1 through 6.
// There are thirty-six possible combinations of the two rolled dice: 1-1, 1-2, 1-3, 1-4, 1-5, 1-6, 2-1, 2-2, … 6-5, 6-6.
// A two-dimensional array of unsigned integers was used to store counters keeping track of the number of times each combination was rolled.
#include <iostream>
#include <cstdlib>
#include <iomanip>

using namespace std;

// constant variable for dimensions 6 x 6 array
const int dimensions = 6;    // 6 rows and 6 columns

int main()
{
    // Declaring seed as unsigned
    unsigned int seed;
    // Getting the seed number from the user
    cin >> seed;
    
    // Calling the srand function to seed the random number generator
    // The seed is the argument passed to the function
    srand(seed);
    
    // Asking user for the times they want the dice to roll
    int rolls;
    cout << "How many times do you want the two dice rolled? ";
    cin >> rolls;
    cout << endl;
    
    if (rolls < 1)
    {
        return 1;
    }
    
    // Initializing counter of posible combinations of dice rolls
    unsigned int combination[dimensions][dimensions] = {0};       // array initialized with 0
    
    // Generating random numbers for the two dice rolls
    for (int i = 0; i < rolls; i++)
    {
        int firstDice = rand() % dimensions + 1;     // for the first dice, random number between 0 and 6 is added 1
        int secondDice = rand() % dimensions + 1;     // for the second dice, random number between 0 and 6 is also added 1
        
        // Accessing the elements in the 2D array
        combination[firstDice - 1][secondDice - 1]++;     // substracting 1 makes it an index between 0 and 5. Incrementing keeps a count of how many times the combination occurs
    }
    
    // Displaying the results to the user
    cout << "The combinations:" << endl;
    
    for (int i = 0; i < dimensions; i++)    // Rows
    {
        for (int j = 0; j < dimensions; j++)     // Columns
        {
            // Displaying the time each dice combination occurs
            // i + 1 and j + 1 is needed for making them to be inside the 1 to 6 range
            cout << "Die 1 = " << i + 1 << " Die 2 = " << j + 1 << " occurred " << combination[i][j] << " times." << endl;
        }
    }
    
   
    return 0;
}