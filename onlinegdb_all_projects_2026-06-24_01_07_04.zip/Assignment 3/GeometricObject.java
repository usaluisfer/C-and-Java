// GeometricObject class that has the following properties and methods:
// Properties: Color and Date 
// Methods: getArea -- abstract, getPerimeter -- abstract, setColor(int color), int getColor()


import java.text.SimpleDateFormat;    // for date formatting like "9/10/2020 – 10:30 AM"
import java.util.Date;

abstract class GeometricObject
{
    int color;
    String date;
    
    // Constructor for initializing
    GeometricObject()
    {
        color = 1;
        
        // Calls import java.text.SimpleDateFormat;
        SimpleDateFormat f = new SimpleDateFormat("M/d/yyyy – h:mm a");
        date = f.format(new Date());
    
    }
    
    // Constructor 2
    GeometricObject(int c, String d)
    {
        color = c;
        date = d;
    }
    
    // abstract methods
    abstract double getArea();
    abstract double getPerimeter();
    
    void setColor(int c)
    {
        color = c;
    }
    
    int getColor()
    {
        return color;
    }
    
    
}


