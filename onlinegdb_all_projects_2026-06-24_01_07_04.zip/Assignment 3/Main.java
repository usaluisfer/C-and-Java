// Main to test the class. It allocates an array for a maximum of 100 triangles.  
import java.util.Scanner;

public class Main
{
    // Main
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        // Allocating an array for a max of 100 traingles
        Triangle[] t = new Triangle[100];
        
        int count = 0;
        int choice;
        
        // Displaying menu setting boolean true
        while (true)
        {
            System.out.println("1. Enter data for a new triangle");
            System.out.println("2. Print all triangles sorted by area");
            System.out.println("3. Enter color (prints only triangles with that color)");
            System.out.println("4. Exit the program");
            System.out.println();
            
            // Letting user enter choice
            System.out.println("Enter choice: ");
            choice = input.nextInt();
            
            if (choice == 1)
            {
                // Asking for length of three sides
                System.out.println("Enter three sides: ");
                double s1 = input.nextDouble();
                double s2 = input.nextDouble();
                double s3 = input.nextDouble();
                
                // Asking for color
                System.out.println("Enter color (1-7): ");
                int c = input.nextInt();
                
                
                if (s1 == 0 && s2 == 0 && s3 == 0)
                {
                    t[count] = new Triangle();
                }
                
                else
                {
                    // If invalid color or side, returns error message and lets user try again
                    if (c < 1 || c > 7 || s1 <= 0 || s2 <= 0 || s3 <= 0)
                    {
                        System.out.println("Invalid, try again.");
                        continue;
                    }
                    
                    t[count] = new Triangle((int)s1, (int)s2, (int)s3, c);
                }
                
                count++;
                
                // Not allowing more than 100 triangles
                if (count >= 100)
                {
                    System.out.println("Limit reached.");
                    continue;
                }
                
                
            }
            
            
            
            
            // Option 2
            else if (choice == 2)
            {
                // Making sure there are triangles to display
                if (count == 0)
                {
                    System.out.println("No triangles to display.");
                    continue;
                }
                
                
                // Making a copy of existing triangles
                Triangle[] temp = new Triangle[count];
                
                for (int i = 0; i < count; i++)
                {
                    temp[i] = t[i];
                }
                
                
                // Using Arrays.sort() method
                java.util.Arrays.sort(temp, 0, count, new java.util.Comparator<Triangle>() 
                {
                    public int compare(Triangle t1, Triangle t2) 
                    {
                        return Double.compare(t1.getArea(), t2.getArea());
                    }
                    
                });
                
            
                
                // Displaying a title for the triangle
                System.out.println("Side 1   Side 2   Side 3   Area      Color    Type                 Date");
                
                // Displaying the triangle
                for (int i = 0; i < count; i++)
                {
                    String line = temp[i].sides[0] + "      " + temp[i].sides[1] + "      " + temp[i].sides[2] + "      " +
                                  temp[i].getArea() + "       " + temp[i].getColor() + "        " + temp[i].getType() + "  " +
                                  temp[i].date;
                    System.out.println(line);
                }
                
                
            }
            
            
            
            
            // Option 3
            else if (choice == 3)
            {
                
                if (count == 0)
                {
                    System.out.println("No triangles to search.");
                    continue;
                }
                
                // Letting user to enter color
                System.out.print("Enter color to search: ");
                int colorToFind = input.nextInt();
                
                // Displaying triangle
                System.out.println("Side 1   Side 2   Side 3   Area      Color     Type                  Date");
                
                for (int i = 0; i < count; i++)
                {
                    
                    if (t[i].getColor() == colorToFind)
                    {
                        
                        String line = t[i].sides[0] + "      " + t[i].sides[1] + "      " + t[i].sides[2] + "      " + t[i].getArea() + "       " +
                                    t[i].getColor() + "      " + t[i].getType() + "    " + t[i].date;
                                      
                        System.out.println(line);
                    }
                }
            }
                
                
              
                
                
            // Option 4 exits the program
            else if (choice == 4)
            {
                
                break;
            }
            
            
            
            
            // If no correct option was selected, error message displayed
            else
            {
                System.out.println("Invalid choice.");
            }
            
        }
       
        
    }
        
        
}