// Triangle class that implements the Comparable interface with the following properties and methods:
// Properties: An array with the sides of the triangle
// Methods: Two constructors, getArea and getPerimeter from GeometricObject, compareTo(Triangle t), and string getType()

import java.lang.Math;   // for getting area using Math.sqrt and Math.round

// implements Comparable for the compareTo function 
public class Triangle extends GeometricObject implements Comparable<Triangle>
{
    double sides[] = new double[3];
    
    // Constructor 1
    Triangle(int s1, int s2, int s3, int c)
    {
        sides[0] = s1;
        sides[1] = s2;
        sides[2] = s3;
        color = c;
    }
    
    // Constructor 2
    Triangle()
    {
        sides[0] = 1;
        sides[1] = 1;
        sides[2] = 1;
        
        color = 1;
        
    }
    
    
    // getArea method
    double getArea()
    {
        // making sure the sides form a triangle 
        if (sides[0] + sides[1] <= sides[2] || sides[0] + sides[2] <= sides[1] || sides[1] + sides[2] <= sides[0])
        {
            return 0;
        }
        
        double s = (sides[0] + sides[1] + sides[2]) / 2;
        double area = Math.sqrt(s * (s - sides[0]) * (s - sides[1]) * (s - sides[2]));
        
        // rounding to 2 decimals
        return Math.round(area * 100.0) / 100.0;
        
        
    }
    
    
    // getPerimeter method
    double getPerimeter()
    {
        return sides[0] + sides[1] + sides[2];
    }
    
    
    // compareTo method
    public int compareTo(Triangle t)
    {
        // Declaring two area variables for comparison
        double a1 = this.getArea();
        double a2 = t.getArea();
        
        // -1 if first area is less than the second one 
        if (a1 < a2)
        {
            return -1;
        }
        
        // 1 if first area is greater
        else if (a1 > a2)
        {
            return 1;
        }
        
        // 0 if equal
        else 
        {
            return 0;
        }
        
    }
    
    
    // getType method
    String getType()
    {
        // Equilateral when all sides are equal
        if (sides[0] == sides[1] && sides[0] == sides[2])
        {
            return "Equilateral Triangle";
        }
        
        // Isosceles when at least two sides are equal
        if (sides[0] == sides[1] || sides[0] == sides[2] || sides[1] == sides[2])
        {
            return "Isosceles Triangle";
        }
        
        // Checking for right triangle by using Pythagorean Theorem
        else if ((sides[0] * sides [0]) + (sides[1] * sides[1]) == (sides[2] * sides[2]) ||
                (sides[1] * sides [1]) + (sides[2] * sides[2]) == (sides[0] * sides[0]) || 
                (sides[0] * sides [0]) + (sides[2] * sides[2]) == (sides[1] * sides[1]))
                {
                    return "Right Triangle";
                }
              
        // Else is a Scalene Triangle (no equal sides or angles)
        else 
        {
            return "Scalene Triangle";
        }
        
        
        
    }
    
}


